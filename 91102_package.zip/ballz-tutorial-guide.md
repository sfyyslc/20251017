# ballz - Your silent app tutorial

Runtime: 06:41 | 1920 x 1080 | 25 fps | MP4 (H.264) | No audio

## Chapters

- **00:00 - Welcome home**
- **00:22 - Make time to focus**
- **02:06 - Make your buddy yours**
- **02:51 - Treats and little friends**
- **03:26 - A home that grows**
- **04:24 - Your study corner**
- **05:29 - Progress and settings**
- **06:17 - Take it with you**

## About this walkthrough

The tutorial is captured from the supplied updated app using its sample world. Text bubbles provide the instructions; green outlines and a visible pointer identify controls. The mobile segment shows the responsive layout. No narration, music, or other sound is included.

Timer jumps are explicitly marked as tutorial preview skips. In normal use, a focus session should run until its timer finishes. The app is a browser-based focus aid, not an operating-system phone lock. The local AI runtime and model files are not included in the supplied app package; this walkthrough shows the preparation help, not real AI inference. The built-in study tools work independently of that model.

## Full on-screen guide

### 00:00 - A little pause. A happier you.

Meet Mochi: your cookie-baking focus companion. Let's see where everything lives.

**Where:** The updated ballz app

### 00:06 - Your map of the app.

Use the left menu for Today, My world, Little shop, Study buddy, and Your progress.

**Where:** Main navigation

### 00:13 - Keep an eye on your cookies.

The jar shows what you can spend. Open it to see your balance and recent rewards or purchases.

**Where:** Top right / Cookie jar

**Note:** The starter world includes 390 sample cookies.

### 00:22 - Start first. Plan next.

Press Start focusing. The timer and break planner opens here, not in a separate page.

**Where:** Today / Start focusing

### 00:29 - Minutes, or a time window.

Choose a duration, or switch to From this time to that for a start and end time.

**Where:** Focus planner / The two tabs

### 00:36 - Make a little plan.

For this example, choose 45 minutes, name your intention, and pick what Mochi will bake.

**Where:** Focus planner / Duration, intention, recipe

### 00:48 - Build in a breather.

Add a 5-minute break at minute 10. The 45-minute session now contains 40 minutes of focus.

**Where:** Focus planner / Add a break

**Note:** Breaks are included in the total. They do not earn cookies.

### 00:58 - You focus. Mochi bakes.

Begin your little pause. The countdown runs while a gentle baking animation keeps your buddy busy.

**Where:** Begin my little pause

### 01:06 - Sounds live inside a session.

Open Quiet sounds for rain, chimes, or your own audio files. Playback stops when the session ends.

**Where:** Focus session / Quiet sounds

**Note:** This tutorial stays completely silent.

### 01:16 - Calls and photos are close by.

Open Calls & photos for the in-app phone and photo tools. They stay accessible during focus.

**Where:** Focus session / Calls & photos

**Note:** This is a browser focus aid, not an actual phone lock.

### 01:24 - Save a little moment.

In Photos, choose or take a picture, or make a postcard of your buddy. Your latest photos stay here.

**Where:** Calls & photos / Photos

### 01:33 - A break, right on time.

At minute 10, focus pauses for your planned break. Stretch, look away, and let the break timer run.

**Where:** Focus session / Planned break

**Note:** Time is advanced here using the app's preview controls.

### 01:40 - Finish to bank the batch.

This example earns 55 cookies: 10 for the first 10 active minutes, then 1.5 per minute after that.

**Where:** Session complete / Cookie reward

**Note:** Tutorial time skip. In normal use, let the timer finish.

### 01:51 - Need to leave early?

Emergency exit cancels the current batch. Previously earned cookies, pets, furniture, and rooms stay safe.

**Where:** Focus session / Emergency exit

**Note:** The exit is always available. No parent PIN is needed.

### 02:06 - A world that feels like you.

Open My world. Your buddy controls are on the right; the room and reaction buttons are on the left.

**Where:** My world / Your buddy

### 02:13 - Change the shape and mood.

Try a color, a body shape, and an expression. Your choices appear immediately and save automatically.

**Where:** Your buddy / Color, shape, face

### 02:21 - Let your buddy wander.

Tap the floor to move Mochi. The buttons below the room add a little love, a funny face, or a hello.

**Where:** My world / Room floor and reactions

### 02:28 - Wrap them in your picture.

Scroll to Upload an image skin and choose a photo or pattern. PNG, JPG, and WebP images work.

**Where:** Your buddy / Upload an image skin

### 02:34 - Your image. Their little face.

The pattern becomes the body skin. The eyes, cheeks, and expression stay on top.

**Where:** Your buddy / Image skin preview

**Note:** Remove image skin returns to the selected body color.

### 02:40 - Dress up, or start a new look.

Your owned outfits are below the skin controls. Rebuild buddy resets appearance without deleting your collection or progress.

**Where:** Your buddy / Outfits and Rebuild buddy

### 02:51 - Good focus becomes good things.

The shop has four shelves: Outfits, Furniture, Pets, and Rooms. Everything is bought with cookies, not real money.

**Where:** Little shop / Category tabs

### 02:58 - A new friend, not a replacement.

On the Pets shelf, choose Bean the bunny and confirm Welcome home. Miso the cat stays in your family.

**Where:** Little shop / Pets / Bean the bunny

### 03:07 - Room for everyone.

Both pets appear together. In Friends, Rest hides a pet temporarily; Join brings them back without buying them again.

**Where:** My world / Friends

### 03:15 - Pick something cozy.

Back in Furniture, buy the Cloud-glow lamp. It goes into your collection, ready to place in a room.

**Where:** Little shop / Furniture / Cloud-glow lamp

### 03:26 - Bigger rooms cost more.

The free cookie nook is the smallest. Higher-priced rooms give you more space and their own distinct look.

**Where:** Little shop / Rooms

### 03:34 - Buy a room of its own.

Choose Moonbeam bedroom and confirm. You keep your other rooms and their furniture arrangements.

**Where:** Little shop / Moonbeam bedroom

### 03:45 - Same camera. More space.

Switch between The cookie nook and Moonbeam bedroom. The new room is larger, not a replacement for the old one.

**Where:** My world / Room tabs

### 03:55 - Place your new furniture.

Open Furniture and select the lamp to place it. Select the rug too; owned designs can be used once in each room.

**Where:** My world / Furniture

### 04:03 - Move it. Make it yours.

While editing, drag a piece to reposition it. The controls below the room let you resize, rotate, mirror, or put it away.

**Where:** Edit room / Selected furniture controls

### 04:15 - A different layout in every room.

Press Done editing when you are happy. Switch rooms freely; each arrangement saves automatically.

**Where:** Done editing / Room tabs

### 04:24 - Start with your own notes.

Study buddy has local chat on the left and study tools on the right. Edit these sample notes or import a text file.

**Where:** Study buddy / Your study notes

**Note:** The built-in study tools work without the AI model.

### 04:32 - Pull out the key points.

Key points selects important sentences from your notes. Save the result as text, or return to your study page.

**Where:** Your study notes / Key points

**Note:** This is a built-in tool, not a generated AI answer.

### 04:41 - Turn notes into practice.

Make cards builds a new fill-in-the-blank deck. Confirm only when you are ready to replace the current cards.

**Where:** Your study notes / Make cards

### 04:50 - Flip, edit, and quiz yourself.

Tap a card to reveal its answer. Add or edit your own cards, then use Quick quiz for a self-graded recall check.

**Where:** A little practice / Flashcards and Quick quiz

### 05:02 - Give your study time a shape.

Open Study plan, enter a topic and available minutes, then make a simple active-recall plan.

**Where:** Your study notes / Study plan

### 05:11 - Local AI needs its model first.

This package does not include the AI files. The setup help shows the one-time preparation commands; chat is not ready yet.

**Where:** Study buddy / Local AI setup

**Note:** Do not confuse the working study tools with generative AI.

### 05:21 - Prepare once. Then load locally.

After successful setup, return to Study buddy and select Load local AI. It needs a compatible WebGPU browser.

**Where:** Setup help / Then Load local AI

**Note:** Real AI inference is not demonstrated in this tutorial.

### 05:29 - See your little wins add up.

Your progress brings together focused minutes, your streak, a daily goal, and badges. All sessions opens the history.

**Where:** Your progress / Charts, badges, history

### 05:36 - Every session has a story.

The history shows finished and canceled sessions, with the focus time and cookies from each one.

**Where:** Your progress / All sessions

### 05:45 - Call it something you love.

Open Settings & your data. Rename the app, yourself, or your buddy, set your daily goal, and save your changes.

**Where:** Settings & your data / Profile form

### 05:53 - A little extra support.

Manage opens the parent controls. The sample PIN is 2468; set session rules, break limits, and optional downtime here.

**Where:** Settings / A little help from a parent

**Note:** These are local app settings, not operating-system restrictions.

### 06:03 - Keep your world safe.

Export backup saves your progress. Import backup restores it. Restore sample world and Erase my data both ask for confirmation.

**Where:** Settings / Your data stays yours

**Note:** Audio imports and AI model files are not included in backups.

### 06:11 - A gentler kind of motion.

Switch off A little movement for a calmer room. You can turn it back on whenever you like.

**Where:** Settings / Gentler by design

### 06:17 - The same tools, on your phone.

On a small screen, your main navigation moves to the bottom. Your avatar at the top opens settings.

**Where:** Mobile layout / Bottom tabs and top avatar

### 06:24 - A focus session in a few taps.

Tap Start focusing, choose your time, and begin. The planner and room controls adapt to the smaller screen.

**Where:** Today / Start focusing

### 06:33 - Start small. Come back to joy.

Make a little plan. Finish your pause. Spend your cookies on a world that feels like you.

**Where:** Start focusing / Your next little pause

**Note:** Your time. Your buddy. Your little world.
