# StockWise Inventory Assistant

Offline inventory, recipes, orders, and demand planning for a small kitchen. The included demo is **Harbor Bowl Kitchen**.

Open the folder with any static file server. From this folder:

```bash
python -m http.server 8000
```

Then visit the printed local address. No build step or package install is required. The WebLLM library is stored in `vendor/web-llm/`. The first time you choose **Load on-device model**, the browser downloads that model's weights and caches them for later offline answers. Inventory math, deliveries, colors, and email drafts work even before the model is loaded.

## What you can do

- Track ingredients, costs, suppliers, reorder points, and target stock.
- Define dishes as recipes and log customer orders. Saving an order deducts every ingredient.
- See which dishes customers order most and which weekdays are busiest.
- Estimate a 7-, 14-, or 30-day purchase list and its cost.
- Set the business name and the website color.
- Connect an email address and send or download an inventory report. The report opens in your mail app; StockWise does not upload it.
- Ask the assistant what any screen or number means. Tell it “I bought 5 kg of jasmine rice”, “Rename the business to …”, or “Change the website color to ocean”.
- When ingredients are low, a reminder offers **OK** or **Remind me later**. Remind me later shows again the next time you open StockWise.

Sample data includes 16 ingredients, 6 menu items, and eight weeks of lunch and dinner orders. Carrots, garlic, shrimp, and spring onions start low so the restock reminder and purchase plan are visible immediately. The sample mailbox is `mina@harborbowl.example`.
