/* Ballz domain logic. Pure functions shared by the UI and dependency-free tests. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.BallzCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const MINUTE = 60000;
  const MAX_MINUTES = 720;
  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
  const localDay = (value) => {
    const d = new Date(value);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  // Only whole ACTIVE minutes earn cookies. Breaks never advance the reward tier.
  // The brief does not define minute 21 onward; the second tier remains 1.5/min.
  function cookiesFor(focusMs) {
    const minutes = Math.max(0, Math.floor(focusMs / MINUTE + 1e-9));
    return Math.min(minutes, 10) + Math.max(0, minutes - 10) * 1.5;
  }

  function validatePlan(totalMinutes, breaks = [], parent = null) {
    if (!Number.isFinite(totalMinutes) || !Number.isInteger(totalMinutes) || totalMinutes < 1 || totalMinutes > MAX_MINUTES) {
      return { ok: false, error: 'Choose a whole-number duration from 1 to 720 minutes.' };
    }
    if (!Array.isArray(breaks) || breaks.length > 10) return { ok: false, error: 'You can add up to 10 breaks.' };
    if (parent && parent.enabled && totalMinutes < parent.minMinutes) {
      return { ok: false, error: `Parent settings require at least ${parent.minMinutes} minutes.` };
    }
    const sorted = breaks.map(b => ({ after: Number(b.after), duration: Number(b.duration) })).sort((a, b) => a.after - b.after);
    let previousEnd = 0;
    for (const b of sorted) {
      if (!Number.isInteger(b.after) || !Number.isInteger(b.duration) || b.after < 1 || b.duration < 1) {
        return { ok: false, error: 'Break start and length must be positive whole minutes.' };
      }
      if (b.duration > 60 || b.after + b.duration >= totalMinutes) {
        return { ok: false, error: 'Keep breaks at most 60 minutes, and leave at least 1 minute of focus afterward.' };
      }
      if (b.after < previousEnd) return { ok: false, error: 'Breaks cannot overlap. Move a break a little later.' };
      if (parent && parent.enabled && b.duration > parent.maxBreakMinutes) {
        return { ok: false, error: `Parent settings limit each break to ${parent.maxBreakMinutes} minutes.` };
      }
      previousEnd = b.after + b.duration;
    }
    const focusMinutes = totalMinutes - sorted.reduce((sum, b) => sum + b.duration, 0);
    return { ok: true, breaks: sorted, focusMinutes, cookies: cookiesFor(focusMinutes * MINUTE) };
  }

  function parseTime(value) {
    if (typeof value !== 'string' || !/^\d{2}:\d{2}$/.test(value)) return null;
    const [h, m] = value.split(':').map(Number);
    return h < 24 && m < 60 ? h * 60 + m : null;
  }

  // Start at the next occurrence of the selected local clock time; overnight works.
  function timeWindow(startValue, endValue, now = Date.now()) {
    const startMinutes = parseTime(startValue), endMinutes = parseTime(endValue);
    if (startMinutes === null || endMinutes === null) return { ok: false, error: 'Choose a valid start and end time.' };
    if (startMinutes === endMinutes) return { ok: false, error: 'Start and end times must be different.' };
    const start = new Date(now);
    start.setHours(Math.floor(startMinutes / 60), startMinutes % 60, 0, 0);
    if (start.getTime() < now) start.setDate(start.getDate() + 1);
    const end = new Date(start);
    end.setHours(Math.floor(endMinutes / 60), endMinutes % 60, 0, 0);
    if (end <= start) end.setDate(end.getDate() + 1);
    const totalMinutes = Math.round((end - start) / MINUTE);
    if (totalMinutes < 1 || totalMinutes > MAX_MINUTES) return { ok: false, error: 'Choose a time window of at most 12 hours.' };
    return { ok: true, startAt: start.getTime(), endAt: end.getTime(), totalMinutes };
  }

  function createSession({ minutes, breaks = [], recipe = 'classic', speed = 1, source = 'manual', startAt = Date.now(), scheduleKey = null }, now = Date.now()) {
    const valid = validatePlan(minutes, breaks);
    if (!valid.ok) throw new Error(valid.error);
    return {
      id: `session-${now}-${Math.random().toString(36).slice(2, 8)}`,
      createdAt: now, startAt, anchorAt: startAt, elapsedAtAnchor: 0,
      totalMs: minutes * MINUTE,
      breaks: valid.breaks.map(b => ({ startMs: b.after * MINUTE, durationMs: b.duration * MINUTE })),
      recipe, speed: [1, 60, 300].includes(speed) ? speed : 1, source, scheduleKey
    };
  }

  function progress(session, now = Date.now()) {
    const waiting = now < session.startAt && session.elapsedAtAnchor === 0;
    const elapsed = clamp(session.elapsedAtAnchor + Math.max(0, now - session.anchorAt) * session.speed, 0, session.totalMs);
    let breakMs = 0, currentBreak = null;
    for (const b of session.breaks) {
      breakMs += clamp(elapsed - b.startMs, 0, b.durationMs);
      if (elapsed >= b.startMs && elapsed < b.startMs + b.durationMs) currentBreak = b;
    }
    const focusMs = Math.max(0, elapsed - breakMs);
    const phase = waiting ? 'scheduled' : elapsed >= session.totalMs ? 'complete' : currentBreak ? 'break' : 'focus';
    const remaining = phase === 'scheduled' ? session.startAt - now : phase === 'break' ? currentBreak.startMs + currentBreak.durationMs - elapsed : session.totalMs - elapsed;
    const nextBreak = session.breaks.find(b => b.startMs > elapsed) || null;
    return { phase, elapsed, focusMs, breakMs, remaining, currentBreak, nextBreak, cookies: cookiesFor(focusMs), fraction: elapsed / session.totalMs };
  }

  // Re-anchoring preserves elapsed time instead of multiplying prior time by a new speed.
  function setSpeed(session, speed, now = Date.now()) {
    if (![1, 60, 300].includes(speed)) throw new Error('Unsupported preview speed.');
    if (now >= session.startAt || session.elapsedAtAnchor > 0) {
      session.elapsedAtAnchor = progress(session, now).elapsed;
      session.anchorAt = now;
    }
    session.speed = speed;
    return session;
  }
  function advance(session, milliseconds, now = Date.now()) {
    if (!Number.isFinite(milliseconds) || milliseconds < 0) throw new Error('Advance must be a nonnegative duration.');
    session.elapsedAtAnchor = clamp(progress(session, now).elapsed + milliseconds, 0, session.totalMs);
    session.startAt = Math.min(now, session.startAt);
    session.anchorAt = now;
    return session;
  }

  function streak(history, now = Date.now()) {
    const dates = new Set(history.filter(h => h.completed).map(h => localDay(h.endedAt)));
    const cursor = new Date(now);
    cursor.setHours(12, 0, 0, 0);
    if (!dates.has(localDay(cursor))) cursor.setDate(cursor.getDate() - 1);
    let count = 0;
    while (dates.has(localDay(cursor))) {
      count++;
      cursor.setDate(cursor.getDate() - 1);
    }
    return count;
  }

  // Return the currently active recurring window, including a window begun yesterday.
  function currentDowntime(parent, now = Date.now()) {
    if (!parent || !parent.enabled || !parent.scheduleEnabled) return null;
    const from = parseTime(parent.start), to = parseTime(parent.end);
    if (from === null || to === null || from === to) return null;
    for (const offset of [-1, 0]) {
      const start = new Date(now);
      start.setDate(start.getDate() + offset);
      start.setHours(Math.floor(from / 60), from % 60, 0, 0);
      const end = new Date(start);
      end.setHours(Math.floor(to / 60), to % 60, 0, 0);
      if (end <= start) end.setDate(end.getDate() + 1);
      if (now >= start.getTime() && now < end.getTime()) return { startAt: +start, endAt: +end, key: `${localDay(start)}@${parent.start}-${parent.end}` };
    }
    return null;
  }

  function purchase(wallet, owned, item) {
    if (!item || !Number.isFinite(item.price) || item.price < 0) return { ok: false, error: 'That item is unavailable.' };
    if (owned.includes(item.id)) return { ok: false, error: 'This is already in your little collection.' };
    if (wallet < item.price) return { ok: false, error: `You need ${item.price - wallet} more cookies.` };
    return { ok: true, wallet: wallet - item.price, owned: [...owned, item.id] };
  }

  function weekly(history, now = Date.now()) {
    return Array.from({ length: 7 }, (_, i) => {
      const date = new Date(now); date.setDate(date.getDate() - 6 + i); date.setHours(12, 0, 0, 0);
      const key = localDay(date);
      return { key, date: +date, minutes: history.filter(h => h.completed && localDay(h.endedAt) === key).reduce((sum, h) => sum + h.focusMs / MINUTE, 0) };
    });
  }

  return { MINUTE, MAX_MINUTES, clamp, localDay, cookiesFor, validatePlan, parseTime, timeWindow, createSession, progress, setSpeed, advance, streak, currentDowntime, purchase, weekly };
});
