# Third-party sources and assets

The delivered application UI, SVG illustrations and synthesized soundscapes use
no external libraries, fonts, images or audio recordings. Timer logic is retained
from the user's uploaded application. Artist/song names are inspiration labels;
recordings are not included. Import only audio you are entitled to use.

## Optional, requested AI dependency

The following are fetched by `prepare_ai.py`, not included in the delivered ZIP:

- WebLLM `@mlc-ai/web-llm@0.2.86`, prebuilt npm distribution, Apache-2.0 project.
  Official source: https://github.com/mlc-ai/web-llm
  Release: https://github.com/mlc-ai/web-llm/releases/tag/v0.2.86
  Documentation: https://webllm.mlc.ai/docs/
  npm package metadata: https://registry.npmjs.org/@mlc-ai%2fweb-llm/0.2.86
- Quantized model: https://huggingface.co/mlc-ai/SmolLM2-360M-Instruct-q4f32_1-MLC
  Base model: https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct
  The installer records the exact repository commit used. Consult the upstream
  model card and license before redistributing the prepared weights.
- Matching prebuilt library:
  https://github.com/mlc-ai/binary-mlc-llm-libs/tree/main/web-llm-models/v0_2_86/base

The setup script preserves the runtime license and package metadata and any
license/model-card files present in the model repository. Do not remove applicable
upstream license notices when redistributing a prepared package. WebLLM's bundled
runtime has its own dependencies; it is not original application code.

The optional browser test script uses Playwright on the test machine. Playwright
is NOT a dependency of the web app and is not bundled into it.
