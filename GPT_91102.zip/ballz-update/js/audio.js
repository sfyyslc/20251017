/* Original synthesized soundscapes and locally imported music, focus-only. */
(() => {
  'use strict';
  let allowed=()=>false, ctx=null, bus=null, nodes=[], interval=null, current=null, volume=.22, db=null, objectURL=null, epoch=0;
  const audio=()=>document.getElementById('local-audio');
  const notify=()=>window.dispatchEvent(new CustomEvent('music-change'));
  async function database(){
    if(db)return db;
    if(!window.indexedDB)throw Error('This browser cannot save audio files locally.');
    db=await new Promise((resolve,reject)=>{const req=indexedDB.open('ballz-local-audio',1);req.onupgradeneeded=()=>req.result.createObjectStore('tracks',{keyPath:'id'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});return db;
  }
  async function store(mode,action){const d=await database();return new Promise((resolve,reject)=>{const tx=d.transaction('tracks',mode),req=action(tx.objectStore('tracks'));let result;req.onsuccess=()=>{result=req.result;};req.onerror=()=>reject(req.error);tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error);});}
  function stop(){epoch++;if(interval){clearInterval(interval);interval=null;}nodes.forEach(n=>{try{n.stop?.();n.disconnect?.();}catch{}});nodes=[];if(bus){try{bus.disconnect();}catch{}bus=null;}const a=audio();a.pause();a.removeAttribute('src');a.load();if(objectURL){URL.revokeObjectURL(objectURL);objectURL=null;}current=null;if(ctx&&ctx.state==='running')ctx.suspend().catch(()=>{});notify();}
  async function start(id){
    if(!allowed())throw Error('Music is only available during a focus session.');
    if(current===id){stop();return;}
    stop();const token=epoch;
    const AudioCtx=window.AudioContext||window.webkitAudioContext;if(!AudioCtx)throw Error('This browser does not support local soundscapes.');
    ctx=ctx||new AudioCtx();await ctx.resume();if(token!==epoch||!allowed()){return;}
    bus=ctx.createGain();bus.gain.value=volume;bus.connect(ctx.destination);current=id;
    if(id==='rain'||id==='hush'||id==='cafe'){
      const len=ctx.sampleRate*3,buffer=ctx.createBuffer(1,len,ctx.sampleRate),data=buffer.getChannelData(0);let last=0;
      for(let i=0;i<len;i++){const white=Math.random()*2-1;last=(last+.02*white)/1.02;data[i]=id==='rain'?white*.12:last*1.7;}
      const src=ctx.createBufferSource();src.buffer=buffer;src.loop=true;
      const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=id==='rain'?1300:id==='cafe'?550:300;src.connect(filter);filter.connect(bus);src.start();nodes.push(src,filter);
    }
    if(id==='chimes'||id==='cafe'){
      const tones=[261.63,329.63,392,523.25,659.25], plink=()=>{if(!allowed()){stop();return;}const o=ctx.createOscillator(),g=ctx.createGain();o.type='sine';o.frequency.value=tones[Math.floor(Math.random()*tones.length)];g.gain.setValueAtTime(.0001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(id==='cafe'?.08:.16,ctx.currentTime+.08);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+3);o.connect(g);g.connect(bus);o.start();o.stop(ctx.currentTime+3.1);nodes.push(o,g);o.onended=()=>{o.disconnect();g.disconnect();nodes=nodes.filter(n=>n!==o&&n!==g);};};plink();interval=setInterval(plink,id==='cafe'?6500:4200);
    }
    notify();
  }
  async function importTrack(file,name){if(!allowed())throw Error('Start a focus session before adding music.');if(file.size>25*1024*1024)throw Error('Please choose an audio file smaller than 25 MB.');if(!file.type.startsWith('audio/')&&!/\.(mp3|m4a|ogg|wav|flac|aac)$/i.test(file.name))throw Error('Choose an MP3, M4A, OGG or WAV audio file.');const track={id:`track-${Date.now()}`,name:(name||file.name).slice(0,120),blob:file};await store('readwrite',s=>s.put(track));return track;}
  async function playLocal(id){if(!allowed())throw Error('Music is only available during focus.');if(current===id){stop();return;}stop();const token=epoch;const track=await store('readonly',s=>s.get(id));if(!track)throw Error('This audio file could not be found.');if(token!==epoch||!allowed())return;objectURL=URL.createObjectURL(track.blob);const a=audio();a.src=objectURL;a.volume=volume;await a.play();if(token!==epoch||!allowed()){stop();return;}current=id;a.onended=()=>stop();notify();}
  function setVolume(v){volume=Math.max(0,Math.min(1,Number(v)));if(bus&&ctx)bus.gain.setTargetAtTime(volume,ctx.currentTime,.05);audio().volume=volume;}
  window.BallzAudio={configure(fn,v){allowed=fn;setVolume(v);},start,stop,importTrack,playLocal,setVolume,get current(){return current;},get volume(){return volume;},async tracks(){try{return(await store('readonly',s=>s.getAll())).map(t=>({id:t.id,name:t.name}));}catch{return[];}},async remove(id){if(current===id)stop();await store('readwrite',s=>s.delete(id));},async clear(){stop();await store('readwrite',s=>s.clear());}};
})();
