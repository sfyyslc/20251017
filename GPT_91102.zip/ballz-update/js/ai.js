/* The actual AI bridge. All runtime, WASM and weights MUST be same-origin. */
const ROOT=new URL('../',import.meta.url);
let worker=null, pending=new Map(), seq=0, ready=false, loading=false, status={phase:'unchecked',text:'Local AI has not been loaded.'};
const emit=(phase,text,progress=0)=>{status={phase,text,progress};window.dispatchEvent(new CustomEvent('ai-status',{detail:status}));};
function rpc(type,payload={}){return new Promise((resolve,reject)=>{if(!worker){reject(Error('Load the local model first.'));return;}const id=++seq;const timeout=setTimeout(()=>{pending.delete(id);reject(Error('The local model took too long. Cancel and retry on a device with more available GPU memory.'));},type==='load'?300000:180000);pending.set(id,{resolve,reject,timeout});worker.postMessage({id,type,...payload});});}
async function check(){
  try{const response=await fetch(new URL('model-status.json',ROOT),{cache:'no-store'});if(!response.ok)throw Error('Model setup status is unavailable.');const manifest=await response.json();
    if(!manifest.ready){emit('missing','Model files are not installed. Run the one-time preparation script before using AI.');return false;}
    if(!window.isSecureContext||!navigator.gpu){emit('unsupported','AI needs a WebGPU-capable browser on localhost or HTTPS. The built-in study tools still work.');return false;}
    const adapter=await navigator.gpu.requestAdapter();if(!adapter){emit('unsupported','No compatible GPU was found. Use the built-in study tools or try a WebGPU-capable device.');return false;}
    emit('available','Model files are on this device. Load the local assistant when you need it.');return true;
  }catch(error){emit('error',error.message);return false;}
}
async function load(){
  if(ready)return;if(loading)return;loading=true;
  try{if(!await check())return;emit('loading','Preparing your local study buddy...',0);
    worker=new Worker(new URL('ai-worker.js',import.meta.url),{type:'module'});
    worker.onmessage=({data})=>{if(data.type==='progress'){emit('loading',data.text,data.progress);return;}if(data.type==='token'){window.dispatchEvent(new CustomEvent('ai-token',{detail:data.text}));return;}const p=pending.get(data.id);if(p){clearTimeout(p.timeout);pending.delete(data.id);data.error?p.reject(Error(data.error)):p.resolve(data.result);}};
    worker.onerror=e=>{const error=Error(e.message||'The AI worker could not start.');for(const p of pending.values()){clearTimeout(p.timeout);p.reject(error);}pending.clear();ready=false;loading=false;emit('error',error.message);worker?.terminate();worker=null;};
    await rpc('load',{root:ROOT.href});ready=true;emit('ready','Ready. Your questions and notes stay in this browser.');
  }catch(error){worker?.terminate();worker=null;ready=false;emit('error',error.message);}finally{loading=false;}
}
async function generate(messages,notes){if(!ready)throw Error('Load the local model before sending a question.');emit('generating','Thinking locally...');try{const text=await rpc('generate',{messages,notes});emit('ready','Ready. Your questions and notes stay in this browser.');return text;}catch(e){emit('error',e.message);throw e;}}
function stop(){if(worker)worker.postMessage({type:'stop'});}
function unload(){stop();worker?.terminate();worker=null;ready=false;loading=false;for(const p of pending.values()){clearTimeout(p.timeout);p.reject(Error('Local AI was unloaded.'));}pending.clear();emit('available','Model unloaded to free GPU memory. Your notes are saved.');}
window.BallzAI={check,load,generate,stop,unload,get ready(){return ready;},get loading(){return loading;},get status(){return status;}};
window.dispatchEvent(new CustomEvent('ai-available'));
