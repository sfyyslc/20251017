/* Local domain data, backup validation and v1 migration. No network access. */
(() => {
  'use strict';
  const C = window.BallzCore;
  const COLORS = [
    ['#F9E6C5','Vanilla bean'],['#EDB7A9','Peach milk'],['#C2CCAA','Matcha mochi'],
    ['#C7BBDD','Lavender cloud'],['#B6CFD5','Blueberry milk'],['#DCADBE','Strawberry cream'],
    ['#BFA18C','Cocoa puff'],['#F5D477','Lemon drop'],['#FCFAF1','Marshmallow'],['#B9BAC9','Moon pebble']
  ];
  const FACES = [['smile','Happy'],['wink','Wink'],['sleepy','Sleepy'],['love','Loved'],['wow','Amazed'],['grin','Giggly'],['determined','Determined'],['blush','Shy']];
  const RECIPES = [
    {id:'classic',name:'Chocolate chip',note:'The comfort classic.',symbol:'cookie'},
    {id:'star',name:'Little stars',note:'A batch of tiny wishes.',symbol:'star'},
    {id:'heart',name:'Sweetheart bites',note:'Baked with extra love.',symbol:'heart'},
    {id:'matcha',name:'Matcha clouds',note:'A gentle green daydream.',symbol:'leaf'},
    {id:'lemon',name:'Lemon sunshine',note:'A little golden goodness.',symbol:'sun'}
  ];
  const CATALOG = [
    {id:'bow',category:'outfits',name:'Strawberry bow',price:35,note:'A very sweet finishing touch.',color:'#EDC1B3'},
    {id:'beret',category:'outfits',name:'Lilac beret',price:45,note:'For your tiny art-school era.',color:'#D9D0E4'},
    {id:'scarf',category:'outfits',name:'Sunday scarf',price:50,note:'Cozy is a whole personality.',color:'#F1D7AA'},
    {id:'flower',category:'outfits',name:'Daisy daydream',price:55,note:'A flower behind a not-quite-ear.',color:'#E5E7C3'},
    {id:'glasses',category:'outfits',name:'Bookworm glasses',price:60,note:'Looking studious. Feeling cute.',color:'#CCD9D1'},
    {id:'overalls',category:'outfits',name:'Sunday overalls',price:70,note:'Little pockets for big plans.',color:'#C6D6DF'},
    {id:'chef',category:'outfits',name:'Head baker',price:80,note:'Officially in charge of cookies.',color:'#EAE4D6'},
    {id:'beanie',category:'outfits',name:'Sleepy beanie',price:85,note:'A tiny cloud for your head.',color:'#DAC9DB'},
    {id:'crown',category:'outfits',name:'Cookie royalty',price:110,note:'A crown for your small wins.',color:'#EFDBA3'},
    {id:'wizard',category:'outfits',name:'Moonlight wizard',price:130,note:'Making distractions disappear.',color:'#C9CBE1'},
    {id:'plant',category:'furniture',name:'Leafy little friend',price:30,note:'Happiest in a sunny corner.',w:88,h:115,color:'#D7E0C7'},
    {id:'rug',category:'furniture',name:'Marshmallow rug',price:40,note:'A soft place to just be.',w:220,h:64,color:'#DED0E0'},
    {id:'lamp',category:'furniture',name:'Cloud-glow lamp',price:55,note:'Your own little golden hour.',w:72,h:142,color:'#F1DFAA'},
    {id:'books',category:'furniture',name:'One more chapter',price:65,note:'A stack of little adventures.',w:78,h:70,color:'#CFD3E2'},
    {id:'cushion',category:'furniture',name:'Peachy floor cushion',price:70,note:'Reserved for doing nothing.',w:116,h:59,color:'#EBC6B7'},
    {id:'desk',category:'furniture',name:'Little writing desk',price:85,note:'Room for your next big idea.',w:158,h:108,color:'#E0C9AB'},
    {id:'oven',category:'furniture',name:'Sage cookie oven',price:90,note:'The warmest heart of the home.',w:120,h:112,color:'#CDDAC6'},
    {id:'shelf',category:'furniture',name:'Storybook shelf',price:110,note:'For all your favorite worlds.',w:118,h:163,color:'#DFCFB7'},
    {id:'aquarium',category:'furniture',name:'Pocket ocean',price:130,note:'Some very unbothered fish.',w:135,h:101,color:'#C2D9DC'},
    {id:'sofa',category:'furniture',name:'Cloud-nine sofa',price:150,note:'A seat for you and a friend.',w:191,h:111,color:'#CDD4B8'},
    {id:'bed',category:'furniture',name:'Moonbeam bed',price:180,note:'Where little daydreams land.',w:170,h:128,color:'#D1CBE0'},
    {id:'piano',category:'furniture',name:'Tiny upright piano',price:220,note:'Quietly waiting for a melody.',w:148,h:147,color:'#D5B9A0'},
    {id:'cat',category:'pets',name:'Miso the cat',price:90,note:'Expert napper. Amateur baker.',color:'#E8D6BB'},
    {id:'bunny',category:'pets',name:'Bean the bunny',price:120,note:'A very good listener.',color:'#EBD6D8'},
    {id:'dog',category:'pets',name:'Noodle the pup',price:150,note:'Every day is the best day.',color:'#D9C5AF'},
    {id:'frog',category:'pets',name:'Pip the frog',price:175,note:'Small hops, big encouragement.',color:'#CDDDB8'},
    {id:'duck',category:'pets',name:'Puddle the duck',price:195,note:'Always down for a little waddle.',color:'#EFDFAC'},
    {id:'fox',category:'pets',name:'Clover the fox',price:230,note:'The softest study sidekick.',color:'#E3BA9F'},
    {id:'kitchen',category:'rooms',name:'The cookie nook',price:0,note:'Small beginnings. Big comfort.',w:580,h:330,area:'4 \u00d7 3 m',wall:'#EFE5D0',floor:'#D9C5A3',color:'#EADBC0'},
    {id:'sunroom',category:'rooms',name:'Sunday sunroom',price:180,note:'A little more room to bloom.',w:660,h:375,area:'6 \u00d7 4 m',wall:'#E6E8D4',floor:'#CFD2AE',color:'#DDE2C6'},
    {id:'moonroom',category:'rooms',name:'Moonbeam bedroom',price:260,note:'A spacious, sleepy sanctuary.',w:740,h:420,area:'7 \u00d7 5 m',wall:'#E0DCEB',floor:'#C7B7D2',color:'#DDD6E8'},
    {id:'loft',category:'rooms',name:'The artist loft',price:380,note:'Wide-open space for new ideas.',w:820,h:465,area:'8 \u00d7 6 m',wall:'#EADBD1',floor:'#D6B79B',color:'#E9D5C8'},
    {id:'greenhouse',category:'rooms',name:'Garden glasshouse',price:520,note:'More sunshine per square foot.',w:890,h:505,area:'10 \u00d7 7 m',wall:'#DDE6D6',floor:'#BFCBAA',color:'#D4E1CB'},
    {id:'cottage',category:'rooms',name:'Cloudberry cottage',price:750,note:'Your biggest little home yet.',w:960,h:545,area:'12 \u00d7 9 m',wall:'#E8DEC9',floor:'#CEB391',color:'#E6D6B8'}
  ];
  const item = id => CATALOG.find(i => i.id === id);
  const recipe = id => RECIPES.find(i => i.id === id) || RECIPES[0];
  const uid = prefix => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
  const num = (n,min,max,fallback) => typeof n === 'number' && Number.isFinite(n) && n >= min && n <= max ? n : fallback;
  const text = (v,fallback='',max=60) => typeof v === 'string' && v.trim() ? v.trim().slice(0,max) : fallback;
  const image = v => typeof v === 'string' && v.length <= 1700000 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v) ? v : null;
  const defaultPlacement = (id,room,index=0) => {
    const r = item(room), it = item(id);
    return {id, x: id === 'rug' ? r.w*.49 : id === 'plant' ? r.w*.15 : r.w*(.25+(index%4)*.17), y:id === 'rug'?r.h*.87:r.h*.87, scale:1, rotation:0, flip:false};
  };
  function seed() {
    const now=Date.now();
    const past=(days,hour) => {const d=new Date(now);d.setDate(d.getDate()-days);d.setHours(hour,0,0,0);return +d>now?now-30*C.MINUTE:+d;};
    const history = [[0,9,25,'classic','Biology: cell structures'],[1,16,40,'star','One chapter at a time'],[1,10,20,'classic','A little maths practice'],[2,15,30,'heart','Room to think'],[4,11,45,'classic','The afternoon reset']].map(([days,hour,m,r,label],i)=>({id:`sample-${i}`,endedAt:past(days,hour),totalMs:m*C.MINUTE,focusMs:m*C.MINUTE,cookies:C.cookiesFor(m*C.MINUTE),recipe:r,completed:true,source:'sample',label}));
    const ledger=history.map(e=>({id:`reward-${e.id}`,at:e.endedAt,amount:e.cookies,label:e.label}));
    ledger.push({id:'welcome',at:past(5,10),amount:530,label:'Welcome gift (sample world)'},...['beret','rug','cat','sunroom'].map((id,i)=>({id:`buy-${id}`,at:past(3,12+i),amount:-item(id).price,label:item(id).name})));
    return {version:2,revision:0,profile:{name:'Olivia',ballName:'Mochi',appName:'ballz',dailyGoal:60},wallet:390,
      owned:['kitchen','sunroom','plant','rug','beret','cat'],
      custom:{color:COLORS[0][0],face:'smile',shape:'round',skin:null,outfit:'beret',room:'kitchen',pets:['cat'],layouts:{kitchen:[defaultPlacement('rug','kitchen'),defaultPlacement('plant','kitchen')],sunroom:[defaultPlacement('plant','sunroom')]},positions:{}},
      history,ledger:ledger.sort((a,b)=>b.at-a.at),active:null,stats:{completed:5,totalFocusMs:160*C.MINUTE,lifetimeCookies:215,longestFocusMs:45*C.MINUTE,bestStreak:3,batches:{classic:3,star:1,heart:1,matcha:0,lemon:0}},
      settings:{speed:1,volume:.22,motion:true,sampleMode:true},
      parent:{enabled:false,pin:'2468',minMinutes:15,maxBreakMinutes:5,scheduleEnabled:false,start:'19:00',end:'20:00',blocked:['social','video','games','messages','browser'],handledWindows:[]},
      gallery:[],study:{notes:'Biology - Cell structures\n\nThe nucleus stores DNA and controls cell activities.\nMitochondria release energy through aerobic respiration.\nThe cell membrane controls what enters and leaves a cell.\nRibosomes make proteins.\nPlant cells have a cellulose cell wall, chloroplasts and a permanent vacuole.\nChloroplasts absorb light energy for photosynthesis.',cards:[{q:'Which cell structure contains DNA?',a:'The nucleus.'},{q:'What do ribosomes make?',a:'Proteins.'},{q:'Name three structures found in typical plant cells but not animal cells.',a:'A cellulose cell wall, chloroplasts and a permanent vacuole.'}],messages:[]}};
  }
  function normalize(raw) {
    if(!raw || ![1,2].includes(raw.version) || !raw.profile || !raw.stats || !Array.isArray(raw.owned) || !Array.isArray(raw.history)) throw Error('This is not a supported app backup.');
    if(!Number.isFinite(raw.wallet)||raw.wallet<0||raw.wallet>1e8) throw Error('The saved cookie balance is invalid.');
    const v1=raw.version===1, b=raw.custom||{}, s=seed(), owned=[...new Set(['kitchen',...raw.owned.filter(id=>item(id))])];
    const isOwned=(id,cat)=>owned.includes(id)&&item(id)?.category===cat;
    const layouts={},positions={};
    for(const r of CATALOG.filter(i=>i.category==='rooms')) {
      const source=v1?(b.decor?.[r.id]||[]).map((id,i)=>defaultPlacement(id,r.id,i)):b.layouts?.[r.id];
      const seen=new Set();
      layouts[r.id]=(Array.isArray(source)?source:[]).filter(p=>p&&isOwned(p.id,'furniture')&&!seen.has(p.id)&&seen.add(p.id)).slice(0,30).map(p=>({id:p.id,x:num(p.x,20,r.w-20,r.w/2),y:num(p.y,r.h*.62,r.h*.96,r.h*.86),scale:num(p.scale,.6,1.5,1),rotation:num(p.rotation,-180,180,0),flip:!!p.flip}));
      positions[r.id]={x:num(b.positions?.[r.id]?.x,60,r.w-60,r.w*.48),y:num(b.positions?.[r.id]?.y,r.h*.7,r.h*.96,r.h*.89)};
    }
    const history=raw.history.slice(0,500).filter(e=>e&&typeof e.id==='string'&&Number.isFinite(e.endedAt)&&e.endedAt>0&&Number.isFinite(e.focusMs)&&e.focusMs>=0&&e.focusMs<=720*C.MINUTE).map(e=>({id:text(e.id,uid('history'),80),endedAt:e.endedAt,totalMs:num(e.totalMs,e.focusMs,720*C.MINUTE,e.focusMs),focusMs:e.focusMs,cookies:e.completed?C.cookiesFor(e.focusMs):0,recipe:recipe(e.recipe).id,completed:!!e.completed,source:['manual','parent','sample'].includes(e.source)?e.source:'manual',label:text(e.label,'A little focus',80)}));
    let active=null;
    if(raw.active) {
      const a=raw.active;
      if(!Array.isArray(a.breaks)||!Number.isFinite(a.totalMs)||a.totalMs<C.MINUTE||a.totalMs>720*C.MINUTE||!Number.isFinite(a.startAt)||a.startAt<0||!Number.isFinite(a.anchorAt)||a.anchorAt<0||!Number.isFinite(a.elapsedAtAnchor)||a.elapsedAtAnchor<0||a.elapsedAtAnchor>a.totalMs||![1,60,300].includes(a.speed)) throw Error('The saved focus session is invalid.');
      const plan=C.validatePlan(a.totalMs/C.MINUTE,a.breaks.map(b=>({after:b.startMs/C.MINUTE,duration:b.durationMs/C.MINUTE})));
      if(!plan.ok) throw Error('The saved breaks are invalid.');
      active={id:text(a.id,uid('session'),80),createdAt:num(a.createdAt,0,9e15,Date.now()),startAt:a.startAt,anchorAt:a.anchorAt,elapsedAtAnchor:a.elapsedAtAnchor,totalMs:a.totalMs,speed:a.speed,recipe:recipe(a.recipe).id,breaks:plan.breaks.map(b=>({startMs:b.after*C.MINUTE,durationMs:b.duration*C.MINUTE})),source:a.source==='parent'?'parent':'manual',scheduleKey:text(a.scheduleKey,'',80),label:text(a.label,'A little focus',80)};
    }
    const p=raw.parent||{}, from=C.parseTime(p.start),to=C.parseTime(p.end);
    const validWindow=from!==null&&to!==null&&from!==to&&((to-from+1440)%1440)<=720;
    s.profile={name:text(raw.profile.name,'Olivia',24),ballName:text(raw.profile.ballName,'Mochi',20),appName:text(raw.profile.appName,'ballz',28),dailyGoal:Math.round(num(raw.profile.dailyGoal,5,720,60))};
    s.wallet=Math.round(raw.wallet*2)/2;s.revision=num(raw.revision,0,1e12,0);s.owned=owned;
    s.custom={color:/^#[A-Fa-f0-9]{6}$/.test(b.color)?b.color:COLORS[0][0],face:FACES.some(f=>f[0]===b.face)?b.face:'smile',shape:['round','dumpling','cloud'].includes(b.shape)?b.shape:'round',skin:image(v1?b.faceData:b.skin),outfit:isOwned(b.outfit,'outfits')?b.outfit:null,room:isOwned(b.room,'rooms')?b.room:'kitchen',pets:[...new Set((v1?owned.filter(id=>item(id).category==='pets'):(Array.isArray(b.pets)?b.pets:[])).filter(id=>isOwned(id,'pets')))],layouts,positions};
    s.history=history;s.active=active;
    s.ledger=(Array.isArray(raw.ledger)?raw.ledger:[]).slice(0,500).filter(e=>e&&Number.isFinite(e.amount)&&Math.abs(e.amount)<=1e8&&Number.isFinite(e.at)).map(e=>({id:text(e.id,uid('ledger'),80),at:e.at,amount:e.amount,label:text(e.label,'Cookie jar',80)}));
    s.stats={completed:Math.floor(num(raw.stats.completed,0,1e7,0)),totalFocusMs:num(raw.stats.totalFocusMs,0,1e14,0),lifetimeCookies:num(raw.stats.lifetimeCookies,0,1e9,0),longestFocusMs:num(raw.stats.longestFocusMs,0,720*C.MINUTE,0),bestStreak:Math.floor(num(raw.stats.bestStreak,0,1e6,0)),batches:Object.fromEntries(RECIPES.map(r=>[r.id,Math.floor(num(raw.stats.batches?.[r.id],0,1e6,0))]))};
    s.settings={speed:[1,60,300].includes(raw.settings?.speed)?raw.settings.speed:1,volume:num(raw.settings?.volume,0,1,.22),motion:raw.settings?.motion!==false,sampleMode:raw.settings?.sampleMode!==false};
    s.parent={enabled:!!p.enabled,pin:/^\d{4}$/.test(String(p.pin))?String(p.pin):'2468',minMinutes:Math.round(num(p.minMinutes,1,720,15)),maxBreakMinutes:Math.round(num(p.maxBreakMinutes,0,60,5)),scheduleEnabled:!!p.scheduleEnabled&&validWindow,start:validWindow?p.start:'19:00',end:validWindow?p.end:'20:00',blocked:(Array.isArray(p.blocked)?p.blocked:s.parent.blocked).filter(id=>['social','video','games','messages','browser'].includes(id)),handledWindows:(Array.isArray(p.handledWindows)?p.handledWindows:[]).filter(k=>typeof k==='string').slice(-30)};
    s.gallery=(Array.isArray(raw.gallery)?raw.gallery:[]).slice(0,8).filter(p=>p&&image(p.data)).map(p=>({id:text(p.id,uid('photo'),80),at:num(p.at,0,9e15,Date.now()),title:text(p.title,'A little moment',60),data:p.data}));
    const study=raw.study||{};
    s.study={notes:typeof study.notes==='string'?study.notes.slice(0,12000):s.study.notes,cards:(Array.isArray(study.cards)?study.cards:s.study.cards).slice(0,50).filter(c=>c&&typeof c.q==='string'&&typeof c.a==='string').map(c=>({q:text(c.q,'Question',300),a:text(c.a,'Answer',1200)})),messages:(Array.isArray(study.messages)?study.messages:[]).slice(-20).filter(m=>m&&['user','assistant'].includes(m.role)&&typeof m.content==='string').map(m=>({role:m.role,content:m.content.slice(0,8000)}))};
    return s;
  }
  const BADGES=[
    {id:'first',name:'First batch',icon:'cookie',note:'Finish one focus session.',test:s=>s.stats.completed>=1},
    {id:'hour',name:'Golden hour',icon:'sun',note:'Focus for 60 minutes in total.',test:s=>s.stats.totalFocusMs>=60*C.MINUTE},
    {id:'roll',name:'On a roll',icon:'flame',note:'Build a 3-day focus streak.',test:s=>s.stats.bestStreak>=3},
    {id:'collector',name:'Cookie collector',icon:'bag',note:'Earn 100 cookies by focusing.',test:s=>s.stats.lifetimeCookies>=100},
    {id:'friends',name:'Better together',icon:'heart',note:'Adopt two different pets.',test:s=>s.owned.filter(id=>item(id)?.category==='pets').length>=2},
    {id:'rooms',name:'Room to grow',icon:'home',note:'Own two different rooms.',test:s=>s.owned.filter(id=>item(id)?.category==='rooms').length>=2},
    {id:'deep',name:'Deep diver',icon:'moon',note:'Complete 90 active focus minutes at once.',test:s=>s.stats.longestFocusMs>=90*C.MINUTE},
    {id:'week',name:'Seven little days',icon:'star',note:'Reach a 7-day focus streak.',test:s=>s.stats.bestStreak>=7},
    {id:'decorator',name:'Home sweet home',icon:'plant',note:'Collect six furniture pieces.',test:s=>s.owned.filter(id=>item(id)?.category==='furniture').length>=6},
    {id:'hundred',name:'A life well lived',icon:'leaf',note:'Focus for 100 hours in total.',test:s=>s.stats.totalFocusMs>=6000*C.MINUTE}
  ];
  window.BallzData={COLORS,FACES,RECIPES,CATALOG,BADGES,item,recipe,seed,normalize,defaultPlacement,uid,image};
})();
