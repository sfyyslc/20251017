#!/usr/bin/env python3
"""Prepare the real, same-origin WebLLM assistant using Python's standard library.

Run once WITH internet, BEFORE serving the app. No npm, pip, build, or API key.
Run --verify WITHOUT internet to check every installed file against its SHA-256.
The app never downloads model assets from a CDN; this is a separate setup step.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tarfile
import tempfile
import time
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

VERSION = "0.2.86"
MODEL = "SmolLM2-360M-Instruct-q4f32_1-MLC"
REPO = "mlc-ai/" + MODEL
WASM = ("https://raw.githubusercontent.com/mlc-ai/binary-mlc-llm-libs/"
        "main/web-llm-models/v0_2_86/base/"
        "SmolLM2-360M-Instruct-q4f32_1_cs1k-webgpu.wasm")
ROOT = Path(__file__).resolve().parent
STATUS = ROOT / "model-status.json"
MANIFEST = ROOT / "ai-files-manifest.json"
TIMEOUT = 120


def digest(path: Path, algorithm: str = "sha256") -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".part")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def request(url: str):
    return urllib.request.urlopen(urllib.request.Request(url, headers={
        "User-Agent": "LittleFocusClub-LocalAI-Setup/2.0",
        "Accept": "*/*", "Accept-Encoding": "identity",
    }), timeout=TIMEOUT)


def get_json(url: str) -> Any:
    with request(url) as response:
        return json.load(response)


def safe_name(name: str) -> str:
    # Remote cache metadata is data, never a filesystem path to trust.
    pure = PurePosixPath(name)
    if not name or name == "." or ":" in name or pure.is_absolute() or ".." in pure.parts or "\\" in name:
        raise ValueError("Unsafe remote filename: " + name)
    if any(part in (".", "") for part in pure.parts):
        raise ValueError("Invalid remote filename: " + name)
    return pure.as_posix()


def download(url: str, target: Path, expected_size: int | None = None,
             expected_sha256: str | None = None) -> None:
    """Stream to an atomic temporary file; reuse only a fully verified download."""
    if target.is_file() and expected_sha256 and digest(target) == expected_sha256:
        print("  Verified existing", target.name)
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".part")
    for attempt in range(1, 4):
        try:
            print("  Downloading", target.name, flush=True)
            with request(url) as response, temporary.open("wb") as output:
                length = response.headers.get("Content-Length")
                total = int(length) if length and length.isdigit() else None
                written = 0
                next_progress = 16 * 1024 * 1024
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    output.write(block)
                    written += len(block)
                    if written >= next_progress:
                        suffix = f" / {total / 1e6:.1f} MB" if total else " MB"
                        print(f"    {written / 1e6:.1f}" + suffix, flush=True)
                        next_progress += 16 * 1024 * 1024
            if not written or (total is not None and written != total):
                raise ValueError("Incomplete download: " + target.name)
            if expected_size is not None and written != expected_size:
                raise ValueError(f"Size mismatch for {target.name}: {written} != {expected_size}")
            if expected_sha256 and digest(temporary) != expected_sha256:
                raise ValueError("SHA-256 mismatch: " + target.name)
            os.replace(temporary, target)
            return
        except (OSError, ValueError, urllib.error.URLError) as error:
            temporary.unlink(missing_ok=True)
            if attempt == 3:
                raise RuntimeError(f"Could not obtain {target.name}: {error}") from error
            print(f"    Attempt {attempt} failed. Retrying...")
            time.sleep(attempt * 2)


def unpack_runtime(archive: Path, destination: Path) -> list[Path]:
    files = []
    with tarfile.open(archive, "r:gz") as package:
        for member in package.getmembers():
            # A bundled npm release is used AS IS; no npm install or JS build.
            if member.name.startswith("package/lib/"):
                relative = member.name.removeprefix("package/lib/")
                if not relative or member.isdir() or relative.endswith((".map", ".d.ts")):
                    continue
                output = destination / safe_name(relative)
            elif member.name in ("package/LICENSE", "package/LICENSE.md", "package/LICENSE.txt"):
                output = destination / "LICENSE"
            elif member.name == "package/package.json":
                output = destination / "package.json"
            else:
                continue
            if not member.isfile():
                raise ValueError("The runtime package contains an unexpected link or special file.")
            source = package.extractfile(member)
            if source is None:
                raise ValueError("Cannot read runtime archive member.")
            output.parent.mkdir(parents=True, exist_ok=True)
            with source, output.open("wb") as target:
                shutil.copyfileobj(source, target)
            files.append(output)
    if not (destination / "index.js").is_file():
        raise ValueError("The official package did not include lib/index.js.")
    return files


def cache_files(metadata: dict) -> dict[str, int | None]:
    records = metadata.get("records", [])
    if not isinstance(records, list):
        raise ValueError("Unexpected model cache index.")
    result: dict[str, int | None] = {}
    for record in records:
        if isinstance(record, dict) and isinstance(record.get("dataPath"), str):
            name = safe_name(record["dataPath"])
            size = record.get("nbytes")
            result[name] = size if isinstance(size, int) and size > 0 else None
    return result


def verify(root: Path | None = None, *, quiet: bool = False) -> bool:
    root = ROOT if root is None else root
    manifest = root / "ai-files-manifest.json"
    if not manifest.is_file():
        if not quiet:
            print("NOT READY: no verified local AI manifest. Run python3 prepare_ai.py with internet first.")
        return False
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        files = data["files"]
        if data.get("runtime") != "@mlc-ai/web-llm@" + VERSION or data.get("model") != MODEL:
            raise ValueError("Installed runtime/model does not match this app.")
        if not isinstance(files, list) or not files:
            raise ValueError("Manifest has no files.")
        names = {f["path"] for f in files}
        for required in ("vendor/webllm/index.js", "models/smollm2-360m/model.wasm",
                         "models/smollm2-360m/mlc-chat-config.json",
                         "models/smollm2-360m/ndarray-cache.json"):
            if required not in names:
                raise ValueError("Missing required entry: " + required)
        for entry in files:
            path = root / safe_name(entry["path"])
            if not path.is_file() or path.stat().st_size != entry["bytes"]:
                raise ValueError("Missing or incomplete file: " + entry["path"])
            if digest(path) != entry["sha256"]:
                raise ValueError("Checksum mismatch: " + entry["path"])
        if not quiet:
            size = sum(f["bytes"] for f in files)
            print(f"VERIFIED: {len(files)} files, {size / 1e6:.1f} MB. No network used.")
        return True
    except (OSError, ValueError, KeyError, TypeError) as error:
        if not quiet:
            print("NOT READY:", error)
        return False


def prepare() -> None:
    if verify(quiet=True):
        atomic_json(STATUS, {"ready": True, "runtime": "@mlc-ai/web-llm@" + VERSION, "model": MODEL})
        print("Local AI is already installed and verified. Use --verify any time without internet.")
        return
    atomic_json(STATUS, {"ready": False, "runtime": "@mlc-ai/web-llm@" + VERSION,
                         "model": MODEL, "reason": "Preparation in progress. Do not load AI until it finishes."})
    print("Preparing a real offline assistant. Expect approximately 210 MB plus runtime/WASM.")
    print("Only public runtime/model files are downloaded. No app data is read or uploaded.\n")
    vendor = ROOT / "vendor" / "webllm"
    model_dir = ROOT / "models" / "smollm2-360m"
    files: list[Path] = []
    print("1/4  Official WebLLM runtime", VERSION)
    metadata = get_json("https://registry.npmjs.org/@mlc-ai%2fweb-llm/" + VERSION)
    dist = metadata["dist"]
    # Verify the official registry integrity before unpacking anything.
    integrity = dist.get("integrity", "")
    with tempfile.TemporaryDirectory(prefix="little-focus-ai-") as temporary:
        archive = Path(temporary) / "webllm.tgz"
        download(dist["tarball"], archive)
        if integrity.startswith("sha512-"):
            actual = base64.b64encode(bytes.fromhex(digest(archive, "sha512"))).decode("ascii")
            if actual != integrity[len("sha512-"):]:
                raise ValueError("The npm runtime archive failed its SHA-512 integrity check.")
        elif dist.get("shasum"):
            if digest(archive, "sha1") != dist["shasum"]:
                raise ValueError("The npm runtime archive failed its registry integrity check.")
        else:
            raise ValueError("No official integrity hash was supplied for the runtime.")
        files.extend(unpack_runtime(archive, vendor))
    if not (vendor / "LICENSE").is_file():
        download(f"https://raw.githubusercontent.com/mlc-ai/web-llm/v{VERSION}/LICENSE", vendor / "LICENSE")
        files.append(vendor / "LICENSE")
    print("2/4  Model metadata and tokenizer")
    info = get_json("https://huggingface.co/api/models/" + REPO)
    revision = info["sha"]
    if not re.fullmatch(r"[0-9a-f]{40,64}", revision):
        raise ValueError("Unexpected model revision.")
    base = f"https://huggingface.co/{REPO}/resolve/{revision}/"
    available = {safe_name(f["rfilename"]) for f in info.get("siblings", [])}
    expected: dict[str, tuple[int | None, str | None]] = {}
    # LFS hashes and sizes allow already-downloaded shards to be safely reused.
    try:
        tree = get_json(f"https://huggingface.co/api/models/{REPO}/tree/{revision}?recursive=true&expand=true")
        for item in tree:
            lfs = item.get("lfs") or {}
            sha = lfs.get("oid") or lfs.get("sha256")
            expected[item["path"]] = (item.get("size"), sha if isinstance(sha, str) and len(sha) == 64 else None)
    except (OSError, ValueError, KeyError, TypeError):
        print("  Optional LFS metadata unavailable; using file lengths and local SHA-256 checks.")

    def model_file(name: str, fallback_size: int | None = None) -> Path:
        name = safe_name(name)
        size, sha = expected.get(name, (fallback_size, None))
        output = model_dir / name
        download(base + urllib.parse.quote(name, safe="/"), output, size, sha)
        files.append(output)
        return output

    config_path = model_file("mlc-chat-config.json")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    indices = ["ndarray-cache.json"]
    if "tensor-cache.json" in available:
        indices.append("tensor-cache.json")
    shards: dict[str, int | None] = {}
    for index in indices:
        path = model_file(index)
        shards.update(cache_files(json.loads(path.read_text(encoding="utf-8"))))
    if not shards:
        raise ValueError("No weight shards were listed in the official model cache index.")
    for name in config.get("tokenizer_files", ["tokenizer.json"]):
        model_file(name)
    for name in ("README.md", "LICENSE", "LICENSE.txt", "LICENSE.md"):
        if name in available:
            model_file(name)
    print("3/4  Quantized weight shards (the largest part)")
    for name, size in sorted(shards.items()):
        model_file(name, size)
    print("4/4  Matching prebuilt GPU WebAssembly library")
    wasm_path = model_dir / "model.wasm"
    download(WASM, wasm_path)
    with wasm_path.open("rb") as stream:
        if stream.read(4) != b"\x00asm":
            raise ValueError("The model library is not a WebAssembly binary.")
    files.append(wasm_path)
    manifest = {
        "runtime": "@mlc-ai/web-llm@" + VERSION, "model": MODEL,
        "model_repository": REPO, "model_revision": revision,
        "model_library_source": WASM,
        "prepared_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "files": [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size,
                   "sha256": digest(p)} for p in sorted(set(files))],
    }
    atomic_json(MANIFEST, manifest)
    if not verify():
        raise RuntimeError("Final verification failed. AI remains disabled.")
    atomic_json(STATUS, {"ready": True, "runtime": manifest["runtime"], "model": MODEL,
                         "model_revision": revision, "files": len(manifest["files"])})
    print("\nREADY. Keep this entire folder together; it now has the local AI assets.")
    print("Serve: python3 -m http.server 8080 --bind 127.0.0.1")
    print("Open localhost:8080, choose Study buddy, then Load local AI.")
    print("A compatible WebGPU browser/GPU is required. No external requests occur in the app.")


def main() -> int:
    global TIMEOUT
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--verify", action="store_true", help="Offline checksum verification only; no downloads.")
    parser.add_argument("--timeout", type=int, default=120, help="Network timeout per request (seconds, default 120).")
    args = parser.parse_args()
    if args.timeout < 5:
        parser.error("--timeout must be at least 5 seconds")
    TIMEOUT = args.timeout
    if args.verify:
        return 0 if verify() else 1
    try:
        prepare()
        return 0
    except KeyboardInterrupt:
        print("\nCanceled. Run again to finish setup.", file=sys.stderr)
        return 130
    except (OSError, RuntimeError, ValueError, KeyError, tarfile.TarError) as error:
        atomic_json(STATUS, {"ready": False, "runtime": "@mlc-ai/web-llm@" + VERSION,
                             "model": MODEL, "reason": str(error)[:500]})
        print("\nAI NOT READY:", error, file=sys.stderr)
        print("The rest of the app still works. Restore internet access and run this script again.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
