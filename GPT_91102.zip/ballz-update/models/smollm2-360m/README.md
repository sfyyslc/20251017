# Local model location - not yet populated

Run `python3 prepare_ai.py` from the app root with internet available. The script
places official SmolLM2-360M-Instruct-q4f32_1-MLC weights, tokenizer, configuration,
cache indexes and the matching GPU WebAssembly library in this folder.

Model generation is not available until those real files are present. The app's
built-in study utilities do not impersonate model-generated output.
