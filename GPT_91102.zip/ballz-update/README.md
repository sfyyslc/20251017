# Your little focus club
## 2026-10-17 update - plain HTML, CSS and vanilla JavaScript

A rebuilt, responsive version of the supplied Ballz app. The default app name is
`ballz`, but you can rename it in **Settings & your data**. The original timer and
cookie rules are retained. No npm, build tools, framework, CDN, account or API key
is required to run the app.

**Important delivery limitation:** the generative AI is integrated with real
WebLLM, but the WebLLM runtime, WebAssembly library and model weights are NOT in
this archive. External binary downloads were unavailable in the packaging
environment. The one-time preparation script below downloads them into local
folders. All other features work immediately without internet. Built-in study
tools are explicitly labeled as non-AI tools, not a pretend chatbot.

## Run now

Extract the ZIP, open a terminal inside the `ballz-update` folder, and run:

```sh
python3 -m http.server 8080 --bind 127.0.0.1
```

Open `http://localhost:8080` in your browser. On systems that use `python` rather
than `python3`, substitute that command. Do not double-click `index.html`:
JavaScript modules, service workers and model fetching need an HTTP origin.
Python 3.10 or newer is recommended for the optional AI preparation script.

The local server must keep running. Internet access is not needed for ordinary
use, or for AI after its files have been prepared. On localhost/HTTPS, the service
worker also caches the app shell so the non-AI app can reload without the server.
Model loading with the server stopped is NOT guaranteed: keep the server running
for AI even after the browser has cached weights.

### One-time preparation for real local AI

Run this ON AN INTERNET-CONNECTED computer, before using AI:

```sh
python3 prepare_ai.py
python3 prepare_ai.py --verify
python3 -m http.server 8080 --bind 127.0.0.1
```

Then open **Study buddy -> Load local AI**. Preparation uses the Python standard
library, not npm or pip. It obtains the prebuilt `@mlc-ai/web-llm@0.2.86` runtime,
SmolLM2-360M-Instruct q4f32 model/tokenizer files, and a matching GPU WebAssembly
library. Budget roughly 210 MB for the model plus runtime/library files. The
installer verifies npm integrity, checks file sizes and available LFS hashes,
and records SHA-256 checksums for offline verification. It only sets
`model-status.json` to ready after successful verification.

Keep the prepared folder together. It can then be copied to a disconnected
computer and served locally. All runtime/model URLs in the app are same-origin;
there are no cloud inference calls or remote JavaScript imports. The separate
setup script contacts public npm, GitHub and Hugging Face sources, not your notes
or browser storage. Downloads that fail leave AI disabled with a clear message.

AI needs a WebGPU-capable browser and compatible GPU, with localhost or HTTPS.
Availability and memory limits depend on the device/browser. A phone opening
plain HTTP on a LAN IP may not expose WebGPU. The small model can make mistakes;
check explanations against class materials. The prompt includes a bounded excerpt
of notes and recent chat, not your entire notebook. Chat is plain text, streamed
from a dedicated worker; Stop and Unload controls are included.

**Real model download, GPU initialization and inference could not be verified in
this environment.** Installer tests use tiny mocked files only; they are not
performance or model-quality tests. The delivered `--verify` correctly reports
NOT READY until the real download step succeeds.

### Try it on a phone

For ordinary app features on a trusted local network, serve with:

```sh
python3 -m http.server 8080 --bind 0.0.0.0
```

Visit `http://YOUR-COMPUTER-LAN-IP:8080` from a phone on the same Wi-Fi. Do not expose
this development server to the public internet. Its only job is serving static
files; it is not an authenticated backend. Secure-context features such as AI and
service workers may require HTTPS on a non-localhost phone connection.

## What changed

### Focus without another setup screen

Press **Start focusing**, then choose a duration or a start/end time. Add breaks,
a study intention and one of five cookie recipes in that dialog. A session's
length includes breaks. For example, 25 minutes with a 5-minute break is 20 active
minutes and awards 25 cookies. First ten whole active minutes earn 1 cookie each;
subsequent whole active minutes earn 1.5 each. Breaks earn nothing. Cookies are
only deposited on successful completion.

Sessions use wall-clock timestamps and resume after refresh. Scheduled starts,
overnight windows up to twelve hours, invalid-break validation and duplicate
reward protection are retained. **Emergency exit forfeits the CURRENT session's
unbanked cookies, not previously earned cookies, pets or room purchases.**

During focus, the buddy gently stirs and steam drifts from its baking table.
Movement slows down rather than competing for attention. Reduced-motion OS
preferences are respected, and Settings also has a motion switch.

### A new buddy and a whole family

Choose three body shapes, ten preset colors (or any custom color), eight faces,
and ten outfits. Rebuild the buddy without losing any progress. Upload a PNG,
JPEG or WebP as the clipped body skin: the cartoon face is always drawn ON TOP.
Image files are resized and re-encoded locally. Up to 8 MB per original image.

Six adoptable pets can all be shown together. Buying a new pet never replaces an
old pet. The Pets panel can temporarily hide a friend without removing ownership.
Your buddy wanders gently at home. In My world, tap/click the floor to move it,
or focus the scene and use arrow keys. In edit mode, drag the buddy directly.

### Separate rooms, not one room with a different name

Six rooms run from the free Cookie nook to the 750-cookie Cloudberry cottage.
Each price step increases the actual room dimensions. The world editor uses the
same camera scale across rooms, so a more expensive room visibly has more space.
The sunroom, moon room, loft, glasshouse and cottage have distinct architecture.

Each purchased room has its own saved furniture arrangement and buddy position.
Switch rooms using the tabs in My world. Bought items remain in the collection;
placing the same owned furniture in another room does not move it out of the
first room. Each room can have one instance of each owned furniture design.

Buy one of twelve furniture pieces, open **My world -> Furniture**, and choose
Place. Drag to position, or use the numeric position/size controls. You can rotate,
mirror and put away selected furniture. Arrow keys move the selected item;
Shift + arrow moves it farther. **Done editing** leaves editing mode. Walls,
windows and other architectural details are fixed; purchased furniture is editable.

### Music is for focus time

Four original, locally generated soundscapes work immediately: rain, chimes,
gentle hush and quiet cafe. Import your own MP3/M4A/OGG/WAV files up to 25 MB each.
Audio is stored in browser IndexedDB. Playback is only available while an active
focus session or its planned break is running, and stops on completion or exit.
The artist/song inspiration shelf contains titles only, not copyrighted recordings.

### Study tools that work immediately

Sample biology notes and three flashcards are included. Edit/import plain-text
notes, extract key sentences, create rule-based fill-in-the-blank cards, edit or
add your own cards, take a self-graded recall quiz, and build a study plan. These
are clearly separate from the real WebLLM chat assistant. PDF/image OCR is not
included; the image upload feature is for buddy skins and photos.

## Sample world and a quick tour

The initial save has Olivia, Mochi, 390 cookies, Miso the cat, a beret, a rug, a
plant, and two independently furnished rooms. Five example focus sessions total
160 minutes and 215 earned cookies. The welcome/purchase ledger reconciles with
the balance. There are ten data-driven badges, a seven-day chart, a daily goal,
recipe counts, sample notes/cards, and a generated buddy postcard.

Try **Little shop -> Pets -> Bean the bunny** to see two pets together. Try
**My world -> Sunday sunroom** to see a larger, separately furnished room. Use
**Start focusing**, add a break at minute 10 for 5 minutes, and begin. The folded
**Preview controls** can skip a minute or finish immediately for testing. These
controls intentionally award sample progress and are not tamper-proof.

Restore samples in Settings for another tour, or choose Erase my data to start
with a clean world and zero cookies. Both actions ask for confirmation. Export a
backup before replacing your save.

## Storage, privacy and migration

The main save is in localStorage under `ballz.local.v2`. Audio is in IndexedDB.
There is no account, analytics, remote AI endpoint or automatic cloud sync. Local
data and the parent PIN are not encrypted. Browsers may clear storage, especially
in private mode; keep JSON backups for progress you care about.

JSON export includes profile, cookies, rooms, pets, skin, recent photos, notes,
flashcards, chat and history. It does NOT include imported audio or AI model files.
Only the newest eight photos are retained to reduce localStorage pressure. A
storage warning appears when a save fails. Importing validates and replaces the
save after confirmation; it does not merge two profiles.

A previous `ballz.local.v1` save on the SAME origin is migrated automatically if
no v2 save exists. The v1 entry is not deleted by migration. All recognized
original item IDs are retained, and all adopted pets become visible together.
Alternatively, export the old app's backup and import it here. Origins include
host AND port: `localhost:8080` and `localhost:8000` have different browser saves.

The editable app name updates the in-app branding and browser title. An already
installed home-screen shortcut can retain its operating-system label; the static
manifest supplies the default `ballz` name. Rename that shortcut separately.

## Honest phone and parental-control boundaries

A browser app cannot power down the device or block other real applications.
The phone screen is a labeled simulation for testing calls/photos, social feed,
messages, a reader, video and a tiny game. The real dialer is only opened through
an explicit `tel:` link and still needs the user to place the call. Camera/file
capture depends on browser support. Never rely on this app for emergency calling.

The local parent PIN is **2468** in the sample world. Parents can set minimum
session length, maximum break length, a recurring downtime window and simulated
blocked apps. The window starts automatically while the app is open. It cannot
wake a closed browser or enforce OS restrictions. Emergency exit is always
available and suppresses the remainder of that downtime window so it does not
immediately lock the user back into a session.

## File map

- `index.html`, `styles.css`: responsive interface, inline icon symbols, local CSP.
- `core.js`: original pure timer, reward, calendar and purchase logic.
- `js/data.js`, `js/art.js`: catalog, sample save, migration, original SVG world art.
- `js/app.js`, `js/audio.js`: interactions, persistence and session-gated audio.
- `js/study-tools.js`: deterministic offline study utilities.
- `js/ai.js`, `js/ai-worker.js`: real WebLLM loading and streaming chat bridge.
- `prepare_ai.py`: one-time downloader and offline checksum verifier.
- `vendor/webllm/`, `models/smollm2-360m/`: filled by that preparation script.
- `sw.js`, `manifest.webmanifest`, `assets/icon.svg`: local app-shell/PWA support.
- `tests/`: pure logic tests, mocked installer tests and optional browser QA.

No fonts, frameworks or third-party artwork are shipped. WebLLM is the sole
requested third-party runtime dependency and is obtained as a prebuilt local
bundle, not loaded from a CDN. See `THIRD_PARTY.md` for upstream references and
`TESTING.md` for the exact tested scope and remaining limitations.

### Replacing an older served copy

Export your old save before replacing files. When reusing the same browser
origin, reload after the new service worker installs. A stale cached interface
can require a hard refresh or removal of the old service worker through browser
developer tools; keep your backup before clearing any browser site data. For an
unreadable v2 save, the app attempts to preserve the raw text in a
`ballz.local.v2.recovery.TIMESTAMP` storage key before opening samples. Erase and
Restore samples also clear these recovery copies after confirmation.
