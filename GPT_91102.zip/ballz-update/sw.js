/* Cache only the app shell. WebLLM owns its model cache; weights remain local. */
const CACHE='ballz-v2-shell-20261017-2';
const SHELL=['./','./index.html','./styles.css','./core.js','./js/data.js','./js/art.js','./js/audio.js','./js/study-tools.js','./js/ai.js','./js/ai-worker.js','./js/app.js','./manifest.webmanifest','./assets/icon.svg','./model-status.json'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>(k.startsWith('ballz-v2-shell-')||k.startsWith('ballz-shell-'))&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
  const u=new URL(event.request.url),root=new URL('./',self.location.href);
  if(event.request.method!=='GET'||u.origin!==root.origin)return;
  // Do not double-cache 200+ MB of weights. Prepared files are on the local server;
  // WebLLM itself caches loaded artifacts for supported browser-offline use.
  if(u.pathname.includes('/models/')||u.pathname.includes('/vendor/'))return;
  const relative=u.pathname.startsWith(root.pathname)?u.pathname.slice(root.pathname.length):null;
  if(!SHELL.includes('./'+relative)&&relative!=='')return;
  event.respondWith(fetch(event.request).then(response=>{
    if(response.ok){const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache=>cache.put(event.request,copy)));}
    return response;
  }).catch(async()=>{
    const cache=await caches.open(CACHE);
    const cached=await cache.match(event.request,{ignoreSearch:true});
    return cached||new Response('Local file unavailable. Restart the local server.',{status:503,headers:{'Content-Type':'text/plain'}});
  }));
});
