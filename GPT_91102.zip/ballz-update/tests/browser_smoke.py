"""Optional browser QA. Requires Playwright only on the TEST machine, not the app.
Run a server first, then: python3 tests/browser_smoke.py
BALLZ_TEST_URL and CHROMIUM_PATH can override the defaults.
"""
import json
import os
from pathlib import Path
import struct
import wave
import time
from playwright.sync_api import sync_playwright

BASE = os.environ.get('BALLZ_TEST_URL', 'http://127.0.0.1:8765/')
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'artifacts'
OUT.mkdir(exist_ok=True)
checks, errors, external, console_errors = [], [], [], []


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)
    print('PASS:', label, flush=True)


def wait_js(page, expression):
    end = time.monotonic() + 8
    while time.monotonic() < end:
        if page.evaluate(expression):
            return
        page.wait_for_timeout(50)
    raise AssertionError('Timed out: ' + expression)


def state(page):
    return page.evaluate('JSON.parse(localStorage.getItem("ballz.local.v2"))')


def click(page, action, extra=''):
    page.mouse.move(1, 1)
    page.wait_for_timeout(35)
    page.locator(f'[data-action="{action}"]{extra}:visible').first.click()


def nav(page, tab):
    page.locator(f'[data-action="nav"][data-tab="{tab}"]:visible').first.click()
    page.wait_for_timeout(80)


def close(page):
    if page.locator('#modal').evaluate('(e)=>e.open'):
        page.locator('#modal [data-action="close-modal"]').first.click()


def shot(page, name):
    page.screenshot(path=str(OUT / name), full_page=True, animations='disabled')


with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH', '/usr/bin/chromium'),
                               headless=True, args=['--no-sandbox'])
    context = browser.new_context(viewport={'width':1440, 'height':1000}, reduced_motion='reduce')
    context.on('request', lambda r: external.append(r.url) if r.url.startswith(('http://','https://')) and not r.url.startswith(BASE) else None)
    page = context.new_page()
    page.set_default_timeout(6000)
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: console_errors.append(m.text) if m.type == 'error' else None)
    page.goto(BASE)
    wait_js(page, 'JSON.parse(localStorage.getItem("ballz.local.v2"))?.gallery.length===1')
    check(state(page)['wallet'] == 390, 'Realistic sample world starts with 390 cookies')
    check(page.locator('#plan-minutes').count() == 0, 'Duration picker is absent before Start focusing')
    shot(page, 'desktop-home.png')

    nav(page, 'settings')
    page.locator('#app-name').fill('Cookie Club')
    page.locator('#profile-form [name=ballName]').fill('Pebble')
    page.locator('#profile-form button[type=submit]').click()
    check('Cookie Club' in page.title(), 'Custom app name updates document title')
    page.reload()
    check(state(page)['profile']['appName'] == 'Cookie Club', 'Custom app and companion names persist')

    nav(page, 'shop')
    click(page, 'category', '[data-category="pets"]')
    click(page, 'buy', '[data-id="bunny"]')
    click(page, 'confirm-buy', '[data-id="bunny"]')
    wait_js(page, 'JSON.parse(localStorage.getItem("ballz.local.v2")).wallet===270')
    check(set(state(page)['custom']['pets']) == {'cat','bunny'}, 'Buying another pet adds to family rather than replacing cat')
    nav(page, 'world')
    check(page.locator('#world-stage [data-pet]').count() == 2, 'Both adopted pets appear together beside companion')
    shot(page, 'desktop-world.png')
    check(len(state(page)['custom']['layouts']['kitchen']) == 2, 'Starter kitchen has independent rug and plant placements')
    click(page, 'room', '[data-id="sunroom"]')
    check(len(state(page)['custom']['layouts']['sunroom']) == 1, 'Second room has its own independent furniture layout')
    click(page, 'world-panel', '[data-panel="furniture"]')
    click(page, 'place', '[data-id="rug"]')
    check(len(state(page)['custom']['layouts']['sunroom']) == 2, 'Owned furniture can be placed in a different room')
    page.locator('[data-placement="x"]').fill('410')
    page.locator('[data-placement="x"]').dispatch_event('change')
    click(page, 'rotate')
    click(page, 'flip')
    layout = state(page)['custom']['layouts']['sunroom']
    rug = next(item for item in layout if item['id'] == 'rug')
    check(rug['x'] == 410 and rug['rotation'] == 15 and rug['flip'], 'Furniture position, rotation and mirroring are saved')
    click(page, 'put-away')
    check(len(state(page)['custom']['layouts']['sunroom']) == 1, 'Putting away furniture affects only current room')
    click(page, 'room', '[data-id="kitchen"]')
    check(len(state(page)['custom']['layouts']['kitchen']) == 2, 'Furnishings in previous room remain unchanged')

    nav(page, 'shop')
    click(page, 'category', '[data-category="rooms"]')
    shot(page, 'desktop-shop.png')
    click(page, 'buy', '[data-id="moonroom"]')
    click(page, 'confirm-buy', '[data-id="moonroom"]')
    wait_js(page, 'JSON.parse(localStorage.getItem("ballz.local.v2")).wallet===10')
    check('moonroom' in state(page)['owned'], 'Room purchase adds separate room and deducts correct price')
    click(page, 'buy', '[data-id="loft"]')
    check('more cookies' in page.locator('#modal-content').inner_text(), 'Insufficient funds cannot buy expensive room')
    close(page)
    room_sizes = page.evaluate('BallzData.CATALOG.filter(i=>i.category==="rooms").map(i=>({price:i.price,w:i.w,h:i.h}))')
    check(all(a['price'] < b['price'] and a['w'] < b['w'] and a['h'] < b['h'] for a,b in zip(room_sizes,room_sizes[1:])), 'Each more expensive room is physically wider and taller')

    nav(page, 'world')
    click(page, 'world-panel', '[data-panel="appearance"]')
    click(page, 'face', '[data-value="wink"]')
    # Small original fixture image; no dependencies or external assets.
    png = page.evaluate('''()=>{const c=document.createElement('canvas');c.width=48;c.height=48;const g=c.getContext('2d');g.fillStyle='#8eab8d';g.fillRect(0,0,48,48);g.fillStyle='#ecd78c';g.fillRect(0,0,24,24);return c.toDataURL('image/png').split(',')[1];}''')
    import base64
    page.locator('#skin-file').set_input_files({'name':'sample-skin.png','mimeType':'image/png','buffer':base64.b64decode(png)})
    wait_js(page, '!!JSON.parse(localStorage.getItem("ballz.local.v2")).custom.skin')
    check(state(page)['custom']['face'] == 'wink', 'Image skin upload preserves selected cartoon face')
    check(page.locator('#world-stage image').count() > 0, 'Uploaded image renders clipped within the companion')
    page.reload()
    check(state(page)['custom']['skin'].startswith('data:image/png'), 'Uploaded skin persists after refresh')
    nav(page, 'world')
    click(page, 'remove-skin')

    nav(page, 'home')
    click(page, 'start')
    check(page.locator('#plan-minutes').is_visible() and not state(page)['active'], 'Start focusing opens duration dialog without starting timer prematurely')
    page.locator('#plan-minutes').fill('25')
    click(page, 'add-break')
    page.locator('[name=after]').fill('10')
    page.locator('[name=breakLength]').fill('5')
    check('20 min of focus' in page.locator('#plan-summary').inner_text(), 'Planner includes break time and calculates 20 active minutes')
    page.locator('[name=after]').fill('24')
    check(page.locator('#begin-session').is_disabled(), 'Invalid break past session end is rejected')
    page.locator('[name=after]').fill('10')
    shot(page, 'desktop-planner.png')
    page.locator('#begin-session').click()
    page.wait_for_selector('#timer')
    check(state(page)['active'] is not None and page.locator('.baking').count() > 0, 'Focus session starts with subtle baking animation')
    shot(page, 'desktop-focus.png')
    click(page, 'music')
    click(page, 'sound', '[data-id="rain"]')
    check(page.evaluate('BallzAudio.current') == 'rain', 'Locally generated rain sound plays during focus')
    close(page)
    page.locator('.demo-panel summary').click()
    for _ in range(10):
        # Rerenders collapse details; reopen as necessary.
        if not page.locator('[data-action="advance"]').is_visible():
            page.locator('.demo-panel summary').click()
        click(page, 'advance')
    check('Rest is part' in page.locator('#focus-heading').inner_text(), 'Break begins at minute 10')
    check(page.locator('#pending-cookies').inner_text() == '10', 'First ten active minutes earn ten pending cookies')
    click(page, 'phone')
    check(page.locator('[data-action="phone-app"][data-app="social"]').is_visible(), 'Simulated phone available during break')
    close(page)
    if not page.locator('[data-action="finish-demo"]').is_visible():
        page.locator('.demo-panel summary').click()
    click(page, 'finish-demo')
    wait_js(page, 'JSON.parse(localStorage.getItem("ballz.local.v2")).active===null')
    check(state(page)['wallet'] == 35, 'Completing 25-minute session with 5-minute break awards exactly 25 cookies')
    check(not page.evaluate('BallzAudio.current'), 'All music stops automatically on completion')
    close(page)
    page.reload()
    check(state(page)['wallet'] == 35, 'Reload never awards the same session twice')
    check(not page.locator('[data-action="music"]').count(), 'Music controls are absent outside a session')

    click(page, 'start')
    page.locator('#begin-session').click()
    page.wait_for_selector('#timer')
    page.locator('.demo-panel summary').click()
    click(page, 'advance')
    click(page, 'emergency')
    shot(page, 'desktop-emergency.png')
    click(page, 'cancel-session')
    wait_js(page, 'JSON.parse(localStorage.getItem("ballz.local.v2")).active===null')
    check(state(page)['wallet'] == 35, 'Emergency exit discards pending reward but preserves previously earned cookies')
    check(not state(page)['history'][0]['completed'], 'Emergency session is tracked as canceled, not completed')

    nav(page, 'study')
    wait_js(page, 'BallzAI.status.phase==="missing"')
    check('No model files are bundled' in page.locator('#ai-status').inner_text(), 'Missing AI model is disclosed, not disguised as working AI')
    page.locator('#chat-input').fill('Explain photosynthesis.')
    page.locator('#chat-form button[type=submit]').click()
    check('Load the local AI model first' in page.locator('#chat-error').inner_text(), 'No fabricated chatbot answer without real model')
    click(page, 'summarize')
    check('nucleus' in page.locator('.tool-output').inner_text().lower(), 'Offline key points are extracted from sample notes')
    close(page)
    click(page, 'flip-card')
    click(page, 'next-card')
    click(page, 'add-card')
    page.locator('#card-form [name=q]').fill('What powers most cell activities?')
    page.locator('#card-form [name=a]').fill('ATP is an energy carrier used by cells.')
    page.locator('#card-form button[type=submit]').click()
    check(len(state(page)['study']['cards']) == 4, 'Flashcards can be created and saved offline')
    click(page, 'quiz')
    click(page, 'quiz-reveal')
    click(page, 'quiz-answer', '[data-correct="true"]')
    check('Card 2 of 4' in page.locator('#modal-content').inner_text(), 'Self-graded recall quiz advances correctly')
    close(page)
    click(page, 'study-plan')
    page.locator('#study-plan-form [name=topic]').fill('Cell structures')
    page.locator('#study-plan-form [name=minutes]').fill('40')
    page.locator('#study-plan-form button[type=submit]').click()
    check('Cell structures' in page.locator('#modal-content').inner_text(), 'Built-in study planner works without AI')
    close(page)
    shot(page, 'desktop-study.png')
    nav(page, 'progress')
    shot(page, 'desktop-progress.png')
    check(page.locator('.badge-grid .badge').count() == 10, 'Ten achievements have populated, data-driven progress')

    nav(page, 'settings')
    click(page, 'parent')
    page.locator('[name=pin]').fill('1111')
    page.locator('#parent-pin-form button[type=submit]').click()
    check('not quite' in page.locator('#pin-error').inner_text().lower(), 'Incorrect parent PIN rejected')
    page.locator('[name=pin]').fill('2468')
    page.locator('#parent-pin-form button[type=submit]').click()
    page.locator('#parent-form [name=enabled]').check()
    page.locator('#parent-form [name=minMinutes]').fill('40')
    page.locator('#parent-form button[type=submit]').click()
    nav(page, 'home')
    click(page, 'start')
    check(int(page.locator('#plan-minutes').input_value()) == 40, 'Parent minimum is used when opening focus planner')
    page.locator('#plan-minutes').fill('10')
    check(page.locator('#begin-session').is_disabled(), 'Parent minimum duration enforced')
    close(page)

    # Real file import uses validation before confirmation.
    backup = state(page)
    backup['profile']['appName'] = 'Restored Club'
    page.locator('#backup-file').set_input_files({'name':'world.json','mimeType':'application/json','buffer':json.dumps(backup).encode()})
    page.wait_for_selector('[data-action="confirm-import"]')
    click(page, 'confirm-import')
    check(state(page)['profile']['appName'] == 'Restored Club', 'JSON backup import restores names, possessions and settings')
    page.locator('#backup-file').set_input_files({'name':'invalid.json','mimeType':'application/json','buffer':b'{bad json'})
    page.wait_for_timeout(120)
    check(state(page)['profile']['appName'] == 'Restored Club', 'Invalid backup does not destroy existing data')

    # Responsive layouts and real mobile interaction, with a fresh sample world.
    nav(page, 'settings')
    click(page, 'reset-sample')
    click(page, 'confirm-reset')
    wait_js(page, 'JSON.parse(localStorage.getItem("ballz.local.v2")).wallet===390')
    for width,height in [(1440,1000),(1024,900),(768,1024),(390,844),(320,740)]:
        page.set_viewport_size({'width':width,'height':height})
        for tab in ['home','world','shop','study','progress','settings']:
            nav(page, tab)
            page.wait_for_timeout(40)
            check(page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'), f'No horizontal overflow: {tab} at {width}px')
            if width == 390 and tab in ['home','world','shop','study']:
                shot(page, 'mobile-'+tab+'.png')
        nav(page, 'home')
        click(page, 'start')
        check(page.locator('#begin-session').is_visible(), f'Focus planner usable at {width}px')
        if width == 390:
            shot(page, 'mobile-planner.png')
        close(page)

    # The complete shell can reload without the server after its first cache.
    page.set_viewport_size({'width':1440,'height':1000})
    nav(page, 'home')
    page.evaluate('navigator.serviceWorker.ready')
    wait_js(page, 'navigator.serviceWorker.controller!==null')
    context.set_offline(True)
    page.reload()
    check(page.locator('#start-focusing').is_visible(), 'Cached app shell reloads in browser offline mode')
    nav(page, 'world')
    check(page.locator('#world-stage').is_visible(), 'World remains interactive in browser offline mode')
    context.set_offline(False)
    check(not errors, 'No JavaScript page errors during tested flows')
    check(not external, 'No external HTTP requests during all tested app flows')
    # Failed network fetches during the deliberate offline test are expected;
    # substantive console errors are preserved for review, not hidden.
    report = {'checks_passed':len(checks),'checks':checks,'javascript_errors':errors,
              'external_requests':external,'console_errors':console_errors,
              'not_tested':['Real WebLLM inference (model and runtime could not be downloaded here)',
                            'Physical mobile devices and native camera/dialer handoff']}
    (OUT/'browser-report.json').write_text(json.dumps(report,indent=2))
    print('\n'+str(len(checks))+' checks passed.', flush=True)
    browser.close()
