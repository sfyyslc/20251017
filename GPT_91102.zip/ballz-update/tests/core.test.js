'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../core.js');
const M = C.MINUTE;
const now = new Date(2026, 9, 3, 10, 0, 0).getTime();
const session = (options = {}) => C.createSession({ minutes: 25, startAt: now, ...options }, now);

test('cookies: first tier, second tier, and capped later tier', () => {
  for (const [minutes, cookies] of [[0,0],[.99,0],[1,1],[9,9],[10,10],[10.9,10],[11,11.5],[20,25],[25,32.5],[120,175]]) assert.equal(C.cookiesFor(minutes * M), cookies);
});
test('negative focus earns nothing', () => assert.equal(C.cookiesFor(-M), 0));
test('valid 2-hour plan predicts 100 active minutes and 145 cookies', () => {
  const result = C.validatePlan(120, [{ after:25,duration:10 },{ after:65,duration:10 }]);
  assert.equal(result.ok, true); assert.equal(result.focusMinutes, 100); assert.equal(result.cookies, 145);
});
test('invalid numeric durations are rejected', () => {
  for (const value of [NaN, Infinity, -1, 0, 1.5, 721, '25', null]) assert.equal(C.validatePlan(value).ok, false);
});
test('breaks must be positive integers', () => {
  for (const b of [{after:0,duration:5},{after:1,duration:0},{after:NaN,duration:5},{after:5,duration:1.5}]) assert.equal(C.validatePlan(25,[b]).ok,false);
});
test('overlapping breaks are rejected; unsorted disjoint breaks are sorted', () => {
  assert.equal(C.validatePlan(60,[{after:10,duration:10},{after:15,duration:10}]).ok,false);
  const result = C.validatePlan(60,[{after:40,duration:5},{after:10,duration:5}]);
  assert.equal(result.ok,true); assert.deepEqual(result.breaks.map(b => b.after),[10,40]);
});
test('breaks cannot fill the end of the session', () => assert.equal(C.validatePlan(25,[{after:20,duration:5}]).ok,false));
test('at most ten breaks are supported', () => assert.equal(C.validatePlan(100,Array.from({length:11},(_,i)=>({after:i*3+1,duration:1}))).ok,false));
test('parent minimum and per-break maximum are enforced', () => {
  const parent = { enabled:true,minMinutes:30,maxBreakMinutes:3 };
  assert.equal(C.validatePlan(25,[],parent).ok,false);
  assert.equal(C.validatePlan(45,[{after:20,duration:5}],parent).ok,false);
  assert.equal(C.validatePlan(45,[{after:20,duration:3}],parent).ok,true);
});
test('zero parent break allowance prohibits breaks', () => assert.equal(C.validatePlan(25,[{after:10,duration:1}],{enabled:true,minMinutes:10,maxBreakMinutes:0}).ok,false));
test('time parser rejects malformed clock values', () => {
  for (const value of ['',null,'1:30','24:00','12:60','abc']) assert.equal(C.parseTime(value),null);
  assert.equal(C.parseTime('23:59'),1439);
});
test('same-day range uses local clock times', () => {
  const range = C.timeWindow('13:30','15:30',now);
  assert.equal(range.ok,true); assert.equal(range.totalMinutes,120);
  assert.equal(new Date(range.startAt).getDate(),3);
});
test('past start time schedules the next day', () => {
  const range = C.timeWindow('09:00','11:00',now);
  assert.equal(new Date(range.startAt).getDate(),4);
});
test('overnight range crosses midnight', () => {
  const range = C.timeWindow('23:30','01:30',now);
  assert.equal(range.totalMinutes,120); assert.equal(new Date(range.endAt).getDate(),4);
});
test('zero and over-12-hour windows are rejected', () => {
  assert.equal(C.timeWindow('13:00','13:00',now).ok,false);
  assert.equal(C.timeWindow('13:00','12:00',now).ok,false);
});
test('progress uses elapsed wall time, not interval callback counts', () => {
  const s = session(); assert.equal(C.progress(s,now+12*M).focusMs,12*M); assert.equal(C.progress(s,now+12*M).cookies,13);
});
test('break begins exactly at its start boundary', () => {
  const s = session({breaks:[{after:10,duration:5}]});
  assert.equal(C.progress(s,now+10*M-1).phase,'focus');
  assert.equal(C.progress(s,now+10*M).phase,'break');
});
test('cookies and active minutes pause throughout a break', () => {
  const s = session({breaks:[{after:10,duration:5}]});
  assert.equal(C.progress(s,now+14*M).focusMs,10*M); assert.equal(C.progress(s,now+14*M).cookies,10);
});
test('break ends exactly and focus resumes at its boundary', () => {
  const s = session({breaks:[{after:10,duration:5}]});
  assert.equal(C.progress(s,now+15*M).phase,'focus');
  assert.equal(C.progress(s,now+16*M).cookies,11.5);
});
test('multiple breaks accumulate, but only active minutes earn', () => {
  const s = session({minutes:60,breaks:[{after:10,duration:5},{after:30,duration:10}]});
  const p=C.progress(s,now+60*M); assert.equal(p.focusMs,45*M); assert.equal(p.cookies,62.5);
});
test('completion clamps elapsed time even after a long closed-tab interval', () => {
  const p=C.progress(session(),now+900*M); assert.equal(p.phase,'complete'); assert.equal(p.elapsed,25*M); assert.equal(p.cookies,32.5);
});
test('a future session remains scheduled and earns nothing', () => {
  const s=session({startAt:now+M}); assert.equal(C.progress(s,now).phase,'scheduled'); assert.equal(C.progress(s,now).cookies,0); assert.equal(C.progress(s,now+M).phase,'focus');
});
test('changing speed does not retroactively accelerate prior elapsed time', () => {
  const s=session(); C.setSpeed(s,60,now+M); assert.equal(C.progress(s,now+M).elapsed,M); assert.equal(C.progress(s,now+M+1000).elapsed,2*M);
});
test('changing speed while scheduled preserves future start time', () => {
  const s=session({startAt:now+10*M}); C.setSpeed(s,60,now+M); assert.equal(s.anchorAt,now+10*M); assert.equal(C.progress(s,now+2*M).phase,'scheduled');
});
test('invalid preview speed throws', () => assert.throws(()=>C.setSpeed(session(),5,now),/Unsupported/));
test('advancing time preserves prior elapsed time and supports exact break boundaries', () => {
  const s=session({breaks:[{after:10,duration:5}]}); C.advance(s,10*M,now); assert.equal(C.progress(s,now).phase,'break'); C.advance(s,5*M,now); assert.equal(C.progress(s,now).phase,'focus');
});
test('preview advance can explicitly begin a scheduled session', () => {
  const s=session({startAt:now+M}); C.advance(s,0,now); assert.equal(C.progress(s,now).phase,'focus');
});
test('serialization preserves a running session', () => {
  const original=session({breaks:[{after:10,duration:5}],speed:60}); const loaded=JSON.parse(JSON.stringify(original)); assert.deepEqual(C.progress(original,now+16000),C.progress(loaded,now+16000));
});
test('purchase transaction deducts only once and refuses overspending', () => {
  const result=C.purchase(100,[],{id:'cat',price:90}); assert.deepEqual(result,{ok:true,wallet:10,owned:['cat']});
  assert.equal(C.purchase(result.wallet,result.owned,{id:'cat',price:90}).ok,false);
  assert.equal(C.purchase(20,[],{id:'cat',price:90}).ok,false);
});
test('streaks ignore emergency exits and allow a not-yet-completed today', () => {
  const date = days => { const d=new Date(now); d.setDate(d.getDate()-days); return +d; };
  const history=[1,2,3].map(days=>({completed:true,endedAt:date(days)}));
  assert.equal(C.streak(history,now),3);
  history.push({completed:false,endedAt:now}); assert.equal(C.streak(history,now),3);
  history.push({completed:true,endedAt:now}); assert.equal(C.streak(history,now),4);
});
test('weekly data contains seven days and excludes canceled sessions', () => {
  const days=C.weekly([{completed:true,endedAt:now,focusMs:25*M},{completed:false,endedAt:now,focusMs:10*M}],now);
  assert.equal(days.length,7); assert.equal(days[6].minutes,25); assert.equal(days[0].minutes,0);
});
test('recurring parent window activates only when enabled and within hours', () => {
  const parent={enabled:true,scheduleEnabled:true,start:'09:00',end:'11:00'};
  assert.ok(C.currentDowntime(parent,now)); assert.equal(C.currentDowntime({...parent,enabled:false},now),null);
  assert.equal(C.currentDowntime(parent,now+3*60*M),null);
});
test('overnight parent window has a stable key across midnight', () => {
  const parent={enabled:true,scheduleEnabled:true,start:'21:00',end:'07:00'};
  const before=+new Date(2026,9,3,23), after=+new Date(2026,9,4,2);
  assert.equal(C.currentDowntime(parent,before).key,C.currentDowntime(parent,after).key);
});
