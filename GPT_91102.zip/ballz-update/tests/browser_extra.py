"""Optional extra browser QA. Requires Playwright on the test machine only."""
import io,json,os,wave
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
BASE=os.environ.get('BALLZ_TEST_URL','http://127.0.0.1:8765/')
checks=[]
def check(ok,label):
    if not ok: raise AssertionError(label)
    checks.append(label);print('PASS:',label,flush=True)
def saved(page):return page.evaluate('JSON.parse(localStorage.getItem("ballz.local.v2"))')
def click(page,action,extra=''):
    page.mouse.move(1,1);page.wait_for_timeout(30)
    page.locator(f'[data-action="{action}"]{extra}:visible').first.click()
def close(page):page.locator('#modal [data-action="close-modal"]').first.click()
def nav(page,tab):click(page,'nav',f'[data-tab="{tab}"]')
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
    c=b.new_context(viewport={'width':1280,'height':960},reduced_motion='reduce',accept_downloads=True)
    page=c.new_page();page.set_default_timeout(6000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(BASE+'#world');page.wait_for_timeout(250)
    click(page,'toggle-edit')
    rug=page.locator('#world-stage [data-furniture="rug"]')
    box=rug.bounding_box();x=box['x']+box['width']*.1;y=box['y']+box['height']*.55
    old=next(i for i in saved(page)['custom']['layouts']['kitchen'] if i['id']=='rug')['x']
    page.mouse.move(x,y);page.mouse.down();page.mouse.move(x+25,y+4,steps=8);page.mouse.up()
    new=next(i for i in saved(page)['custom']['layouts']['kitchen'] if i['id']=='rug')['x']
    check(new>old,'Pointer drag changes furniture coordinates')
    page.locator('#world-stage .world-svg').focus();page.keyboard.press('Shift+ArrowRight')
    check(next(i for i in saved(page)['custom']['layouts']['kitchen'] if i['id']=='rug')['x']>=new+9,'Keyboard fine adjustment works for furniture')
    click(page,'toggle-edit');before=saved(page)['custom']['positions']['kitchen']['x']
    page.locator('#world-stage .world-svg').focus();page.keyboard.press('ArrowRight')
    check(saved(page)['custom']['positions']['kitchen']['x']==before+2,'Buddy moves with keyboard independently of furniture')
    click(page,'room','[data-id="sunroom"]')
    check(page.locator('#world-stage .room-architecture').count()==1,'Second room has distinct sunroom architecture')
    page.screenshot(path=str(ROOT/'artifacts/desktop-sunroom.png'),full_page=True,animations='disabled')
    click(page,'rebuild');original=saved(page)['profile']['ballName']
    page.locator('#rebuild-form [name=ballName]').fill('Not saved');click(page,'close-modal')
    check(saved(page)['profile']['ballName']==original,'Canceling rebuild does not submit the form')
    click(page,'rebuild');page.locator('#rebuild-form [name=ballName]').fill('Puff')
    page.locator('#rebuild-form [name=shape]').select_option('cloud');page.locator('#rebuild-form button[type=submit]').click()
    check(saved(page)['custom']['shape']=='cloud' and saved(page)['wallet']==390 and 'cat' in saved(page)['owned'],'Rebuild preserves progress and purchases')
    nav(page,'settings');click(page,'phone');click(page,'phone-app','[data-app="photos"]');click(page,'capture');page.wait_for_timeout(500)
    check(len(saved(page)['gallery'])>=2,'Original buddy postcards generate and persist')
    with page.expect_download() as downloaded:click(page,'download-photo')
    check(downloaded.value.suggested_filename.endswith('.jpg'),'Photo download uses correct JPEG extension')
    close(page);nav(page,'home');click(page,'start');page.locator('#plan-minutes').fill('15');page.locator('#begin-session').click();click(page,'music')
    buf=io.BytesIO()
    with wave.open(buf,'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(8000);wav.writeframes(b'\0\0'*8000*3)
    page.locator('#music-file').set_input_files({'name':'local-test.wav','mimeType':'audio/wav','buffer':buf.getvalue()})
    page.wait_for_selector('[data-action="play-track"]');click(page,'play-track');page.wait_for_timeout(300)
    check(page.evaluate('BallzAudio.current?.startsWith("track-")'),'Imported WAV plays from IndexedDB during focus')
    close(page);page.reload();page.wait_for_timeout(200)
    check(saved(page)['active'] is not None,'Active focus survives a page reload')
    click(page,'music');page.wait_for_selector('[data-action="play-track"]');check(page.locator('[data-action="play-track"]').count()==1,'Imported audio remains after reload')
    close(page);click(page,'emergency');click(page,'cancel-session');page.wait_for_timeout(200)
    check(page.evaluate('!BallzAudio.current && document.querySelector("#local-audio").paused'),'Emergency exit stops imported audio')
    denied=page.evaluate('''async()=>{try{await BallzAudio.start('rain');return false;}catch(e){return /only available/.test(e.message);}}''')
    check(denied,'Audio API rejects playback outside focus')
    nav(page,'settings');click(page,'erase');click(page,'confirm-erase');page.wait_for_timeout(200)
    check(saved(page)['wallet']==0 and not saved(page)['history'] and not saved(page)['custom']['pets'],'Erase creates a clean zero-cookie world')
    check(page.evaluate('BallzAudio.tracks().then(t=>t.length)')==0,'Erase clears imported IndexedDB music')
    fresh=b.new_context(viewport={'width':390,'height':844},reduced_motion='reduce');bad=fresh.new_page()
    bad.add_init_script('localStorage.setItem("ballz.local.v2", "{broken")');bad.goto(BASE);bad.wait_for_timeout(200)
    check(bad.evaluate('Object.keys(localStorage).some(k=>k.startsWith("ballz.local.v2.recovery."))'),'Malformed saves are retained in a recovery key')
    click(bad,'start');bad.locator('#begin-session').click();bad.wait_for_timeout(4400)
    bad.screenshot(path=str(ROOT/'artifacts/mobile-focus.png'),full_page=True,animations='disabled')
    check(bad.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),'Mobile focus screen has no horizontal overflow')
    check(not errors,'No JavaScript errors in extended flows')
    (ROOT/'artifacts/browser-extra-report.json').write_text(json.dumps({'checks_passed':len(checks),'checks':checks,'javascript_errors':errors},indent=2))
    b.close();print(str(len(checks))+' extra checks passed.')
