"""Offline unit tests for installer safety and verification. No real model required."""
import base64
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('prepare_ai', Path(__file__).resolve().parents[1]/'prepare_ai.py')
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


class InstallerTests(unittest.TestCase):
    def test_safe_model_names(self):
        self.assertEqual(M.safe_name('params_shard_0.bin'), 'params_shard_0.bin')
        for value in ['', '.', '..', '../bad', '/tmp/bad', 'a/../../bad', 'C:/bad', 'a\\bad']:
            with self.subTest(value=value), self.assertRaises(ValueError):
                M.safe_name(value)

    def test_extract_cache_records(self):
        self.assertEqual(M.cache_files({'records':[{'dataPath':'params_0.bin','nbytes':10}]}), {'params_0.bin':10})
        with self.assertRaises(ValueError):
            M.cache_files({'records':[{'dataPath':'../../escape'}]})

    def test_runtime_archive_ignores_unrelated_members(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            archive=root/'package.tgz'
            with tarfile.open(archive,'w:gz') as tar:
                for name,data in [('package/lib/index.js',b'export const version="test";'),('package/LICENSE',b'test license'),('package/lib/index.js.map',b'{}'),('package/src/not-used.ts',b'ignored')]:
                    info=tarfile.TarInfo(name); info.size=len(data)
                    tar.addfile(info,io.BytesIO(data))
            files=M.unpack_runtime(archive,root/'vendor')
            self.assertEqual(len(files),2)
            self.assertTrue((root/'vendor/index.js').exists())
            self.assertFalse((root/'vendor/index.js.map').exists())

    def test_runtime_archive_rejects_traversal_and_links(self):
        for name,symlink in [('package/lib/../../escape',False),('package/lib/index.js',True)]:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as d:
                root=Path(d); archive=root/'unsafe.tgz'
                with tarfile.open(archive,'w:gz') as tar:
                    member=tarfile.TarInfo(name)
                    if symlink:
                        member.type=tarfile.SYMTYPE;member.linkname='/tmp/no'
                    tar.addfile(member)
                with self.assertRaises(ValueError):
                    M.unpack_runtime(archive,root/'vendor')

    def test_atomic_json_and_checksum(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'test.json';M.atomic_json(p,{'ready':False})
            self.assertEqual(json.loads(p.read_text()),{'ready':False})
            self.assertFalse(p.with_suffix('.json.part').exists())
            self.assertEqual(M.digest(p),hashlib.sha256(p.read_bytes()).hexdigest())

    def test_offline_verifier_missing_and_corrupt_files(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            self.assertFalse(M.verify(root,quiet=True))
            files=[]
            for name in ['vendor/webllm/index.js','models/smollm2-360m/model.wasm','models/smollm2-360m/mlc-chat-config.json','models/smollm2-360m/ndarray-cache.json']:
                p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'test')
                files.append({'path':name,'bytes':4,'sha256':M.digest(p)})
            M.atomic_json(root/'ai-files-manifest.json',{'runtime':'@mlc-ai/web-llm@'+M.VERSION,'model':M.MODEL,'files':files})
            self.assertTrue(M.verify(root,quiet=True))
            (root/files[0]['path']).write_bytes(b'xxxx')
            self.assertFalse(M.verify(root,quiet=True))

    def test_download_validates_and_reuses_hash(self):
        content=b'a test shard'
        class Response(io.BytesIO):
            headers={'Content-Length':str(len(content))}
        with tempfile.TemporaryDirectory() as d, patch.object(M,'request',return_value=Response(content)) as req:
            target=Path(d)/'file.bin';sha=hashlib.sha256(content).hexdigest()
            M.download('https://example.test/file',target,len(content),sha)
            self.assertEqual(target.read_bytes(),content)
            M.download('https://example.test/file',target,len(content),sha)
            self.assertEqual(req.call_count,1)

    def test_full_setup_with_mocked_official_responses(self):
        # Only the downloader/control flow is tested. These are NOT real model files.
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);archive=root/'mock.tgz'
            with tarfile.open(archive,'w:gz') as tar:
                for name,data in [('package/lib/index.js',b'export const mock=true;'),('package/LICENSE',b'mock license')]:
                    info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
            tgz=archive.read_bytes()
            def get_json(url):
                if 'registry.npmjs.org' in url:
                    return {'dist':{'tarball':'https://example.test/mock.tgz','integrity':'sha512-'+base64.b64encode(hashlib.sha512(tgz).digest()).decode()}}
                if '/tree/' in url:
                    return []
                return {'sha':'a'*40,'siblings':[{'rfilename':'ndarray-cache.json'},{'rfilename':'tokenizer.json'}]}
            def download(url,target,*args):
                target.parent.mkdir(parents=True,exist_ok=True)
                data=tgz if url.endswith('mock.tgz') else b'\x00asm\x01\x00\x00\x00' if url.endswith('.wasm') else json.dumps({'tokenizer_files':['tokenizer.json']}).encode() if target.name=='mlc-chat-config.json' else json.dumps({'records':[{'dataPath':'params_shard_0.bin','nbytes':4}]}).encode() if target.name=='ndarray-cache.json' else b'test'
                target.write_bytes(data)
            with patch.object(M,'ROOT',root),patch.object(M,'STATUS',root/'model-status.json'),patch.object(M,'MANIFEST',root/'ai-files-manifest.json'),patch.object(M,'get_json',side_effect=get_json),patch.object(M,'download',side_effect=download):
                M.prepare()
                self.assertTrue(json.loads((root/'model-status.json').read_text())['ready'])
                self.assertTrue(M.verify(root,quiet=True))


if __name__=='__main__':
    unittest.main(verbosity=2)
