# Test report - 2026-10-17

The delivered non-AI application was tested locally in headless Chromium. The
runtime application itself has no testing-library dependency. All tests listed
below passed against the delivered source. Logs and screenshots are in
`tests/artifacts/`.

## Executed checks

| Suite | Result | Scope |
| --- | --- | --- |
| Pure JavaScript tests | 45 passed | Timer/rewards/break boundaries, schedules, purchase safety, catalog, sample-ledger reconciliation, migration, image validation and study tools |
| Python installer tests | 8 passed | Safe filenames, tar extraction, rejected traversal/symlinks, atomic writes, SHA checks, verified-download reuse, and the setup control flow using tiny mocked responses |
| Main browser suite | 83 passed | Navigation, renamed branding, accumulated pets, rooms/furniture, skin persistence, focus/breaks/rewards, emergency exits, session-only sounds, study tools, parents, backup validation, responsive views and offline shell |
| Extended browser suite | 18 passed | Real pointer drag, keyboard movement, room architecture, rebuild cancel/save, postcard generation/download, imported WAV playback/persistence, audio guards, erase, corrupt-save recovery and mobile focus |

**Total: 154 passing automated checks.** The main browser suite recorded zero
JavaScript page errors, zero console errors and zero external HTTP requests.
The extended suite recorded zero JavaScript page errors. The live WebLLM model
is explicitly NOT covered by these counts.

### Responsive and offline checks

The main Today, World, Shop, Study, Progress and Settings screens were checked at
1440, 1024, 768, 390 and 320 CSS pixels wide. No horizontal page overflow was
found at those widths. The focus planner was opened at each width; the focus
screen also passed a 390-pixel overflow check. Desktop and mobile screenshots
were visually inspected.

After the service worker had installed, the browser was switched to offline mode.
The app reloaded successfully and the world remained interactive. All resources
used during these flows were same-origin. This test is for the app shell, NOT
WebLLM model loading while the server is stopped.

### Important unverified items

Real WebLLM runtime/model downloads were unavailable in this environment.
`python3 prepare_ai.py --verify` correctly returned NOT READY in the delivered
folder. The runtime, GPU library and weights are not bundled. Actual model
initialization, streamed answers, GPU memory/performance and inference on any
physical phone were not tested. Mock installer success must not be interpreted
as a real model being present or a successful inference test.

Tests used Chromium, not a full Safari/Firefox/device matrix. Physical touch,
camera capture and native phone-dialer handoff were not tested on real devices.
A silent three-second WAV fixture was used to test imported audio behavior; the
individual artist recordings are not bundled. Browser eviction of localStorage,
real OS-level parental controls and real app blocking are not supported features.
The local parent PIN and cookie currency are deliberately not tamper-proof.

## Re-run tests

No setup is needed for the Python installer unit tests:

```sh
python3 -m unittest discover -s tests -p 'test_prepare_ai.py'
```

With Node available on the test machine:

```sh
node --test tests/core.test.js tests/data.test.js
```

Browser QA additionally requires the Python Playwright package and a Chromium
executable on the TEST machine. These are not web-app dependencies. Start a
local server, then run:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
# In another terminal, in the same app folder:
python3 tests/browser_smoke.py
python3 tests/browser_extra.py
```

Set `CHROMIUM_PATH` to your browser binary if it is not `/usr/bin/chromium`.
`BALLZ_TEST_URL` can override `http://127.0.0.1:8765/` (include a trailing slash).
The browser suites use isolated profiles with sample data and can overwrite
screenshots/report files under `tests/artifacts/`.

## Suggested real-AI acceptance test after preparation

Run the download script online, then `--verify`. Serve on localhost in a
WebGPU-capable browser. Open Study buddy, load the model, and ask a question about
the sample notes. Check that real tokens stream from the worker. Disconnect the
internet, leave the local server running, and ask another question. Inspect
network requests to confirm local-only URLs. Test Stop, Unload and reload on the
actual target device; verify that the study notes remain saved. Do not ship an
AI-ready claim until this real-device check passes.
