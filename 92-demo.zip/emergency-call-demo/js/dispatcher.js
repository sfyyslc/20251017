/**
 * A deliberately small, deterministic TRAINING simulator, not a triage system.
 * No LLM, network, dispatch, medical procedures, or HTML rendering is used here.
 * Chinese source rules reduce dependence on imperfect English translations.
 */
const patterns = {
  critical: /\b(?:not breathing|isn['\u2019]?t breathing|can(?:not|['\u2019]t) breathe|unconscious|unresponsive|heart attack)\b|\u6ca1\u6709\u547c\u5438|\u7121\u6cd5\u547c\u5438|\u65e0\u6cd5\u547c\u5438|\u4e0d\u80fd\u547c\u5438|\u660f\u8ff7|\u5931\u53bb\u610f\u8bc6|\u5931\u53bb\u610f\u8b58/i,
  fire: /\b(?:fire|flames?|burning|smoke|gas leak)\b|\u7740\u706b|\u8457\u706b|\u8d77\u706b|\u706b\u707e|\u706b\u707d|\u5192\u70df|\u5192\u7159|\u6d53\u70df|\u6fc3\u7159|\u7164\u6c14\u6cc4\u6f0f|\u74e6\u65af\u6d29\u6f0f/i,
  medical: /\b(?:ambulance|injur(?:y|ies|ed)|bleed(?:ing)?|chest pain|fainted|seizure|stroke|hurt|medical emergency)\b|\u6551\u62a4\u8f66|\u6551\u8b77\u8eca|\u53d7\u4f24|\u53d7\u50b7|\u6d41\u8840|\u51fa\u8840|\u80f8\u75db|\u80f8\u53e3\u75db|\u6655\u5012|\u6688\u5012|\u62bd\u6410/i,
  police: /\b(?:police|robbery|robbed|burglar|burglary|breaking in|break[ -]in|attacking|assault|gun|knife|threaten(?:ing|ed)?)\b|\u8b66\u5bdf|\u62a2\u52ab|\u6436\u52ab|\u6301\u5200|\u6301\u67aa|\u6301\u69cd|\u5165\u5ba4|\u5165\u5ba4\u76d7\u7a83|\u5165\u5ba4\u76dc\u7aca|\u88ab\u6253|\u5a01\u80c1|\u5a01\u8105/i,
  traffic: /\b(?:crash(?:ed|ing)?|collisions?|car accident|traffic accident|hit[ -]and[ -]run|car hit|hit by a car)\b|\u8f66\u7978|\u8eca\u798d|\u4ea4\u901a\u4e8b\u6545|\u649e\u8f66|\u649e\u8eca|\u88ab\u8f66\u649e|\u88ab\u8eca\u649e/i,
};

function clean(text) {
  return String(text ?? '').normalize('NFKC').toLowerCase()
    .replace(/\b(?:fire station|fire drill|fire alarm test|fire department|smoke detector test|birthday|fireplace)\b/g, '')
    .replace(/\u6d88\u9632\u6f14\u4e60|\u6d88\u9632\u6f14\u7fd2|\u6d88\u9632\u7ad9/g, '');
}

function inspect(text) {
  let value = clean(text);
  const denied = new Set();
  const clauses = [
    ['fire', /\b(?:no|not a|without|isn['\u2019]?t a)\s+(?:fire|smoke|flames?)\b|\bnot on fire\b|(?:\u6ca1\u6709|\u6c92\u6709|\u4e0d\u662f)(?:\u7740\u706b|\u8457\u706b|\u706b\u707e|\u706b\u707d|\u70df|\u7159)|\u6ca1\u7740\u706b/g],
    ['medical', /\b(?:no|without)\s+(?:injur(?:y|ies)|bleeding)\b|\b(?:not|isn['\u2019]?t) (?:injured|hurt|bleeding)\b|(?:\u6ca1\u6709\u4eba|\u6c92\u6709\u4eba|\u65e0\u4eba|\u7121\u4eba|\u6ca1\u6709|\u6c92\u6709|\u6ca1\u4eba)(?:\u53d7\u4f24|\u53d7\u50b7|\u6d41\u8840)/g],
    ['traffic', /\bno (?:crash(?:ed|ing)?|collisions?|car accident|traffic accident)\b|(?:\u6ca1\u6709|\u6c92\u6709)(?:\u8f66\u7978|\u8eca\u798d|\u4ea4\u901a\u4e8b\u6545)/g],
    ['police', /\bno (?:gun|knife|robbery|burglary)\b|(?:\u6ca1\u6709|\u6c92\u6709)(?:\u62a2\u52ab|\u6436\u52ab|\u67aa|\u69cd)/g],
    ['critical', /\b(?:not|isn['\u2019]?t) (?:unconscious|unresponsive)\b|(?:\u6ca1\u6709|\u6c92\u6709|\u6ca1)(?:\u660f\u8ff7|\u5931\u53bb\u610f\u8bc6|\u5931\u53bb\u610f\u8b58)/g],
  ];
  for (const [category, regex] of clauses) {
    value = value.replace(regex, () => { denied.add(category); return ' '; });
  }
  const hits = new Set(Object.entries(patterns).filter(([, regex]) => regex.test(value)).map(([key]) => key));
  return { hits, denied };
}

/** Priorities are canned scenario selection only, not an emergency-service protocol. */
export function classifyEmergency(original, english = '') {
  const source = inspect(original);
  const translated = inspect(english);
  const hits = new Set(source.hits);
  for (const x of translated.hits) if (!source.denied.has(x)) hits.add(x);
  if (hits.has('critical')) return { category: 'medical', urgent: true };
  for (const category of ['fire', 'police', 'traffic', 'medical']) {
    if (hits.has(category)) return { category, urgent: false };
  }
  return { category: 'unknown', urgent: false };
}

export function createSession() {
  return { turn: 0, category: 'unknown', urgent: false, location: '', safety: '', people: '', awaiting: 'incident', seen: [] };
}

function hasLocation(text) {
  return /\b\d+[a-z]?\s+.{1,35}\b(?:street|st|road|rd|avenue|ave|lane|ln|drive|dr|boulevard|blvd)\b|\b(?:at|near|outside|inside|on)\s+(?:the\s+)?(?:central|main|city|north|south|east|west)\b|(?:\u8def|\u8857|\u5df7|\u9053)\s*\d+\s*\u53f7|(?:\u8def|\u8857|\u5df7|\u9053)\s*\d+\s*\u865f|\u5730\u5740(?:\u662f|:|\uff1a)/i.test(text);
}

function isLocationAnswer(text) {
  if (safetyValue(text) || /\b(?:people|person|breathing|awake|injured|what|why|who)\b|[?\uff1f]|\u53d7\u4f24|\u53d7\u50b7|\u547c\u5438|\u9192\u7740/i.test(text)) return false;
  return !/^(?:yes|no|okay|ok|help|thanks?|thank you|hello|\u662f|\u4e0d\u662f|\u6551\u547d|\u8c22\u8c22)[.!?\s]*$/i.test(text.trim())
    && /\p{L}|\p{N}/u.test(text) && Array.from(text.trim()).length >= 3;
}

function safetyValue(text) {
  if (/\b(?:not safe|unsafe|in danger|still inside|trapped)\b|\u4e0d\u5b89\u5168|\u6709\u5371\u9669|\u88ab\u56f0|\u9084\u5728\u88e1\u9762|\u8fd8\u5728\u91cc\u9762/i.test(text)) return 'not safe';
  if (/\b(?:safe|outside|away from danger)\b|\u5b89\u5168|\u5728\u5916\u9762|\u5df2\u7ecf\u51fa\u6765|\u5df2\u7d93\u51fa\u4f86/i.test(text)) return 'safe';
  return '';
}

const labels = { fire: 'Fire', medical: 'Medical', police: 'Police', traffic: 'Traffic', unknown: 'Unclassified' };
export const categoryLabel = category => labels[category] ?? labels.unknown;

/** Pure state transition. Caller commits it only after translation succeeds. */
export function nextReply(previous, original, english = original) {
  const state = { ...previous, seen: [...previous.seen] };
  const source = String(original).trim();
  const translated = String(english).trim();
  if (!source) throw new Error('Cannot dispatch an empty message.');
  const combined = `${source}\n${translated}`;
  const match = classifyEmergency(source, translated);
  const secondaryInjury = match.category === 'medical' && !match.urgent && ['fire', 'traffic', 'police'].includes(state.category);
  const isNewCategory = match.category !== 'unknown' && match.category !== state.category && !secondaryInjury;
  const escalation = match.urgent && !state.urgent;
  if (isNewCategory) {
    state.category = match.category;
    state.urgent = match.urgent;
    state.people = '';
    state.awaiting = state.location ? (state.safety ? 'people' : 'safety') : 'location';
  } else if (escalation) state.urgent = true;
  state.turn++;
  state.seen.push(source);
  // Bound session metadata; UI keeps the visible transcript independently.
  if (state.seen.length > 30) state.seen.shift();

  const courtesy = /^(?:thanks?(?: you)?|thank you(?: very much)?|\u8c22\u8c22|\u8b1d\u8b1d)[.!\u3002\uff01\s]*$/i.test(source);
  if (courtesy) return { state, reply: 'You are welcome. This is a practice conversation only; no emergency call has been placed.', route: state.category };
  if (state.category === 'unknown') {
    state.awaiting = 'incident';
    return { state, reply: 'Simulated dispatcher: Tell me what happened: a fire, a medical problem, a threat, or a traffic collision. What is the location?', route: 'unknown' };
  }

  const unknownLocation = /\b(?:don['\u2019]?t know|do not know|unsure|not sure|unknown)\b|\u4e0d\u77e5\u9053|\u4e0d\u6e05\u695a/i.test(combined);
  if (!unknownLocation && (hasLocation(combined) || (previous.awaiting === 'location' && !isNewCategory && match.category === 'unknown' && isLocationAnswer(source)))) state.location = source;
  const safety = safetyValue(combined);
  if (safety) state.safety = safety;
  if (previous.awaiting === 'people' && !isNewCategory && !escalation) state.people = source;

  const prefix = `${categoryLabel(state.category)} scenario${state.urgent ? ' (urgent symptoms reported)' : ''}. `;
  let reply;
  if (!state.location) {
    state.awaiting = 'location';
    reply = prefix + (unknownLocation ? 'For this exercise, give a nearby landmark, intersection, or building name.' : 'What is the address or nearest landmark?');
  } else if (!state.safety) {
    state.awaiting = 'safety';
    reply = prefix + 'Location noted for the exercise. Are you in a safe place, away from the immediate danger?';
  } else if (!state.people || escalation) {
    state.awaiting = 'people';
    const questions = {
      fire: 'Is anyone still inside or injured?',
      medical: 'How many people need help, and are they awake and breathing?',
      police: 'Is the person posing the threat still nearby? Is anyone injured?',
      traffic: 'How many vehicles are involved, and is anyone injured?',
    };
    reply = prefix + (state.safety === 'not safe' ? 'You reported that the scene is not safe. ' : '') + questions[state.category];
  } else {
    state.awaiting = 'updates';
    reply = prefix + 'The practice details are noted. Has anything changed? This simulator does not contact or dispatch emergency services.';
  }
  return { state, reply, route: state.category };
}
