/** Pinned library; model files download into browser storage, never a Python backend. */
export const CONFIG = Object.freeze({
  transformersURL: 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/transformers.min.js',
  wasmURL: 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/',
  translation: { id: 'Xenova/opus-mt-zh-en', revision: '39d480d52a9ea3065a1f117adfe4dbc55de10e6f', dtype: 'q8' },
  speechModels: {
    base: { id: 'onnx-community/whisper-base', revision: '1846881b6b3a3024392c1eea3ad983695bc23925' },
    tiny: { id: 'onnx-community/whisper-tiny', revision: 'main' },
    small: { id: 'onnx-community/whisper-small', revision: 'main' },
  },
  maxInputLength: 1200,
  translationChunkLength: 140,
  sampleRate: 16000,
  partialEveryMs: 2200,
  silenceMs: 720,
  maxSegmentMs: 12000,
  minSpeechMs: 240,
  energyThreshold: 0.012,
  maxPendingSegments: 5,
  loadTimeoutMs: 600000,
  inferenceTimeoutMs: 180000,
});
