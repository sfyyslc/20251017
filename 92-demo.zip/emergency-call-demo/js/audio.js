import { PCMResampler, rms } from './audio-core.js';

export class Microphone {
  constructor(onAudio, onLevel) {
    this.onAudio = onAudio; this.onLevel = onLevel;
    this.enabled = false; this.flushID = 0; this.flushWaiters = new Map();
  }
  /** Call directly from the Voice-mode user gesture, before any model awaits. */
  async start() {
    if (!globalThis.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
      throw new Error('Microphone access needs localhost or HTTPS. Open http://localhost:8000, not a plain HTTP LAN address.');
    }
    const AudioContextClass = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!AudioContextClass) throw new Error('This browser has no Web Audio support. Use a current desktop Chrome or Edge.');
    this.context = new AudioContextClass();
    // Resume within the input-mode click, as required by browser autoplay policies.
    const resumed = this.context.resume();
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false });
      if (this.stopped) { this.stream.getTracks().forEach(track => track.stop()); return; }
      await resumed;
      await this.context.audioWorklet.addModule(new URL('./pcm-worklet.js', import.meta.url));
      if (this.stopped) return;
      this.resampler = new PCMResampler(this.context.sampleRate);
      this.source = this.context.createMediaStreamSource(this.stream);
      this.node = new AudioWorkletNode(this.context, 'local-pcm-capture');
      this.node.port.onmessage = ({ data }) => {
        if (data.type === 'flushed') {
          this.flushWaiters.get(data.id)?.(); this.flushWaiters.delete(data.id); return;
        }
        if (data.type === 'pcm' && this.enabled) {
          const samples = this.resampler.push(data.samples);
          this.onLevel(rms(samples)); this.onAudio(samples);
        }
      };
      this.source.connect(this.node); this.node.connect(this.context.destination);
      this.setEnabled(false);
      this.stream.getAudioTracks()[0].addEventListener('ended', () => {
        if (!this.stopped) { this.setEnabled(false); this.onEnded?.(); }
      });
    } catch (error) { this.stop(); throw error; }
  }
  async pauseAndFlush() {
    if (!this.node || !this.enabled) return;
    // Flush the worklet tail while its audio thread is running.
    // The reply acts as a FIFO barrier before capture is paused.
    const id = ++this.flushID;
    await new Promise(resolve => {
      const timer = setTimeout(() => { this.flushWaiters.delete(id); resolve(); }, 500);
      this.flushWaiters.set(id, () => { clearTimeout(timer); resolve(); });
      this.node.port.postMessage({ type: 'flush', id });
    });
    this.setEnabled(false);
    if (this.context?.state === 'running') await this.context.suspend();
  }
  setEnabled(value) {
    this.enabled = Boolean(value) && !this.stopped;
    this.stream?.getTracks().forEach(track => { track.enabled = this.enabled; });
    if (this.enabled && this.context?.state === 'suspended') void this.context.resume();
    if (!this.enabled) this.onLevel(0);
  }
  stop() {
    this.stopped = true; this.enabled = false;
    this.stream?.getTracks().forEach(track => track.stop());
    this.source?.disconnect(); this.node?.disconnect();
    if (this.node) this.node.port.onmessage = null;
    if (this.context && this.context.state !== 'closed') void this.context.close();
    for (const resolve of this.flushWaiters.values()) resolve();
    this.flushWaiters.clear(); this.onLevel(0);
  }
}
