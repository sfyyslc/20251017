/**
 * Transformers.js 3.8.1 does NOT auto-detect Whisper's language when omitted.
 * Compare its initial decoder language-token logits, restricted to en / zh.
 * This is an audio-model decision, unlike the UI's text-script label.
 */
export function chooseSpeechLanguage(logits, englishID, chineseID, vocabularySize) {
  if (!logits?.length || !Number.isInteger(vocabularySize) || vocabularySize < 1 || logits.length % vocabularySize !== 0) throw new Error('Invalid language logits.');
  for (const id of [englishID, chineseID]) if (!Number.isInteger(id) || id < 0 || id >= vocabularySize) throw new Error('Invalid language token ID.');
  const offset = logits.length - vocabularySize;
  const en = Number(logits[offset + englishID]);
  const zh = Number(logits[offset + chineseID]);
  if (!Number.isFinite(en) || !Number.isFinite(zh)) throw new Error('Non-finite language scores. Select a speech language manually.');
  return zh > en ? 'zh' : 'en';
}

function disposeTree(value, seen = new Set()) {
  if (!value || typeof value !== 'object' || ArrayBuffer.isView(value) || seen.has(value)) return;
  seen.add(value);
  if (typeof value.dispose === 'function') { value.dispose(); return; }
  for (const item of Object.values(value)) disposeTree(item, seen);
}

export async function detectSpokenLanguage(asr, Tensor, audio) {
  const config = asr.model.generation_config;
  const startID = config?.decoder_start_token_id ?? asr.model.config.decoder_start_token_id;
  const enID = config?.lang_to_id?.['<|en|>'];
  const zhID = config?.lang_to_id?.['<|zh|>'];
  if (![startID, enID, zhID].every(Number.isInteger)) throw new Error('This model cannot auto-select English / Chinese. Choose a speech language manually.');
  let features, decoder, output;
  try {
    features = await asr.processor(audio);
    decoder = new Tensor('int64', BigInt64Array.from([BigInt(startID)]), [1, 1]);
    // The initial start-of-transcript token predicts the language token.
    output = await asr.model({ ...features, decoder_input_ids: decoder });
    return chooseSpeechLanguage(output.logits.data, enID, zhID, output.logits.dims.at(-1));
  } finally {
    // Including decoder KV caches and encoder outputs matters on WebGPU.
    disposeTree({ features, decoder, output });
  }
}
