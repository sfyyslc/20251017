import { CONFIG } from './config.js';
import { detectLanguage, validateInput, joinTranscript, errorMessage } from './text.js';
import { createSession, nextReply, categoryLabel } from './dispatcher.js';
import { Microphone } from './audio.js';
import { VoiceSegmenter, TranscriptQueue } from './audio-core.js';
import { ModelClient } from './model-client.js';

const $ = id => document.getElementById(id);
const modeInputs = [...document.querySelectorAll('input[name="mode"]')];
let session = createSession();
let mode = 'text';
let processing = false;
let preparing = false;
let modeBusy = false;
let generation = 0;
let mic = null;
let segmenter = null;
let queue = null;
let voicePrefix = '';
let parts = new Map();
let speech = new ModelClient('speech', event => modelProgress('speech', event));
const translation = new ModelClient('translation', event => modelProgress('translation', event));
let assetCacheReady;

function showError(error) {
  $('error').textContent = errorMessage(error);
  $('error').hidden = false;
}
function clearError() { $('error').hidden = true; $('error').textContent = ''; }
function invalidateTranslation() {
  $('english-output').textContent = 'Your English translation will appear here.';
  $('english-output').classList.add('placeholder');
  $('translation-tag').textContent = 'ON SUBMIT';
}
function updateControls() {
  const locked = processing || preparing;
  $('source').readOnly = mode === 'voice' || processing || modeBusy;
  for (const radio of modeInputs) radio.disabled = locked || (modeBusy && mode === 'text');
  // Switching back to Text remains possible while a speech model is downloading.
  $('submit').disabled = locked || modeBusy || (!String($('source').value).trim() && !(mode === 'voice' && mic?.enabled));
  $('reset').disabled = locked;
  $('prepare').disabled = locked || mode === 'voice' || modeBusy;
  for (const id of ['speech-model', 'device', 'speech-language', 'threshold']) $(id).disabled = locked || mode === 'voice' || modeBusy;
  for (const button of document.querySelectorAll('[data-example]')) button.disabled = locked || mode !== 'text' || modeBusy;
  $('mode-badge').textContent = mode === 'voice' ? 'Voice mode' : 'Text mode';
  $('voice-strip').hidden = mode !== 'voice' && !modeBusy;
  const language = detectLanguage($('source').value);
  $('language-badge').textContent = language.label;
  $('language-badge').title = 'Script-based estimate within an English / Chinese-only demo; not universal language identification.';
  const count = Array.from($('source').value).length;
  $('character-count').textContent = `${count} / ${CONFIG.maxInputLength}`;
  $('character-count').style.color = count > CONFIG.maxInputLength ? 'var(--danger)' : '';
}

function modelProgress(kind, event) {
  const status = $(`${kind}-status`);
  const progress = $(`${kind}-progress`);
  if (event.status === 'progress') {
    const percent = Number.isFinite(event.progress) ? Math.round(event.progress) : null;
    const name = String(event.file || 'model file').split('/').pop();
    status.textContent = percent === null ? `Downloading ${name}...` : `${name}: ${percent}% (this file)`;
    progress.hidden = false;
    if (percent === null) progress.removeAttribute('value'); else progress.value = percent;
  } else if (event.message) status.textContent = event.message;
  else if (event.status === 'initiate' || event.status === 'download') {
    status.textContent = `Loading ${String(event.file || 'model').split('/').pop()}...`;
  }
  if (event.status === 'ready') progress.hidden = true;
  $('ai-summary').textContent = speech.ready && translation.ready ? 'Both models ready' : 'Models load on demand';
  if (event.status === 'progress' || event.status === 'runtime') $('ai-summary').textContent = 'Downloading / loading...';
  if (mode === 'voice' && modeBusy && kind === 'speech') $('voice-state').textContent = status.textContent;
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function addDispatcher(text, initial = false) {
  const article = element('article', 'message dispatcher');
  const meta = element('div', 'message-meta');
  meta.append(element('span', 'avatar', 'r.'), element('span', '', initial ? 'SIMULATED DISPATCHER / READY' : 'SIMULATED DISPATCHER'));
  article.append(meta, element('div', 'message-body', text));
  $('chat-log').append(article);
}
function addUser(original, english, language) {
  const article = element('article', 'message user');
  article.append(element('div', 'message-meta', `YOU / ${language.label.toUpperCase()}`));
  const body = element('div', 'message-body');
  const originalNode = element('p', 'message-original', original);
  originalNode.lang = language.code === 'zh' ? 'zh' : 'en';
  body.append(originalNode);
  const englishNode = element('div', 'message-translation');
  englishNode.lang = 'en';
  englishNode.append(element('small', '', language.code === 'en' || language.code === 'und' ? 'ENGLISH / ORIGINAL' : 'ENGLISH TRANSLATION'), element('span', '', english));
  body.append(englishNode); article.append(body); $('chat-log').append(article);
}
function initConversation() {
  $('chat-log').replaceChildren();
  addDispatcher('This is a practice call, not a real emergency line. Tell me what happened and where. You can use English or Chinese.', true);
  $('turn-count').textContent = '00 TURNS'; $('route-label').textContent = 'Awaiting a scenario';
}

function makeVoicePipeline(token) {
  parts = new Map(); voicePrefix = $('source').value.trim();
  const localQueue = new TranscriptQueue(
    audio => speech.transcribe(audio, $('speech-language').value),
    result => {
      if (token !== generation) return;
      const previous = parts.get(result.id);
      if (previous && previous.version > result.version) return;
      // Re-running a growing utterance REPLACES its partial; it never appends it twice.
      parts.set(result.id, result);
      const text = joinTranscript([voicePrefix, ...[...parts.entries()].sort((a, b) => a[0] - b[0]).map(([, item]) => item.text)]);
      if (text !== $('source').value) { $('source').value = text; invalidateTranslation(); }
      $('voice-state').textContent = processing ? 'Finishing the last phrase...' : `Listening locally${result.latencyMs ? ` / last pass ${(result.latencyMs / 1000).toFixed(1)}s` : ''}`;
      updateControls();
      if (Array.from(text).length > CONFIG.maxInputLength) failVoice(new Error('The message reached the length limit. Listening stopped; shorten the preserved text before submitting.'));
    },
    error => { if (token === generation) failVoice(error); },
  );
  queue = localQueue;
  segmenter = new VoiceSegmenter(segment => localQueue.enqueue(segment), { energyThreshold: Number($('threshold').value) });
}
function failVoice(error) {
  ++generation;
  mic?.stop(); mic = null; queue?.close(); queue = null; segmenter = null;
  speech.terminate(error);
  mode = 'text'; modeBusy = false;
  modeInputs.forEach(radio => { radio.checked = radio.value === mode; });
  showError(error); updateControls();
}
async function startVoice() {
  clearError();
  mode = 'voice'; modeBusy = true;
  const token = ++generation;
  $('voice-state').textContent = 'Allow microphone access. Loading speech model...';
  makeVoicePipeline(token);
  const localMic = new Microphone(
    samples => { if (token === generation) segmenter?.push(samples); },
    level => { $('meter-fill').style.width = `${Math.min(100, Math.round(level * 900))}%`; },
  );
  mic = localMic;
  localMic.onEnded = () => { if (token === generation) failVoice(new Error('The microphone disconnected or permission was revoked. The partial transcript is preserved.')); };
  // Start/resume AudioContext inside the mode-change user gesture.
  const started = localMic.start();
  updateControls();
  try {
    await started;
    if (token !== generation) { localMic.stop(); return; }
    await assetCacheReady;
    if (token !== generation) return;
    await speech.load({ model: $('speech-model').value, device: $('device').value });
    if (token !== generation) return;
    modeBusy = false; localMic.setEnabled(true);
    $('voice-state').textContent = 'Listening locally / speak naturally, pause between phrases';
    $('input-help').textContent = 'Live partials may be revised. Select Text to stop listening and edit.';
    updateControls();
  } catch (error) { if (token === generation) failVoice(error); }
}
async function stopVoice({ flush = true } = {}) {
  const token = generation;
  const localMic = mic;
  if (modeBusy) {
    // Do not wait for an entire model download just to turn the microphone off.
    ++generation; localMic?.stop(); mic = null; queue?.close(); queue = null; segmenter = null;
    mode = 'text'; modeBusy = false; updateControls(); return;
  }
  mode = 'text'; modeBusy = true; $('voice-state').textContent = 'Finishing the last phrase...'; updateControls();
  try {
    if (flush) {
      await localMic?.pauseAndFlush();
      segmenter?.flush();
      await queue?.drain();
    }
  } catch (error) { showError(error); }
  finally {
    if (token === generation) {
      ++generation; localMic?.stop(); mic = null; queue?.close(); queue = null; segmenter = null;
      mode = 'text'; modeBusy = false;
      $('input-help').textContent = 'Your original text stays visible. Use fictional details.';
      updateControls();
    }
  }
}

for (const radio of modeInputs) radio.addEventListener('change', () => {
  if (radio.value === 'voice') void startVoice();
  else void stopVoice();
});
$('source').addEventListener('input', () => { clearError(); invalidateTranslation(); updateControls(); });
$('source').addEventListener('keydown', event => {
  if (!event.isComposing && event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
    event.preventDefault(); if (!$('submit').disabled) $('message-form').requestSubmit();
  }
});
const examples = {
  fire: '\u6211\u5bb6\u7740\u706b\u4e86\u3002',
  medical: '\u6211\u7238\u7238\u660f\u8ff7\u4e86\uff0c\u8bf7\u6d3e\u6551\u62a4\u8f66\u3002',
  traffic: 'Two cars crashed at 25 Oak Street.',
  police: '\u6709\u4eba\u6b63\u5728\u5165\u5ba4\u62a2\u52ab\u3002',
};
for (const button of document.querySelectorAll('[data-example]')) button.addEventListener('click', () => {
  $('source').value = examples[button.dataset.example]; clearError(); invalidateTranslation(); updateControls(); $('source').focus();
});

$('message-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (processing || preparing || modeBusy) return;
  clearError(); processing = true;
  const token = generation;
  const submittedFromVoice = mode === 'voice';
  let attemptedTranslation = false;
  $('submit').textContent = submittedFromVoice ? 'Finishing speech...' : 'Translating...';
  $('thinking').hidden = false;
  $('thinking').textContent = submittedFromVoice ? 'Finishing speech, then translating locally...' : 'Preparing your message locally...';
  updateControls();
  try {
    if (submittedFromVoice) {
      await mic?.pauseAndFlush();
      segmenter?.flush();
      await queue?.drain();
      if (token !== generation) throw new Error('Voice input was interrupted. Review the preserved text and submit again.');
    }
    const original = validateInput($('source').value);
    const language = detectLanguage(original);
    let english = original;
    if (language.code === 'zh') {
      attemptedTranslation = true;
      $('thinking').textContent = 'Translating Chinese to English in this browser...';
      await assetCacheReady;
      const result = await translation.translate(original);
      english = result.text.trim();
      if (!english) throw new Error('Translation returned no text. Your message was not submitted.');
    }
    const result = nextReply(session, original, english);
    // Commit as one UI transaction: no half-submitted turns if translation failed.
    session = result.state;
    addUser(original, english, language); addDispatcher(result.reply);
    $('english-output').textContent = english; $('english-output').classList.remove('placeholder');
    $('translation-tag').textContent = language.code === 'zh' ? 'CHINESE \u2192 ENGLISH' : 'ALREADY ENGLISH / UNCHANGED';
    $('route-label').textContent = `${categoryLabel(session.category)} / ${session.awaiting === 'updates' ? 'details noted' : `awaiting ${session.awaiting}`}`;
    $('turn-count').textContent = `${String(session.turn).padStart(2, '0')} ${session.turn === 1 ? 'TURN' : 'TURNS'}`;
    $('source').value = '';
    if (submittedFromVoice && token === generation) makeVoicePipeline(token);
    $('chat-log').scrollTop = $('chat-log').scrollHeight;
  } catch (error) {
    if (attemptedTranslation) translation.terminate(error);
    showError(error);
    // On a voice submission failure, switch to editable text and preserve everything.
    if (submittedFromVoice && token === generation) {
      mic?.stop(); mic = null; queue?.close(); queue = null; segmenter = null;
      ++generation; mode = 'text'; modeBusy = false;
      modeInputs.forEach(radio => { radio.checked = radio.value === 'text'; });
    }
  } finally {
    processing = false; $('thinking').hidden = true;
    $('submit').replaceChildren(document.createTextNode('Submit to chat '), element('span', '', '\u2197'));
    if (submittedFromVoice && mode === 'voice' && token === generation) {
      mic?.setEnabled(true); $('voice-state').textContent = 'Listening locally / ready for the next message';
    }
    updateControls();
  }
});

$('reset').addEventListener('click', () => {
  ++generation; mic?.stop(); mic = null; queue?.close(); queue = null; segmenter = null;
  mode = 'text'; modeBusy = false; parts.clear(); session = createSession();
  modeInputs.forEach(radio => { radio.checked = radio.value === 'text'; });
  $('source').value = ''; $('input-help').textContent = 'Your original text stays visible. Use fictional details.';
  clearError(); invalidateTranslation(); initConversation(); updateControls();
});
for (const id of ['speech-model', 'device']) $(id).addEventListener('change', () => {
  speech.terminate(); speech = new ModelClient('speech', event => modelProgress('speech', event));
  $('speech-status').textContent = 'Not loaded'; $('speech-progress').hidden = true; $('ai-summary').textContent = 'Models load on demand';
});
$('threshold').addEventListener('input', () => { $('threshold-value').textContent = Number($('threshold').value).toFixed(3); });
$('prepare').addEventListener('click', async () => {
  if (preparing || processing) return;
  preparing = true; clearError(); updateControls();
  $('prepare').textContent = 'Preparing models...';
  try {
    await assetCacheReady;
    await speech.load({ model: $('speech-model').value, device: $('device').value });
    await translation.load();
    $('ai-summary').textContent = 'Both models ready';
    $('cache-status').textContent = 'Models are ready in this session. For offline use, reload once while online, then run AI checks with external internet blocked. Keep the local Python server running.';
  } catch (error) { showError(error); $('ai-summary').textContent = 'Model loading failed'; }
  finally { preparing = false; $('prepare').textContent = 'Prepare both AI models'; updateControls(); }
});

document.addEventListener('visibilitychange', () => {
  if (document.hidden && mode === 'voice' && !processing) {
    void stopVoice({ flush: true }).then(() => {
      modeInputs.forEach(radio => { radio.checked = radio.value === 'text'; });
      if (!document.hidden) showError(new Error('Listening stopped when this tab was hidden. Review the transcript and select Voice to resume.'));
    });
  }
});
window.addEventListener('pagehide', () => { mic?.stop(); queue?.close(); });

async function initializeAssetCache() {
  if (!('serviceWorker' in navigator)) {
    $('cache-status').textContent = 'Application caching is unavailable. An internet connection may be required on every reload.';
    return;
  }
  try {
    await navigator.serviceWorker.register(new URL('../sw.js', import.meta.url), { scope: new URL('../', import.meta.url).pathname });
    await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller) {
      await new Promise(resolve => {
        const timer = setTimeout(resolve, 3000);
        navigator.serviceWorker.addEventListener('controllerchange', () => { clearTimeout(timer); resolve(); }, { once: true });
      });
    }
    $('cache-status').textContent = navigator.serviceWorker.controller
      ? 'Application caching is active. AI model files cache separately on first successful load. Offline operation depends on retained browser caches.'
      : 'Reload once before loading AI to enable application caching. Model files cache separately.';
  } catch {
    $('cache-status').textContent = 'Application cache setup failed. The app can still run online; offline reloads are not guaranteed.';
  }
}
initConversation(); updateControls();
assetCacheReady = initializeAssetCache();
