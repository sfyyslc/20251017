import { CONFIG } from './config.js';

/** Streaming linear resampler. Carries fractional position across worklet frames. */
export class PCMResampler {
  constructor(inputRate, outputRate = CONFIG.sampleRate) {
    if (!(inputRate > 0) || !(outputRate > 0)) throw new Error('Invalid sample rate.');
    this.step = inputRate / outputRate;
    this.position = 0;
    this.buffer = new Float32Array(0);
  }
  push(frame) {
    const buffer = new Float32Array(this.buffer.length + frame.length);
    buffer.set(this.buffer); buffer.set(frame, this.buffer.length);
    const out = [];
    while (this.position + 1 < buffer.length) {
      const index = Math.floor(this.position);
      const fraction = this.position - index;
      out.push(buffer[index] * (1 - fraction) + buffer[index + 1] * fraction);
      this.position += this.step;
    }
    const consumed = Math.min(Math.floor(this.position), buffer.length);
    this.buffer = buffer.slice(consumed);
    this.position -= consumed;
    return new Float32Array(out);
  }
}

export function rms(samples) {
  if (!samples.length) return 0;
  let sum = 0;
  for (const sample of samples) sum += sample * sample;
  return Math.sqrt(sum / samples.length);
}

function concat(frames) {
  const out = new Float32Array(frames.reduce((n, x) => n + x.length, 0));
  let offset = 0;
  for (const frame of frames) { out.set(frame, offset); offset += frame.length; }
  return out;
}

/** Energy-gated pseudo-streaming. Silence finalizes; partials replace a segment. */
export class VoiceSegmenter {
  constructor(onSegment, options = {}) {
    this.options = { ...CONFIG, ...options };
    this.onSegment = onSegment;
    this.nextID = 1;
    this.reset();
  }
  reset() {
    this.frames = []; this.total = 0; this.voiced = 0;
    this.silence = 0; this.lastPartial = 0; this.version = 0;
    this.preRoll = []; this.preLength = 0; this.id = null;
  }
  snapshot(final) {
    if (this.voiced * 1000 / this.options.sampleRate < this.options.minSpeechMs) return;
    this.onSegment({ id: this.id, version: ++this.version, audio: concat(this.frames), final });
  }
  push(frame) {
    if (!frame.length) return;
    const rate = this.options.sampleRate;
    const isVoice = rms(frame) >= this.options.energyThreshold;
    if (this.id === null && !isVoice) {
      this.preRoll.push(frame.slice()); this.preLength += frame.length;
      while (this.preLength > rate * 0.22 && this.preRoll.length > 1) this.preLength -= this.preRoll.shift().length;
      return;
    }
    if (this.id === null) {
      this.id = this.nextID++;
      this.frames = this.preRoll; this.total = this.preLength;
      this.preRoll = []; this.preLength = 0;
    }
    this.frames.push(frame.slice()); this.total += frame.length;
    if (isVoice) { this.voiced += frame.length; this.silence = 0; } else this.silence += frame.length;
    if (this.silence * 1000 / rate >= this.options.silenceMs || this.total * 1000 / rate >= this.options.maxSegmentMs) {
      this.flush();
    } else if ((this.total - this.lastPartial) * 1000 / rate >= this.options.partialEveryMs) {
      this.snapshot(false); this.lastPartial = this.total;
    }
  }
  flush() { if (this.id !== null) this.snapshot(true); this.reset(); }
}

/** Only one inference in flight. Pending partials for the same segment coalesce. */
export class TranscriptQueue {
  constructor(recognize, onText, onError, maxPending = CONFIG.maxPendingSegments) {
    this.recognize = recognize; this.onText = onText; this.onError = onError;
    this.maxPending = maxPending; this.pending = new Map(); this.running = false;
    this.waiters = []; this.closed = false; this.error = null;
  }
  enqueue(segment) {
    if (this.closed || this.error) return;
    if (!this.pending.has(segment.id) && this.pending.size >= this.maxPending) {
      this.fail(new Error('Speech is arriving faster than this device can transcribe. Listening has stopped. Submitted text is unchanged; review the partial transcript, or choose the Tiny model and try again.'));
      return;
    }
    this.pending.set(segment.id, segment);
    void this.pump();
  }
  fail(error) {
    if (this.closed || this.error) return;
    this.error = error; this.pending.clear(); this.onError(error); this.settle();
  }
  async pump() {
    if (this.running || this.closed || this.error) return;
    this.running = true;
    try {
      while (this.pending.size && !this.closed && !this.error) {
        const [id, segment] = this.pending.entries().next().value;
        this.pending.delete(id);
        const result = await this.recognize(segment.audio);
        if (!this.closed && !this.error) this.onText({ ...segment, audio: undefined, text: result.text ?? '', latencyMs: result.latencyMs });
      }
    } catch (error) { this.fail(error); }
    finally { this.running = false; this.settle(); }
  }
  settle() {
    if (!this.running && !this.pending.size || this.closed || this.error) {
      for (const waiter of this.waiters.splice(0)) this.error ? waiter.reject(this.error) : waiter.resolve();
    }
  }
  drain() {
    if (this.error) return Promise.reject(this.error);
    if (!this.running && !this.pending.size) return Promise.resolve();
    return new Promise((resolve, reject) => this.waiters.push({ resolve, reject }));
  }
  close() { this.closed = true; this.pending.clear(); this.settle(); }
}
