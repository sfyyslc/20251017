import { CONFIG } from './config.js';

/** Restricted English/Chinese script estimate, NOT a universal language detector. */
export function detectLanguage(text) {
  const value = String(text ?? '').normalize('NFKC');
  if (/\p{Script=Hiragana}|\p{Script=Katakana}|\p{Script=Hangul}|\p{Script=Cyrillic}|\p{Script=Arabic}/u.test(value)) {
    return { code: 'unsupported', label: 'Outside English / Chinese scope' };
  }
  if (/\p{Script=Han}/u.test(value)) {
    return { code: 'zh', label: /[a-z]/i.test(value) ? 'Chinese + Latin text' : 'Chinese' };
  }
  if (/[a-z]/i.test(value)) return { code: 'en', label: 'English' };
  return { code: 'und', label: value.trim() ? 'Language undetermined' : 'Waiting for input' };
}

export function validateInput(text) {
  const value = String(text ?? '').trim();
  if (!value) throw new Error('Enter text or speak before submitting.');
  if (Array.from(value).length > CONFIG.maxInputLength) {
    throw new Error(`Please keep each message under ${CONFIG.maxInputLength} characters. Your input has been kept.`);
  }
  if (detectLanguage(value).code === 'unsupported') {
    throw new Error('This demo supports English and Chinese only. Your input has been kept.');
  }
  return value;
}

/** Split long Chinese input without silently truncating the model's token window. */
export function splitForTranslation(text, limit = CONFIG.translationChunkLength) {
  if (!Number.isInteger(limit) || limit < 8) throw new Error('Chunk limit must be at least 8.');
  const chars = Array.from(String(text).trim());
  const result = [];
  while (chars.length) {
    if (chars.length <= limit) { result.push(chars.splice(0).join('')); break; }
    let cut = limit;
    for (let i = limit - 1; i >= Math.floor(limit / 2); i--) {
      if (/[\s\u3002\uff01\uff1f.!?;,\uff0c\uff1b]/u.test(chars[i])) { cut = i + 1; break; }
    }
    const part = chars.splice(0, cut).join('').trim();
    if (part) result.push(part);
  }
  return result;
}

export function joinTranscript(parts) {
  return parts.map(x => x.trim()).filter(Boolean).join(' ').replace(/([\p{Script=Han}]) ([\p{Script=Han}])/gu, '$1$2').trim();
}

export function errorMessage(error) {
  const name = error?.name;
  if (name === 'NotAllowedError' || name === 'PermissionDeniedError') return 'Microphone permission was denied. Allow the microphone in your browser site settings, then select Voice again. Text input still works.';
  if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return 'No microphone was found. Connect one, then select Voice again.';
  if (name === 'NotReadableError') return 'The microphone is unavailable or is being used by another application. Text input still works.';
  return error?.message || String(error) || 'Something went wrong. Your input has been kept.';
}
