import { CONFIG } from './config.js';
import { splitForTranslation, detectLanguage } from './text.js';
import { detectSpokenLanguage } from './speech-language.js';

let library = null;
let model = null;
let modelKind = null;
let backend = null;
let chain = Promise.resolve();

async function getLibrary() {
  if (!library) {
    library = await import(CONFIG.transformersURL);
    library.env.allowLocalModels = false;
    library.env.useBrowserCache = true;
    // Python's stock server supplies no COOP/COEP headers: single-thread WASM is intentional.
    library.env.backends.onnx.wasm.numThreads = 1;
    library.env.backends.onnx.wasm.proxy = false;
    library.env.backends.onnx.wasm.wasmPaths = CONFIG.wasmURL;
  }
  return library;
}

async function run({ id, type, payload = {} }) {
  const progress = data => self.postMessage({ id, type: 'progress', data });
  if (type === 'load') {
    if (model) return { backend, kind: modelKind };
    progress({ status: 'runtime', message: 'Loading the pinned browser AI runtime...' });
    const { pipeline } = await getLibrary();
    modelKind = payload.kind;
    if (modelKind === 'translation') {
      backend = 'wasm';
      model = await pipeline('translation', CONFIG.translation.id, {
        revision: CONFIG.translation.revision, device: backend, dtype: CONFIG.translation.dtype,
        progress_callback: progress,
      });
    } else if (modelKind === 'speech') {
      const info = CONFIG.speechModels[payload.model || 'base'];
      if (!info) throw new Error('Unknown speech model.');
      backend = payload.device || 'wasm';
      model = await pipeline('automatic-speech-recognition', info.id, {
        revision: info.revision, device: backend,
        dtype: backend === 'webgpu' ? { encoder_model: 'fp32', decoder_model_merged: 'q4' } : 'q8',
        progress_callback: progress,
      });
    } else throw new Error('Unknown model purpose.');
    return { backend, kind: modelKind };
  }
  if (!model) throw new Error('Load the model before running inference.');
  const started = performance.now();
  if (type === 'transcribe' && modelKind === 'speech') {
    const options = { task: 'transcribe', return_timestamps: false, max_new_tokens: 192, do_sample: false };
    const language = payload.language === 'zh' || payload.language === 'en'
      ? payload.language
      : await detectSpokenLanguage(model, library.Tensor, payload.audio);
    options.language = language === 'zh' ? 'chinese' : 'english';
    const result = await model(payload.audio, options);
    return { text: result.text.trim(), language, latencyMs: Math.round(performance.now() - started) };
  }
  if (type === 'translate' && modelKind === 'translation') {
    const pieces = splitForTranslation(payload.text);
    const output = [];
    for (let i = 0; i < pieces.length; i++) {
      progress({ status: 'translation', message: `Translating part ${i + 1} of ${pieces.length}...` });
      if (detectLanguage(pieces[i]).code !== 'zh') { output.push(pieces[i]); continue; }
      const result = await model(pieces[i], { max_new_tokens: 256, num_beams: 1, do_sample: false });
      const text = result?.[0]?.translation_text?.trim();
      if (!text) throw new Error('The translation model returned no text. Review your input and try again.');
      output.push(text);
    }
    return { text: output.join(' '), latencyMs: Math.round(performance.now() - started) };
  }
  throw new Error('Unsupported worker request.');
}

self.onmessage = ({ data }) => {
  // Serialize all operations, even when the caller accidentally sends overlapping requests.
  chain = chain.then(async () => {
    try { self.postMessage({ id: data.id, type: 'result', data: await run(data) }); }
    catch (error) { self.postMessage({ id: data.id, type: 'error', message: error?.message || String(error) }); }
  });
};
