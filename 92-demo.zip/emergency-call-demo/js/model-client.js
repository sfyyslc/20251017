import { CONFIG } from './config.js';

export class ModelClient {
  constructor(kind, onProgress = () => {}) {
    this.kind = kind; this.onProgress = onProgress; this.nextID = 1;
    this.pending = new Map(); this.ready = false; this.loading = null;
  }
  spawn() {
    if (this.worker) return;
    this.worker = new Worker(new URL('./ai-worker.js', import.meta.url), { type: 'module', name: `local-${this.kind}` });
    this.worker.onmessage = ({ data }) => {
      const request = this.pending.get(data.id);
      if (!request) return;
      if (data.type === 'progress') { this.onProgress(data.data); return; }
      clearTimeout(request.timer); this.pending.delete(data.id);
      if (data.type === 'error') request.reject(new Error(data.message)); else request.resolve(data.data);
    };
    this.worker.onerror = event => {
      event.preventDefault();
      this.terminate(new Error(event.message || 'AI worker failed. Check that the CDN is reachable.'));
    };
  }
  request(type, payload = {}, timeout = CONFIG.inferenceTimeoutMs, transfer = []) {
    this.spawn();
    const id = this.nextID++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.terminate(new Error('AI operation timed out. Your input has been kept. Try the Tiny speech model or CPU mode, and check network access.')), timeout);
      this.pending.set(id, { resolve, reject, timer });
      try { this.worker.postMessage({ id, type, payload }, transfer); }
      catch (error) { clearTimeout(timer); this.pending.delete(id); reject(error); }
    });
  }
  async load(options = {}) {
    if (this.ready) return { backend: this.backend };
    if (this.loading) return this.loading;
    this.loading = this.performLoad(options).finally(() => { this.loading = null; });
    return this.loading;
  }
  async performLoad(options) {
    let device = 'wasm';
    if (this.kind === 'speech' && options.device !== 'wasm' && navigator.gpu) {
      try { if (await navigator.gpu.requestAdapter()) device = 'webgpu'; } catch { /* WASM remains available. */ }
    }
    try {
      let result;
      try { result = await this.request('load', { kind: this.kind, ...options, device }, CONFIG.loadTimeoutMs); }
      catch (error) {
        if (device !== 'webgpu') throw error;
        // Retry in a NEW worker: a failed ONNX initialization can poison its singleton.
        this.terminate(error);
        this.onProgress({ status: 'fallback', message: 'GPU initialization failed; retrying with single-thread CPU / WASM. This may be slower.' });
        result = await this.request('load', { kind: this.kind, ...options, device: 'wasm' }, CONFIG.loadTimeoutMs);
      }
      this.ready = true; this.backend = result.backend;
      this.onProgress({ status: 'ready', message: `Ready on ${result.backend === 'webgpu' ? 'WebGPU' : 'CPU / WASM'}.` });
      return result;
    } catch (error) {
      this.terminate(error);
      throw new Error(`Could not load the ${this.kind} model. First use needs access to cdn.jsdelivr.net and huggingface.co; allow downloads, or retry after reconnecting. ${error.message}`);
    }
  }
  async translate(text) { await this.load(); return this.request('translate', { text }); }
  async transcribe(audio, language) {
    // Transfer a copy; the segmenter's source buffers remain available for its final pass.
    const copy = new Float32Array(audio);
    return this.request('transcribe', { audio: copy, language }, CONFIG.inferenceTimeoutMs, [copy.buffer]);
  }
  terminate(error = new Error('Operation cancelled.')) {
    this.worker?.terminate(); this.worker = null; this.ready = false;
    for (const request of this.pending.values()) { clearTimeout(request.timer); request.reject(error); }
    this.pending.clear();
  }
}
