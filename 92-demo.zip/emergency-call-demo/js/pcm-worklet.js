/* No audio is played back or sent to a server. Frames are transferred locally. */
class PCMWorklet extends AudioWorkletProcessor {
  constructor() {
    super();
    this.buffer = new Float32Array(2048); this.offset = 0;
    this.port.onmessage = event => {
      if (event.data?.type === 'flush') {
        if (this.offset) {
          const tail = this.buffer.slice(0, this.offset);
          this.port.postMessage({ type: 'pcm', samples: tail }, [tail.buffer]);
          this.offset = 0;
        }
        this.port.postMessage({ type: 'flushed', id: event.data.id });
      }
    };
  }
  process(inputs, outputs) {
    const channels = inputs[0];
    // Explicit zero output prevents microphone feedback.
    for (const output of outputs) for (const channel of output) channel.fill(0);
    if (!channels?.length) return true;
    for (let i = 0; i < channels[0].length; i++) {
      let sample = 0;
      for (const channel of channels) sample += channel[i] || 0;
      this.buffer[this.offset++] = sample / channels.length;
      if (this.offset === this.buffer.length) {
        const ready = this.buffer;
        this.port.postMessage({ type: 'pcm', samples: ready }, [ready.buffer]);
        this.buffer = new Float32Array(2048); this.offset = 0;
      }
    }
    return true;
  }
}
registerProcessor('local-pcm-capture', PCMWorklet);
