# Target-computer acceptance checklist

Start `python3 -m http.server 8000` in the project root and open `http://localhost:8000`. Use fictional information. These checks are intentionally separate from the synthetic automated tests.

## 1. Deterministic baseline, no model downloads

Keep Text selected. Submit each line separately:

| Input | Expected result |
| --- | --- |
| My house is on fire. | Original English displayed; English unchanged; Fire asks location |
| 25 Oak Street | Location noted; asks about safety |
| I am outside and safe. | Asks whether anyone is inside or injured |
| Everyone is outside. No injuries. | Practice details noted; asks for updates |

The Network tab should show no AI runtime/weight download for this English-only flow. New session resets the conversation. Repeating a scenario should not duplicate text. Input containing `<img src=x onerror=alert(1)>` must appear as text, never an element.

## 2. Actual Chinese translation

Open `tests/ai.html`, run the six actual translation checks, and read all outputs. A PASS checks only selected words, not full meaning. Pay special attention to the negated fire statement and address number. These are real network/model operations, not the automated fixture.

On the main page, start a new session and submit:

| Original Chinese | Intended meaning | Expected route/progression |
| --- | --- | --- |
| 我家着火了。 | My house is on fire. | Fire; location |
| 人民路25号 | 25 Renmin Road | Safety |
| 我在外面，很安全 | I am outside and safe. | People |
| 没有人受伤 | Nobody is injured. | Updates |

The English translation area must remain empty until Submit. The chat must retain the original Chinese even after the input clears. Route selection may still succeed when translation quality is poor because original Chinese rules are also used; therefore a correct route is not proof of a correct translation.

Reset between these independent scenarios:

| Input | Expected canned category |
| --- | --- |
| 我爸爸昏迷了。 | Medical, urgent symptoms |
| 有人正在入室抢劫。 | Police |
| 这里发生了交通事故。 | Traffic |
| 没有火灾。 | Unclassified, not Fire |

## 3. Actual voice and language selection

Select Chinese speech language, then Voice. Accept microphone permission and wait for Listening locally. There is no Record button. Say the first Chinese fire sentence above, pause, and watch the original transcript appear. Before Submit, no English translation or new chat turn should appear. Submit and check the English translation, source preservation, canned reply, and resumed listening for the next turn.

Repeat with English, then Auto for both languages. Include a number and address; inspect them rather than assuming the model preserved them. Auto makes an additional initial-logits inference, so compare its delay to the forced-language setting. A wrong Auto choice can be bypassed with the explicit selector.

Also test a 10-second utterance, quiet speech, background noise, silence, and a sentence crossing a 12-second segment boundary. Check partial revisions do not duplicate phrases. The energy gate may need adjustment. If processing falls behind, the queue should report a backlog error and preserve text rather than silently pretend transcription is current.

Select Text while speaking. Listening must stop, and text becomes editable after finalizing the last phrase. Deny permission in a fresh profile: an actionable error should appear and typed chat should continue to work. Unplug the microphone to check graceful recovery. Close the page and confirm the browser microphone indicator turns off.

The AI checks page also accepts a local audio file up to 12 seconds and an optional expected transcript. The file stays in the browser. That isolates ASR from live microphone capture but does not replace the live check.

## 4. Network failure and offline reuse

On a fresh profile, block external downloads and submit Chinese. The app should report a model-load failure without inventing a translation or discarding input. English text should remain usable.

Restore access, prepare both models, exercise Chinese translation and actual speech, and reload online once. Keep Python running but disconnect external internet. Retry both AI checks and a Chinese chat. Record whether runtime, configurations, tokenizers, and weights are all available. Use the same profile, origin, and port. Do not claim offline readiness unless actual inference succeeds after reload.

## 5. Record the result

Record browser/OS/GPU, model/backend, language mode, first-load success, warm-start success, actual translations/transcripts, partial/final latency, and offline result. Use the exact fixture sentences only as a baseline; add examples from the intended users and environment. No result makes this simulator suitable for real emergency handling.
