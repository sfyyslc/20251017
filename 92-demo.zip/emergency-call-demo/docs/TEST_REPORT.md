# Test report

## Result summary

This package's automated test results establish its deterministic chat behavior and UI orchestration, not the quality or compatibility of real neural inference.

| Check | Result | What actually ran |
| --- | --- | --- |
| Unit suite, Node.js | 125 passed / 0 failed | Real pure JS modules |
| Same unit suite, Chromium | 125 passed / 0 failed | Real modules through in-memory source loader |
| Browser integration suite | 29 passed / 1 skipped / 0 failed | Real DOM, rules, app/client/worker logic, synthetic AI and microphone |
| Local static assets | 70 passed / 0 failed | HTTP fetches with Python standard library, syntax and path checks |
| Neural translation and ASR | NOT RUN | Network unavailable to execution environment |
| Actual microphone and AudioWorklet | NOT RUN | Capture blocked by managed browser policy |
| Real WebGPU / CPU model execution | NOT RUN | No runtime/weights available |
| Native module loading in browser | NOT RUN | Browser navigation blocked by managed policy |
| Offline shell-navigation check | SKIPPED | Browser navigation blocked |
| Offline model-cache reuse | NOT RUN | Real model loading unavailable |

Machine-readable evidence: `tests/unit-results.json`, `tests/browser-results.json`, and `tests/static-results.json`. Test durations are synthetic test timings, not speech/translation performance measurements.

## Deterministic coverage

The unit suite exercises English, simplified Chinese, and traditional Chinese scenario routing; selected English/Chinese negations; fire/drill exclusions; medical priority; context-preserving secondary injuries; unknown inputs; courtesy; multi-turn location/safety/people progression; category changes; session bounds; unsupported scripts; Unicode length checks; translation splitting; transcript joining; resampling; energy thresholds; pre-roll; partial/final segment versions; silence and maximum duration; serialized queue execution; coalescing; backpressure; errors; and English/Chinese language-logit selection with temporary-tensor disposal.

The dispatcher is tested as a small deterministic state machine. This does not prove coverage of arbitrary natural-language phrasing, and those rules must not be used for real triage.

The browser suite exercises the full four-turn English flow without models, a four-turn Chinese flow with clearly synthetic translations, scenario buttons, original/English display, submit gating, duplicate submit prevention, input preservation after errors, keyboard and Chinese IME handling, HTML-injection prevention, reset, model download errors, microphone-denial recovery, cancellation during loading, synthetic continuous audio flow, finalization on submit, language hints, simulated GPU-load fallback, and mobile layout.

## Environment and substitutions

The execution environment provided Python 3.13, Node 22, Python Playwright, and Chromium. Code-execution downloads from Hugging Face/jsDelivr could not resolve. Managed Chromium policies block URL navigation (including localhost) and audio capture. Those policies were not changed.

`DEMO_TEST_IN_MEMORY=1` was therefore used for the recorded browser results:

1. `tests/memory_harness.py` injects the local HTML/CSS into an allowed blank document and loads source modules as isolated closures. This is not a native ESM-loading test.
2. The actual `app.js`, dispatcher, audio-core utilities, ModelClient, and AI-worker logic execute. The worker uses a classic Blob source bundle in this harness rather than the production module-worker loader.
3. The microphone adapter supplies synthetic PCM; it does not execute the real getUserMedia / AudioWorklet capture chain.
4. `tests/fake-transformers.js` supplies labelled synthetic translations, transcripts, language logits, timing, and injected failures. No neural model is downloaded or evaluated. The production app never imports this fixture.
5. Service-worker navigation and offline reload cannot be exercised in this mode, so that check is explicitly SKIP, not PASS.

Normal `python3 tests/browser_tests.py` supports an ordinary static server in an unrestricted maintainer environment. It still uses synthetic AI outputs and Chromium's fake audio device; it is an integration test, not an accuracy benchmark. Running the application itself never requires these maintainer dependencies.

## What remains to validate on the target computer

Use the included `tests/ai.html` with the real runtime and model weights. Verify a Chinese translation preserves incident, negation, and location; transcribe both English and Mandarin audio; and compare forced-language versus Auto results. The two-language initial-logits detection path is source-reviewed and unit-tested with synthetic tensors, but actual ONNX model execution is unverified here.

Then use the main page with a real microphone. Check microphone permission, real AudioWorklet loading, the quiet/noise threshold, spoken names/numbers, phrase boundaries, CPU backlog behavior, WebGPU-to-CPU fallback, and immediate stop on selecting Text or closing the page. Measure partial and final latency on that specific device; do not derive it from test-fixture timings.

Finally, exercise both models online and retry with external internet disconnected while keeping the Python static server available. Confirm the same browser profile and origin can load its cached models and runtime. The application implements best-effort caching but this report does not certify offline operation.

## Reviewable artifacts

`docs/interface-preview.png` and `docs/mobile-preview.png` show the browser-rendered layout with a real deterministic English conversation. They were captured using the in-memory source loader and do not demonstrate speech recognition or translation.

`docs/MANUAL_TESTS.md` includes reproducible English/Chinese conversation inputs and expected canned response progression. `docs/SOURCES.md` identifies the primary documentation used to select APIs and model exports.
