# Primary sources and implementation notes

These references support API/model choices, not a claim that neural inference was executed during packaging. Dependency version 3.8.1 is intentionally pinned; it is not described as the latest version.

## Browser runtime

- Transformers.js browser installation: https://huggingface.co/docs/transformers.js/installation
- Custom environment and caching: https://huggingface.co/docs/transformers.js/custom_usage
- Exact 3.8.1 model/generation implementation: https://raw.githubusercontent.com/huggingface/transformers.js/3.8.1/src/models.js
- Exact 3.8.1 ONNX backend: https://raw.githubusercontent.com/huggingface/transformers.js/3.8.1/src/backends/onnx.js
- Runtime bundle used: https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/transformers.min.js

The 3.8.1 Whisper `_retrieve_init_tokens` source contains a language-detection TODO and defaults to English when language is omitted. This project therefore does not rely on omission to detect Chinese. It compares initial en/zh language-token logits and passes an explicit transcription language. That model-forward integration still needs target-device neural validation. A manual language override is provided.

WASM is single-threaded to avoid requiring COOP/COEP headers unavailable with the unmodified Python command. This is a performance trade-off, not a claim of equivalent GPU/CPU speed.

## Speech recognition

- Original Whisper and Turbo translation limitation: https://github.com/openai/whisper
- Browser-compatible multilingual Base export: https://huggingface.co/onnx-community/whisper-base
- Selected revision files: https://huggingface.co/onnx-community/whisper-base/tree/1846881b6b3a3024392c1eea3ad983695bc23925/onnx

The application uses `task: transcribe` only. Speech translation is deliberately separated into text translation after the transcript is finalized. Turbo is not used; the Whisper README explicitly says Turbo is not trained for translation.

Base CPU uses the q8 encoder and merged decoder, approximately 23.2 + 53.7 MB. The GPU path uses the fp32 encoder and q4 merged decoder, approximately 82.5 + 124 MB. Those are repository weight-file sizes, not the size of all repository variants, total first-use download, runtime RAM, or latency.

Optional Tiny/Small selections currently use the upstream `main` revision. They can change; pin a full commit in `js/config.js` after validating a particular version for deployment. The default Base revision is pinned.

## Chinese-to-English translation

- Model card and Transformers.js translation usage: https://huggingface.co/Xenova/opus-mt-zh-en
- Selected commit: https://huggingface.co/Xenova/opus-mt-zh-en/commit/39d480d52a9ea3065a1f117adfe4dbc55de10e6f
- Model files: https://huggingface.co/Xenova/opus-mt-zh-en/tree/main/onnx

The selected commit adds/updates ONNX exports for Transformers.js v3. The configured q8 encoder and merged decoder are approximately 52.9 + 60.2 MB; other tokenizer/runtime assets add more. Plain Whisper cannot translate typed text, which is why this separate text model is used. No translation-quality benchmark is asserted.

## Browser microphone and workers

- getUserMedia permission/secure-context requirements: https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
- AudioWorklet: https://developer.mozilla.org/en-US/docs/Web/API/AudioWorklet
- WebGPU capabilities: https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API
- Service worker API: https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API

Use localhost for the one-command deployment; ordinary LAN HTTP is not equivalent for microphone permissions. Browser permission and user-gesture requirements cannot be bypassed by this application.

No browser SpeechRecognition service, cloud AI endpoint, LLM, external font, or UI framework is used. The app's chat rules and visual assets are original source included in this package. External dependencies and model assets retain their own licensing.
