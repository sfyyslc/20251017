# Relay - browser-only English / Chinese call simulator

A no-build HTML, CSS, and JavaScript demo with continuous microphone transcription, submit-time Chinese-to-English translation, and a deterministic, multi-turn simulated dispatcher.

**Training only. This program does not call, contact, or dispatch emergency services. It is not an emergency triage or medical system. Use fictional details.**

## Run it

Unzip the package, open a terminal in the `emergency-call-demo` folder, then run:

```bash
python3 -m http.server 8000
```

Open **http://localhost:8000** in a current desktop Chrome or Edge browser. Do not double-click `index.html` or use a `file://` URL. Stop the server with Ctrl+C.

Python 3 and a browser must already be present. Nothing else is required to run the app: no npm, Node.js, build step, API key, local AI service, extension, or manually installed model. The optional maintainer tests have separate prerequisites and are not part of application startup.

The standard Python command listens on available network interfaces. To restrict serving to this computer, use this equivalent local-only variant:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

First AI use needs internet access to fetch the pinned runtime and model files. Those downloads can total hundreds of MB. **The ZIP contains source code, not model weights or a preloaded browser cache. It is not an air-gapped, first-run distribution.** English typed chat requires no AI download.

## Use it

**Text:** type English or Chinese. The original text and its script-based language label appear immediately. Click **Submit to chat** (or Ctrl/Cmd+Enter) to translate Chinese to English and add both versions to the conversation. English passes through unchanged. The input clears for the next turn, while the submitted original remains in the chat.

**Voice:** select **Voice**, allow the browser's microphone prompt, and wait for **Listening locally**. There is no Record button. Transcription then updates automatically while you speak. Speech model preparation is performed once per loaded session; audio during preparation is not retained. Choose **Text** to finish the current phrase, stop the microphone, and edit the transcript.

Click **Submit to chat** to pause capture, finish queued transcription, translate the completed text, and receive the canned reply. Listening resumes for the next turn. Speech during submit-time processing is not recorded. On failure the partial input is preserved and the app returns to editable Text mode.

The default speech-language setting chooses between English and Chinese using Whisper's initial language-token logits. Choose **Chinese** or **English** explicitly before entering Voice mode when Auto is unreliable, or to avoid its extra inference pass. This is not a general-purpose multilingual detector. Mandarin is the intended Chinese speech test case.

Open **AI models & device settings** to prepare both models in advance, use Whisper Tiny/Small instead of Base, force CPU/WASM, or adjust the microphone energy threshold. Model progress is per file, not an aggregate estimate. A failed GPU initialization retries in a new CPU worker.

**New session** clears the practice conversation and stops listening; it does not delete cached model files.

## What runs where

```text
Microphone -> AudioWorklet -> 16 kHz PCM -> Whisper -> original transcript
Typed text ---------------------------------------> original text
                                                     |
                                                   Submit
                                                     |
                      Chinese -> OPUS-MT translation -> English
                      English -----------------------> unchanged
                                                     |
                         original + English -> JavaScript dispatcher
                                                     |
                                  canned, stateful practice reply
```

All inference runs in the viewing browser. Python serves static files only. Production code never imports the synthetic test runtime.

| Component | Selected implementation |
| --- | --- |
| UI | Plain HTML/CSS/JavaScript, local ES modules |
| Browser AI library | Transformers.js 3.8.1, pinned jsDelivr bundle |
| Speech | `onnx-community/whisper-base`, multilingual, pinned commit |
| Chinese-to-English text | `Xenova/opus-mt-zh-en`, q8, pinned commit |
| Chat | Deterministic bilingual rules; no LLM/WebLLM download |
| Capture | Web Audio / AudioWorklet, local PCM only |
| Caching | Static/runtime service-worker caches and Transformers model cache |

Whisper processes audio, not arbitrary typed text. A separate text translation model handles both typed Chinese and the recognized Chinese transcript. Whisper Turbo is not used for translation. See [primary sources](docs/SOURCES.md).

Default Base weight files total roughly 77 MB on the CPU path or 207 MB on the selected GPU path; translation weights add roughly 113 MB. These are repository file-size sums, not measured downloads, runtime RAM, or latency. Tokenizers, configurations, and the JS/WASM runtime add more. Switching model/backend can download another variant.

## Live transcription and limitations

This is **continuous, chunked transcription**, not guaranteed word-by-word streaming. Growing utterances are scheduled about every 2.2 seconds, followed by inference time. A pause of roughly 720 ms finalizes a phrase; a continuous phrase is capped at 12 seconds. Final passes replace partial text instead of duplicating it. A simple energy gate suppresses quiet frames; it is not a trained voice activity detector.

Actual delay depends on hardware, browser, speech length, and model. CPU processing may fall behind; use a smaller model, a fixed speech language, or shorter phrases. A bounded queue stops capture with an error rather than silently discarding an unbounded backlog. No real-device speed or Mandarin accuracy benchmark is claimed for this package.

Typed language labels are script heuristics scoped to English/Chinese. Some unsupported scripts are rejected, but other Latin-script languages cannot reliably be distinguished from English. Mixed-language speech, accents, very short utterances, noise, names, and negation can be transcribed or translated incorrectly. Simplified/traditional Han text is accepted, but equivalent model accuracy is not promised.

The dispatcher uses source Chinese as well as translated English to reduce translation-dependent routing. It recognizes a limited set of fire, medical, police, and traffic scenarios, then asks about location, safety, and people involved. These are canned practice rules, not general intelligence, a complete parser, or an official call-handling protocol. Change them in `js/dispatcher.js` and rerun the tests.

## Browser permissions, network, and offline operation

Use `localhost`, not a plain HTTP LAN IP address. Microphone access requires a secure context and browser permission. The Voice-mode selection supplies a user gesture; the app cannot silently bypass the permission prompt.

WebGPU is optional: speech tries GPU and then CPU/WASM. Translation uses CPU/WASM. WASM deliberately uses one thread because the stock Python server does not add cross-origin-isolation headers. This avoids needing a custom server but limits CPU throughput. Current desktop Chrome/Edge are the initial target; other browser/OS/GPU combinations are not certified.

The app does not upload message text or audio, has no analytics, and does not send a cloud inference request. Runtime/model hosts do see ordinary download requests and network metadata. Conversation text is kept in page memory, not persisted by the app. Raw PCM is transient; there is no recording archive.

The service worker attempts to cache local app files and the pinned CDN runtime. Transformers.js caches downloaded model files separately. Caching is best effort. Private browsing, quota limits, cache eviction, version changes, or changing the browser profile, host, or port can require downloads again.

To evaluate offline reuse: prepare and exercise both models, reload once online, then disconnect external internet while keeping Python running. Use the **AI checks** page to confirm that inference still works. **Offline neural-model loading has not been verified in the supplied test run.** Do not assume a progress bar completing proves offline readiness.

For changes to deployment assets, bump the `VERSION` in `sw.js`; for a clean diagnostic, clear this origin's site data. That can also delete cached weights and require another download. Avoid serving this folder beside untrusted scripts on the same origin.

## Tests and validation status

- **125 / 125 deterministic tests passed** in Node and Chromium: bilingual routing, stateful conversations, negation, input validation, audio segmentation, queue behavior, and language-selection helpers.
- **29 browser integration checks passed, 1 skipped, 0 failed** using synthetic model outputs and synthetic microphone input. The restricted test environment required an in-memory source loader instead of normal browser navigation.
- Actual neural inference, real microphone capture/AudioWorklet execution, WebGPU inference, native browser ESM loading, and offline model reuse were **not** validated in this environment. Download endpoints were unreachable from code execution, and managed browser policies prevented navigation and capture.

The precise scope and caveats are in [TEST_REPORT.md](docs/TEST_REPORT.md), with machine-readable results under `tests/`. The screenshots demonstrate UI rendering and deterministic English chat, not model quality.

After starting the same Python server:

```text
http://localhost:8000/tests/index.html   # 125 no-download self-tests
http://localhost:8000/tests/ai.html      # actual-model checks, no mocks
```

The AI checks page provides six Chinese translation cases and an optional local audio-file transcription check. Use [MANUAL_TESTS.md](docs/MANUAL_TESTS.md) for live microphone and offline acceptance. A keyword PASS is not a semantic accuracy certification.

Optional developer commands, only when those tools are already installed:

```bash
node tests/run.mjs
# With Python Playwright + Chromium, and the static server already running:
python3 tests/browser_tests.py
```

## Files

```text
index.html, style.css        UI
js/app.js                    interaction and conversation orchestration
js/config.js                 runtime/model versions and limits
js/audio.js, pcm-worklet.js   real browser microphone capture
js/audio-core.js              PCM resampling, segmentation, inference queue
js/ai-worker.js               real model loading and inference
js/speech-language.js         English/Chinese audio-language selection
js/model-client.js           worker RPC, progress, timeout, CPU fallback
js/text.js                   validation, script labels, chunking
js/dispatcher.js             pure bilingual rules and conversation state
sw.js                        best-effort app/runtime caching
tests/                       self-tests, real-AI checks, maintainer fixtures
docs/                        test report, manual checks, sources, previews
```

Original project code is provided under the included MIT license. Downloaded external runtimes and models retain their own licenses; their weights and runtime binaries are not redistributed in this ZIP.
