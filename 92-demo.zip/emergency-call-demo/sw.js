/* Cache only static assets, never messages or audio. Bump VERSION when deploying edits. */
const VERSION = 'relay-v1';
const SHELL = `${VERSION}-shell`;
const RUNTIME = `${VERSION}-runtime`;
const FILES = [
  './', './index.html', './style.css', './js/app.js', './js/config.js', './js/text.js',
  './js/dispatcher.js', './js/audio.js', './js/audio-core.js', './js/pcm-worklet.js',
  './js/model-client.js', './js/ai-worker.js', './js/speech-language.js',
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(SHELL).then(cache => cache.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (/^relay-v\d+-(shell|runtime)$/.test(key) && key !== SHELL && key !== RUNTIME) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  const local = url.origin === self.location.origin && url.href.startsWith(self.registration.scope);
  const pinnedRuntime = url.origin === 'https://cdn.jsdelivr.net' && url.pathname.startsWith('/npm/@huggingface/transformers@3.8.1/');
  if (!local && !pinnedRuntime) return; // Model caching is managed by Transformers.js, not duplicated here.
  if (local && !(/\.(js|css|html)$/.test(url.pathname) || url.pathname.endsWith('/'))) return;
  event.respondWith((async () => {
    const cache = await caches.open(pinnedRuntime ? RUNTIME : SHELL);
    if (pinnedRuntime) {
      const hit = await cache.match(request);
      if (hit) return hit;
    }
    try {
      const response = await fetch(request);
      if (response.ok && response.type !== 'opaque') {
        // Cache failures (quota / private mode) must not prevent an online load.
        try { await cache.put(request, response.clone()); } catch { /* Best-effort caching. */ }
      }
      return response;
    } catch (error) {
      const hit = await cache.match(request);
      if (hit) return hit;
      throw error;
    }
  })());
});
