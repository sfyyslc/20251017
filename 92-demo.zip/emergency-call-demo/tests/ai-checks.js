import { ModelClient } from '../js/model-client.js';
const $ = id => document.getElementById(id);
let busy = false;
const report = (id, event) => {
  if (event.message) $(id).textContent = event.message;
  else if (event.status === 'progress') $(id).textContent = `${event.file || 'Model file'}: ${Number(event.progress || 0).toFixed(0)}% (this file)`;
};
const translator = new ModelClient('translation', event => report('translation-progress', event));
const speech = new ModelClient('speech', event => report('speech-progress', event));

async function ensureCacheControl() {
  if (!navigator.serviceWorker) return;
  try {
    await navigator.serviceWorker.register('../sw.js');
    await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller) await new Promise(resolve => {
      const timeout = setTimeout(resolve, 2500);
      navigator.serviceWorker.addEventListener('controllerchange', () => { clearTimeout(timeout); resolve(); }, { once: true });
    });
  } catch { /* Online checks still work if caching is unavailable. */ }
}
function lock(value) { busy = value; $('translation-test').disabled = value; $('speech-test').disabled = value; }
const cases = [
  { source: '\u6211\u5bb6\u7740\u706b\u4e86\u3002', meaning: 'My house is on fire.', check: /fire|burn/i },
  { source: '\u6211\u7238\u7238\u660f\u8ff7\u4e86\u3002', meaning: 'My father is unconscious / has fainted.', check: /unconscious|faint|passed out|coma/i },
  { source: '\u6709\u4eba\u6b63\u5728\u5165\u5ba4\u62a2\u52ab\u3002', meaning: 'Someone is breaking in / committing a robbery.', check: /rob|burglar|breaking|break.+in|intrud/i },
  { source: '\u8fd9\u91cc\u53d1\u751f\u4e86\u4ea4\u901a\u4e8b\u6545\u3002', meaning: 'There is a traffic accident here.', check: /accident|crash|collision/i },
  { source: '\u6ca1\u6709\u706b\u707e\u3002', meaning: 'There is no fire.', check: /(?=.*\b(?:no|not|isn't)\b)(?=.*fire)/i },
  { source: '\u5730\u5740\u662f\u4eba\u6c11\u8def25\u53f7\u3002', meaning: 'The address is 25 Renmin / People\'s Road. Preserve 25.', check: /\b25\b/ },
];
$('translation-test').addEventListener('click', async () => {
  if (busy) return; lock(true); $('translation-results').replaceChildren();
  let passed = 0;
  try {
    await ensureCacheControl();
    for (const [index, item] of cases.entries()) {
      const start = performance.now();
      const result = await translator.translate(item.source);
      const pass = Boolean(result.text.trim()) && /[a-z]/i.test(result.text) && item.check.test(result.text);
      if (pass) passed++;
      const entry = document.createElement('pre'); entry.style.cssText = 'white-space:pre-wrap;border-top:1px solid #dce4e1;padding-top:14px;font-size:12px';
      entry.textContent = `${index + 1}. ${pass ? 'PASS (word check only)' : 'REVIEW'}\nOriginal: ${item.source}\nExpected meaning: ${item.meaning}\nActual output: ${result.text}\nElapsed: ${((performance.now() - start) / 1000).toFixed(1)}s`;
      $('translation-results').append(entry);
    }
    $('translation-progress').textContent = `${passed} / ${cases.length} automatic word checks passed. Review the actual outputs above, especially the negation and address.`;
  } catch (error) { translator.terminate(error); $('translation-progress').textContent = `ERROR: ${error.message}`; }
  finally { lock(false); }
});
$('speech-test').addEventListener('click', async () => {
  if (busy) return;
  const file = $('audio-file').files[0];
  if (!file) { $('speech-progress').textContent = 'Select a local audio file first.'; return; }
  lock(true); $('speech-result').textContent = '';
  // Create and resume on the button gesture, before model downloads.
  const context = new AudioContext();
  try {
    await context.resume();
    const decoded = await context.decodeAudioData(await file.arrayBuffer());
    if (decoded.duration <= 0 || decoded.duration > 12) throw new Error('Use an audio file between 0 and 12 seconds long.');
    const offline = new OfflineAudioContext(1, Math.ceil(decoded.duration * 16000), 16000);
    const source = offline.createBufferSource(); source.buffer = decoded; source.connect(offline.destination); source.start();
    const pcm = (await offline.startRendering()).getChannelData(0);
    await context.close();
    await ensureCacheControl();
    await speech.load({ model: 'base', device: 'auto' });
    const result = await speech.transcribe(pcm, $('audio-language').value);
    const normalize = text => text.normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');
    const expected = $('expected').value.trim();
    const comparison = expected ? `\nExact normalized comparison: ${normalize(expected) === normalize(result.text) ? 'MATCH' : 'DIFFERENT (review output)'}` : '';
    $('speech-result').textContent = `Transcript: ${result.text}\nSelected audio language: ${result.language}\nInference time (this file/device): ${(result.latencyMs / 1000).toFixed(1)}s${comparison}`;
    $('speech-progress').textContent = 'Actual model inference completed. Review the transcript for accuracy.';
  } catch (error) { speech.terminate(error); $('speech-progress').textContent = `ERROR: ${error.message}`; }
  finally { if (context.state !== 'closed') await context.close(); lock(false); }
});
window.addEventListener('pagehide', () => { translator.terminate(); speech.terminate(); });
