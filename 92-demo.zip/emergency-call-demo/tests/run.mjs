import { runSuite } from './suite.js';
import { writeFile } from 'node:fs/promises';
const results = await runSuite(result => console.log(`${result.status} ${result.name}${result.error ? ': ' + result.error : ''}`));
const failed = results.filter(x => x.status !== 'PASS');
console.log(`\n${results.length - failed.length}/${results.length} passed.`);
await writeFile(new URL('./unit-results.json', import.meta.url), JSON.stringify({ environment: `Node ${process.version}`, actualAIInference: false, tests: results }, null, 2));
process.exitCode = failed.length ? 1 : 0;
