"""Optional maintainer tests; NOT required to run the webpage.
Requires Python Playwright and a Chromium executable in the maintainer environment.
Run against an already-running server: python3 tests/browser_tests.py
AI is explicitly mocked. Normal mode uses the static server and synthetic browser
audio. DEMO_TEST_IN_MEMORY=1 additionally substitutes source loading and microphone
capture; it skips service-worker navigation. See docs/TEST_REPORT.md.
No recognition/translation quality is measured.
"""
import json
import os
import time
import unittest
from memory_harness import render, run_browser_unit
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent.parent
URL = os.environ.get('DEMO_URL', 'http://127.0.0.1:8000')
MEMORY = os.environ.get('DEMO_TEST_IN_MEMORY') == '1'
RESULTS = []
BROWSER_ERRORS = []
FAKE = (ROOT / 'tests/fake-transformers.js').read_text()


def record(name, fn):
    start = time.monotonic()
    try:
        fn()
        result = {'name': name, 'status': 'PASS'}
    except unittest.SkipTest as error:
        result = {'name': name, 'status': 'SKIP', 'reason': str(error)}
    except Exception as error:
        result = {'name': name, 'status': 'FAIL', 'error': str(error)}
    result['durationMs'] = round((time.monotonic() - start) * 1000)
    RESULTS.append(result)
    print(result['status'], name, result.get('error', ''), flush=True)


def make_page(browser, fake=True, options=None, viewport=None, service_workers='block', init=None):
    context = browser.new_context(permissions=['microphone'], viewport=viewport or {'width': 1440, 'height': 1100}, service_workers=service_workers)
    context.add_init_script("""window.__testTracks=[];
      if (navigator.mediaDevices) {
        const original=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
        navigator.mediaDevices.getUserMedia=async (...args)=>{
          const stream=await original(...args); window.__testTracks.push(...stream.getTracks()); return stream;
        };
      }
    """)
    if init:
        context.add_init_script(init)
    if fake:
        body = FAKE.replace('const TEST_OPTIONS = {};', 'const TEST_OPTIONS = ' + json.dumps(options or {}) + ';')
        context.route('https://cdn.jsdelivr.net/**', lambda route: route.fulfill(status=200, content_type='text/javascript', headers={'access-control-allow-origin': '*'}, body=body))
    context.set_default_timeout(7000)
    page = context.new_page()
    page.on('pageerror', lambda error: BROWSER_ERRORS.append(str(error)))
    if MEMORY:
        render(page, fake=fake, options=options, init=init)
    else:
        page.goto(URL, wait_until='networkidle')
    return context, page


def submit(page, text):
    page.locator('#source').fill(text)
    page.locator('#submit').click()
    page.wait_for_function("document.getElementById('thinking').hidden")
    expect(page.locator('#error')).to_be_hidden()


def new_session(page):
    page.locator('#reset').click()
    expect(page.locator('#chat-log .user')).to_have_count(0)


def main():
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH', '/usr/bin/chromium'), headless=True, args=[
            '--no-sandbox', '--disable-dev-shm-usage', '--use-fake-ui-for-media-stream',
            '--use-fake-device-for-media-stream', '--autoplay-policy=no-user-gesture-required',
        ])
        context, page = make_page(browser)
        runtime_requests = []
        page.on('request', lambda request: runtime_requests.append(request.url) if 'cdn.jsdelivr.net' in request.url else None)

        def initial():
            expect(page.locator('#submit')).to_be_disabled()
            expect(page.locator('#english-output')).to_have_text('Your English translation will appear here.')
            expect(page.locator('#chat-log .dispatcher')).to_have_count(1)
            assert not runtime_requests
        record('Initial load / empty input / no AI download', initial)

        def english_flow():
            submit(page, 'My house is on fire.')
            expect(page.locator('#route-label')).to_contain_text('Fire / awaiting location')
            expect(page.locator('.message-original')).to_have_text('My house is on fire.')
            expect(page.locator('#english-output')).to_have_text('My house is on fire.')
            submit(page, '25 Oak Street')
            expect(page.locator('#route-label')).to_contain_text('awaiting safety')
            submit(page, 'I am outside and safe')
            expect(page.locator('#route-label')).to_contain_text('awaiting people')
            submit(page, 'Everyone is outside. No injuries.')
            expect(page.locator('#route-label')).to_contain_text('details noted')
            expect(page.locator('#chat-log .user')).to_have_count(4)
            assert not runtime_requests
        record('Four-turn English conversation using real rules, no AI', english_flow)

        for text, route in [('Two cars crashed at 25 Oak Street.', 'Traffic'), ('Someone is breaking in', 'Police'), ('My father is unconscious', 'Medical'), ('There is no fire', 'Unclassified')]:
            def check(text=text, route=route):
                new_session(page); submit(page, text)
                expect(page.locator('#route-label')).to_contain_text(route)
            record('English UI route: ' + route, check)

        def zh_gated():
            new_session(page)
            page.locator('#source').fill('\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            expect(page.locator('#language-badge')).to_have_text('Chinese')
            expect(page.locator('#english-output')).to_have_text('Your English translation will appear here.')
            expect(page.locator('#chat-log .user')).to_have_count(0)
            assert not runtime_requests
        record('Chinese script label updates, translation waits for Submit', zh_gated)

        def zh_flow():
            submit(page, '\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            expect(page.locator('#english-output')).to_have_text('My house is on fire.')
            expect(page.locator('#route-label')).to_contain_text('Fire / awaiting location')
            expect(page.locator('.message-original').last).to_have_text('\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            submit(page, '\u4eba\u6c11\u8def25\u53f7')
            submit(page, '\u6211\u5728\u5916\u9762\uff0c\u5f88\u5b89\u5168')
            submit(page, '\u6ca1\u6709\u4eba\u53d7\u4f24')
            expect(page.locator('#route-label')).to_contain_text('Fire / details noted')
            expect(page.locator('#chat-log .user')).to_have_count(4)
        record('Four-turn Chinese UI / real worker / synthetic translation fixture', zh_flow)

        for example, route in [('medical', 'Medical'), ('police', 'Police')]:
            def check(example=example, route=route):
                new_session(page); page.locator(f'[data-example={example}]').click(); page.locator('#submit').click()
                expect(page.locator('#route-label')).to_contain_text(route, timeout=10000)
            record('Chinese example UI route: ' + route, check)

        def xss():
            new_session(page)
            text = '<img src=x onerror="window.xss=1"> There is a fire.'
            submit(page, text)
            expect(page.locator('#chat-log img')).to_have_count(0)
            expect(page.locator('.message-original')).to_have_text(text)
            assert page.evaluate('window.xss === undefined')
        record('Original text is rendered safely, not as HTML', xss)

        def input_limit():
            new_session(page); page.locator('#source').fill('a' * 1201); page.locator('#submit').click()
            expect(page.locator('#error')).to_contain_text('under 1200')
            expect(page.locator('#source')).to_have_value('a' * 1201)
            expect(page.locator('#chat-log .user')).to_have_count(0)
        record('Oversized message is rejected and preserved', input_limit)

        def unsupported():
            new_session(page); page.locator('#source').fill('\ud55c\uad6d\uc5b4'); page.locator('#submit').click()
            expect(page.locator('#error')).to_contain_text('English and Chinese only')
            expect(page.locator('#chat-log .user')).to_have_count(0)
        record('Unsupported script does not masquerade as English', unsupported)

        def keyboard():
            new_session(page); page.locator('#source').fill('A car collision')
            page.locator('#source').press('Control+Enter')
            expect(page.locator('#route-label')).to_contain_text('Traffic')
        record('Ctrl+Enter submits a text message', keyboard)

        def ime():
            new_session(page); page.locator('#source').fill('\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            page.locator('#source').evaluate("el=>el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',ctrlKey:true,isComposing:true,bubbles:true}))")
            expect(page.locator('#chat-log .user')).to_have_count(0)
        record('IME composition does not accidentally submit', ime)

        def double_submit():
            new_session(page); page.locator('#source').fill('\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            page.locator('#message-form').evaluate("el=>{el.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));el.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));}")
            expect(page.locator('#chat-log .user')).to_have_count(1)
            expect(page.locator('#turn-count')).to_have_text('01 TURN')
        record('Overlapping submit events commit exactly one turn', double_submit)

        def fail_inference():
            new_session(page); page.locator('#source').fill('\u7ffb\u8bd1\u5931\u8d25'); page.locator('#submit').click()
            expect(page.locator('#error')).to_contain_text('Injected translation inference failure')
            expect(page.locator('#source')).to_have_value('\u7ffb\u8bd1\u5931\u8d25')
            expect(page.locator('#chat-log .user')).to_have_count(0)
            submit(page, '\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            expect(page.locator('#route-label')).to_contain_text('Fire')
        record('Translation failure keeps input / retry remains usable', fail_inference)

        def reset():
            new_session(page)
            expect(page.locator('#source')).to_have_value('')
            expect(page.locator('#english-output')).to_have_text('Your English translation will appear here.')
            expect(page.locator('#route-label')).to_have_text('Awaiting a scenario')
            expect(page.locator('#turn-count')).to_have_text('00 TURNS')
        record('New session resets state, translation, and conversation', reset)

        def voice_flow():
            new_session(page)
            page.locator('input[name=mode][value=voice]').check(force=True)
            expect(page.locator('#voice-state')).to_contain_text('Listening locally', timeout=15000)
            expect(page.locator('#source')).to_have_value('\u6211\u5bb6\u7740\u706b\u4e86\u3002', timeout=15000)
            expect(page.locator('#english-output')).to_have_text('Your English translation will appear here.')
            assert page.locator('button').filter(has_text='Record').count() == 0
            page.locator('#submit').click()
            expect(page.locator('#chat-log .user')).to_have_count(1, timeout=10000)
            expect(page.locator('#english-output')).to_have_text('My house is on fire.')
            expect(page.locator('#voice-state')).to_contain_text('ready for the next message')
            expect(page.locator('.message-original')).to_have_text('\u6211\u5bb6\u7740\u706b\u4e86\u3002')
        record('Continuous microphone / PCM / auto-language / submit / resume (synthetic ASR)', voice_flow)

        def mic_stop():
            page.locator('input[name=mode][value=text]').check(force=True)
            expect(page.locator('#mode-badge')).to_have_text('Text mode', timeout=10000)
            page.wait_for_function("window.__testTracks.length>0 && window.__testTracks.every(t=>t.readyState==='ended')")
            expect(page.locator('#source')).not_to_have_attribute('readonly', '')
        record('Selecting Text flushes speech and stops every microphone track', mic_stop)

        def explicit_english():
            new_session(page); page.locator('#speech-language').select_option('en')
            page.locator('input[name=mode][value=voice]').check(force=True)
            expect(page.locator('#source')).to_have_value('My house is on fire.', timeout=15000)
            page.locator('#reset').click()
            expect(page.locator('#source')).to_have_value('')
            page.wait_for_timeout(300)
            assert page.evaluate("window.__testTracks.every(t=>t.readyState==='ended')")
        record('Explicit English speech hint / reset stops microphone', explicit_english)

        def screenshot():
            submit(page, 'Two cars crashed at 25 Oak Street.')
            submit(page, 'I am outside and safe')
            page.locator('#source').fill('Two vehicles. Nobody is injured.')
            page.screenshot(path=str(ROOT / 'docs/interface-preview.png'), full_page=True)
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        record('Desktop layout / real English chat screenshot / no overflow', screenshot)
        context.close()

        def model_load_error():
            c, p = make_page(browser, options={'failLoad': True})
            p.locator('#source').fill('\u6211\u5bb6\u7740\u706b\u4e86\u3002'); p.locator('#submit').click()
            expect(p.locator('#error')).to_contain_text('Could not load the translation model', timeout=10000)
            expect(p.locator('#source')).to_have_value('\u6211\u5bb6\u7740\u706b\u4e86\u3002')
            submit(p, 'A fire')
            expect(p.locator('#route-label')).to_contain_text('Fire')
            c.close()
        record('Download failure is actionable; English works without models', model_load_error)

        def denied():
            c, p = make_page(browser, init="navigator.mediaDevices.getUserMedia=async()=>{throw new DOMException('denied','NotAllowedError')};")
            p.locator('input[name=mode][value=voice]').click(force=True)
            expect(p.locator('#error')).to_contain_text('Microphone permission was denied')
            expect(p.locator('#mode-badge')).to_have_text('Text mode')
            submit(p, 'A fire'); c.close()
        record('Microphone denial recovers to working Text mode', denied)

        def cancel_load():
            c, p = make_page(browser, options={'loadDelay': 900})
            p.locator('input[name=mode][value=voice]').check(force=True)
            p.locator('input[name=mode][value=text]').check(force=True)
            p.wait_for_timeout(1200)
            expect(p.locator('#mode-badge')).to_have_text('Text mode')
            expect(p.locator('#source')).to_have_value('')
            assert p.evaluate("window.__testTracks.every(t=>t.readyState==='ended')")
            c.close()
        record('Switching to Text during model loading does not leak microphone', cancel_load)

        def fallback():
            c, p = make_page(browser, options={'failGPU': True}, init="Object.defineProperty(navigator,'gpu',{value:{requestAdapter:async()=>({})},configurable:true});")
            p.locator('details').evaluate('el=>el.open=true')
            p.locator('#prepare').click()
            expect(p.locator('#ai-summary')).to_have_text('Both models ready', timeout=15000)
            expect(p.locator('#speech-status')).to_contain_text('CPU / WASM')
            c.close()
        record('GPU failure retries with a fresh CPU worker', fallback)

        def mobile():
            c, p = make_page(browser, viewport={'width': 390, 'height': 844})
            submit(p, 'A fire')
            assert p.evaluate('document.documentElement.scrollWidth <= innerWidth')
            p.screenshot(path=str(ROOT / 'docs/mobile-preview.png'), full_page=True)
            c.close()
        record('Mobile-width responsive layout and text chat', mobile)

        def offline():
            if MEMORY:
                raise unittest.SkipTest('Navigation policy blocks local origins; app-shell service worker must be tested on the target browser.')
            c, p = make_page(browser, fake=False, service_workers='allow')
            p.wait_for_function('navigator.serviceWorker.controller !== null', timeout=15000)
            c.set_offline(True)
            p.reload(wait_until='domcontentloaded')
            submit(p, 'A fire')
            expect(p.locator('#route-label')).to_contain_text('Fire')
            c.set_offline(False); c.close()
        record('Cached app shell reloads and English chat works offline', offline)

        def browser_unit():
            c, p = make_page(browser)
            if MEMORY:
                results = run_browser_unit(p)
            else:
                p.goto(URL + '/tests/index.html')
                p.locator('#run').click()
                p.wait_for_function('window.testResults !== undefined')
                results = p.evaluate('window.testResults')
            assert all(x['status'] == 'PASS' for x in results), results
            c.close()
        record('All unit tests also execute in Chromium', browser_unit)

        record('No unhandled browser JavaScript errors', lambda: (_ for _ in ()).throw(AssertionError(BROWSER_ERRORS)) if BROWSER_ERRORS else None)
        browser.close()
    report = {
        'browser': 'Chromium via Playwright', 'actualAIInference': False,
        'inMemorySourceLoader': MEMORY, 'actualMicrophoneCapture': not MEMORY,
        'notes': 'Application, worker logic, DOM, and rules execute. AI outputs are synthetic. In-memory mode also replaces device capture with synthetic PCM and skips service-worker navigation; it changes source loading but not app logic.',
        'results': RESULTS, 'unhandledBrowserErrors': BROWSER_ERRORS,
    }
    (ROOT / 'tests/browser-results.json').write_text(json.dumps(report, indent=2))
    passed = sum(x['status'] == 'PASS' for x in RESULTS)
    print(f'\n{passed}/{len(RESULTS)} browser tests passed.', flush=True)
    raise SystemExit(1 if any(x['status'] == 'FAIL' for x in RESULTS) else 0)

if __name__ == '__main__':
    main()
