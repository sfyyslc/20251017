/* TEST FIXTURE ONLY. Production never imports this file.
 * Replaces the remote runtime in browser automation, NOT the application's code.
 * Outputs are synthetic and are not evidence of AI accuracy or real latency.
 */
const TEST_OPTIONS = {}; // REPLACED_BY_TEST_RUNNER
export const env = { backends: { onnx: { wasm: {} } } };
export class Tensor {
  constructor(type, data, dims) { this.type = type; this.data = data; this.dims = dims; }
  dispose() {}
}
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const fixtures = new Map([
  ['\u6211\u5bb6\u7740\u706b\u4e86\u3002', 'My house is on fire.'],
  ['\u6211\u7238\u7238\u660f\u8ff7\u4e86\uff0c\u8bf7\u6d3e\u6551\u62a4\u8f66\u3002', 'My father is unconscious. Please send an ambulance.'],
  ['\u6709\u4eba\u6b63\u5728\u5165\u5ba4\u62a2\u52ab\u3002', 'Someone is breaking in and robbing the home.'],
  ['\u4eba\u6c11\u8def25\u53f7', '25 Renmin Road'],
  ['\u6211\u5728\u5916\u9762\uff0c\u5f88\u5b89\u5168', 'I am outside and safe'],
  ['\u6ca1\u6709\u4eba\u53d7\u4f24', 'No one is injured'],
  ['\u6ca1\u6709\u706b\u707e', 'There is no fire'],
]);
export async function pipeline(kind, modelID, options) {
  if (env.backends.onnx.wasm.numThreads !== 1) throw new Error('Expected single-thread WASM under the plain Python server.');
  if (TEST_OPTIONS.failLoad) throw new Error('Injected model download failure');
  if (TEST_OPTIONS.failGPU && options.device === 'webgpu') throw new Error('Injected GPU initialization failure');
  options.progress_callback?.({ status: 'progress', file: 'test-fixture-only.onnx', progress: 50 });
  await sleep(TEST_OPTIONS.loadDelay ?? 35);
  if (kind === 'translation') {
    if (modelID !== 'Xenova/opus-mt-zh-en' || options.dtype !== 'q8') throw new Error('Unexpected translation model configuration.');
    return async (text, generation) => {
      if (generation.num_beams !== 1) throw new Error('Expected deterministic greedy decoding.');
      await sleep(TEST_OPTIONS.translationDelay ?? 80);
      if (text.includes('\u5931\u8d25')) throw new Error('Injected translation inference failure');
      return [{ translation_text: fixtures.get(text) || 'A test message requiring assistance.' }];
    };
  }
  if (kind !== 'automatic-speech-recognition') throw new Error('Unexpected task.');
  const asr = async (audio, generation) => {
    if (!(audio instanceof Float32Array) || audio.length < 100) throw new Error('Expected 16 kHz float PCM.');
    if (!['chinese', 'english'].includes(generation.language)) throw new Error('Automatic language selection was not applied.');
    if (generation.task !== 'transcribe') throw new Error('Live speech must stay in the original language.');
    await sleep(TEST_OPTIONS.speechDelay ?? 60);
    return { text: generation.language === 'chinese' ? '\u6211\u5bb6\u7740\u706b\u4e86\u3002' : 'My house is on fire.' };
  };
  asr.processor = async () => ({ input_features: new Tensor('float32', new Float32Array(1), [1, 1, 1]) });
  asr.model = async ({ decoder_input_ids }) => {
    if (decoder_input_ids.data[0] !== 4n) throw new Error('Language detection must start at the start-of-transcript token.');
    return { logits: new Tensor('float32', new Float32Array([0, 1, 9, 0, 0]), [1, 1, 5]) };
  };
  asr.model.generation_config = { decoder_start_token_id: 4, lang_to_id: { '<|en|>': 1, '<|zh|>': 2 } };
  asr.model.config = {};
  return asr;
}
