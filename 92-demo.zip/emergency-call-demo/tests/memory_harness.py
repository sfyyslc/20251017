"""Offline DOM test loader for environments that forbid browser navigation.
It injects the project's local source as isolated module closures, with synthetic
microphone and AI runtime adapters. It does not disable browser policies or make
network requests. Normal users should use the static server, not this harness.
"""
import json
import posixpath
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IMPORT = re.compile(r"^import\s+\{([^}]+)\}\s+from\s+['\"]([^'\"]+)['\"];?\s*$", re.M)
EXPORT = re.compile(r'\bexport\s+(?:(?:async\s+)?function|class|const|let)\s+(\w+)')

FAKE_MICROPHONE = r'''
export class Microphone {
  constructor(onAudio,onLevel) { this.onAudio=onAudio; this.onLevel=onLevel; this.enabled=false; }
  async start() {
    this.stream=await navigator.mediaDevices.getUserMedia({audio:true});
    if(this.stopped){this.stream.getTracks().forEach(t=>t.stop());return;}
    this.timer=setInterval(()=>{
      if(this.enabled&&!this.stopped){this.onLevel(.08);this.onAudio(new Float32Array(1600).fill(.08));}
    },100);
  }
  setEnabled(value){this.enabled=!!value&&!this.stopped;this.stream?.getTracks().forEach(t=>t.enabled=this.enabled);if(!this.enabled)this.onLevel(0);}
  async pauseAndFlush(){this.setEnabled(false);}
  stop(){this.stopped=true;this.enabled=false;clearInterval(this.timer);this.stream?.getTracks().forEach(t=>t.stop());this.onLevel(0);}
}
'''


def compile_modules(entry, overrides=None, transform=None, footer=''):
    overrides = overrides or {}
    modules = []
    seen = set()

    def visit(path):
        if path in seen:
            return
        seen.add(path)
        source = overrides.get(path, (ROOT / path).read_text() if (ROOT / path).exists() else '')
        imports = []
        for match in IMPORT.finditer(source):
            dependency = posixpath.normpath(posixpath.join(posixpath.dirname(path), match[2]))
            visit(dependency)
            imports.append((match[0], f'const {{{match[1]}}} = __modules[{json.dumps(dependency)}];'))
        exports = EXPORT.findall(source)
        for old, new in imports:
            source = source.replace(old, new)
        source = re.sub(r'\bexport\s+(?=(?:async\s+)?function|class|const|let)', '', source)
        source = source.replace('import.meta.url', json.dumps('http://localhost:8000/' + path))
        if transform:
            source = transform(path, source)
        modules.append(f'__modules[{json.dumps(path)}]=(()=>{{\n{source}\nreturn {{{",".join(exports)}}};\n}})();')

    visit(entry)
    return '(()=>{const __modules={};\n' + '\n'.join(modules) + '\n' + footer + '\n})();'


def render(page, fake=True, options=None, init=None):
    options = options or {}
    html = (ROOT / 'index.html').read_text()
    html = re.sub(r'<script\b[^>]*>.*?</script>', '', html, flags=re.S)
    html = re.sub(r'<link[^>]+rel="stylesheet"[^>]*>', '<style>' + (ROOT / 'style.css').read_text() + '</style>', html)
    page.set_content(html, wait_until='domcontentloaded')
    # All of the following adapters are confined to tests. There is no real device access.
    page.evaluate("""()=>{
      window.__testTracks=[];window.__testWorkerStarts=0;
      Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>{
        await new Promise(r=>setTimeout(r,20));
        const track={readyState:'live',enabled:true,stop(){this.readyState='ended';},addEventListener(){}};
        window.__testTracks.push(track);return {getTracks:()=>[track],getAudioTracks:()=>[track]};
      }}});
      Object.defineProperty(navigator,'gpu',{value:undefined,configurable:true});
    }""")
    if init:
        page.evaluate('()=>{' + init + '}')
    fake_source = (ROOT / 'tests/fake-transformers.js').read_text().replace('const TEST_OPTIONS = {};', 'const TEST_OPTIONS = ' + json.dumps(options) + ';')
    fake_source = re.sub(r'\bexport\s+', '', fake_source)
    library = '(function(){' + fake_source + ';return {env,Tensor,pipeline};})()'
    worker = compile_modules('js/ai-worker.js', transform=lambda path, text: text.replace('await import(CONFIG.transformersURL)', library) if path == 'js/ai-worker.js' else text)
    page.evaluate("""code=>{
      const NativeWorker=window.Worker;
      window.Worker=class {
        constructor(url,options){
          window.__testWorkerStarts++;
          const blob=new Blob([code],{type:'text/javascript'});
          return new NativeWorker(URL.createObjectURL(blob),{...options,type:'classic'});
        }
      };
    }""", worker)
    bundle = compile_modules('js/app.js', overrides={'js/audio.js': FAKE_MICROPHONE})
    page.add_script_tag(content=bundle)


def run_browser_unit(page):
    bundle = compile_modules('tests/suite.js', footer="window.__testRunSuite=__modules['tests/suite.js'].runSuite;")
    page.add_script_tag(content=bundle)
    return page.evaluate('async()=>await window.__testRunSuite()')
