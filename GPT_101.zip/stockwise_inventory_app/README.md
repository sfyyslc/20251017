# StockWise - October 17, 2026 update

A local inventory workspace for small food businesses. Plain HTML, CSS and vanilla JavaScript. No frontend framework, build step, CDN, cloud account or application backend. Python only serves the files and optionally installs the requested WebLLM assets.

## Read this first

**The inventory app and built-in assistant tools work offline immediately. The genuine WebLLM runtime and model weights are NOT included in this archive.** External binary downloads were blocked in the authoring environment. The app contains a real WebLLM integration and a standard-library Python installer, not a simulated AI runtime. `vendor/manifest.json` accurately starts with `installed: false`.

Run the one-time online installation below to populate the missing assets. Generative model loading and inference could not be tested end to end here. Email features prepare reports and drafts; this static app cannot authenticate to a mailbox or send messages itself.

## Start the app

Extract the archive, open a terminal inside `stockwise_inventory_app`, and run:

```sh
python -m http.server 8000 --bind 127.0.0.1
```

Open `http://localhost:8000` in your browser. Use `python3` instead of `python` where needed. Keep the terminal running. Do not open `index.html` through `file://`; modules, local asset requests and browser security features require serving the files.

Everything other than open-ended model answers is ready without installation. The same command works without an internet connection. There is no service worker: the local server still needs to be running.

### Preserve an existing workspace

Export a JSON backup from your original app first, then close its tabs. Run the updated app at the same host and port, using the same browser profile. The original storage key, `stockwise-inventory-app-v1`, is retained. Existing inventory, recipes, orders and business name are migrated; new settings get defaults. No sample data is merged into an existing business.

When changing host, port, browser or device, use **Backup & restore > Import JSON**. Backups include workspace data, not AI binaries. Avoid running the old and new app simultaneously against the same browser storage.

## Install real local AI once, while online

Python 3.9 or newer is required for the installer. No `pip`, npm, bundler or build tool is needed.

```sh
python install_ai.py
python install_ai.py --verify
```

The installer downloads the official **WebLLM 0.2.85** browser bundle, **Qwen2.5-0.5B-Instruct-q4f32_1-MLC** configuration/tokenizer/weight shards, its compatible compiled WebAssembly library, and license files. Expect a download of several hundred megabytes and additional runtime/cache memory. Exact download size is recorded after installation; it has not been measured in this environment.

The script validates the npm package integrity, validates available upstream weight hashes and file sizes, and records a SHA-256 inventory of local assets. `--verify` checks the completed folder without contacting the internet. Download errors leave the model unavailable; no fake model or cloud fallback is substituted. Rerunning can reuse correctly sized model files, with upstream hashes checked where available.

After successful installation:

1. Start or keep the Python server running, then refresh the app.
2. Open **Assistant > Enable local AI** and wait for its status to read **Local AI ready**.
3. Disconnect the internet and test an open-ended question. All model URLs in this integration point to the local server.

To move to another machine, copy the **whole installed folder**, including `vendor/` and `models/`, not just the HTML files or a browser cache. A successful local file verification does not prove GPU compatibility. The full online install and real inference remain unverified in this handoff.

### Browser and device requirements

Generative AI needs a compatible WebGPU browser/device, sufficient available GPU memory, and a secure browser context. `localhost` on the serving computer is supported by the app's checks. A phone visiting a computer's plain HTTP LAN address is not equivalent to localhost; use a trusted HTTPS deployment for model inference on another device. Mobile layout works independently of AI hardware support.

The core inventory tools require no GPU. They continue working if the model is missing, loading, stopped, unsupported, or out of memory. AI loading is off by default. The optional automatic setting loads the model when the Assistant page is opened, not on every page.

## What changed

| Area | Included behavior |
| --- | --- |
| Account & email | Business name, owner name, report email, live report preview, local draft history, JSON/CSV exports, email-ready `.eml` files with attachments. |
| Appearance & settings | Six palettes, custom color picker and hex input, contrast-aware text/buttons, reminder preference, 7/14/30-day default forecast, optional AI autoload. |
| Assistant | Live customer favorites, stock/cost calculations, app explanations, delivery/count/waste requests, supported settings changes, confirmation previews, stale-data checks, cancel and confirmable undo. |
| Restock reminders | Consolidated low/critical stock pop-up, OK acknowledgement, next-visit snooze, repeat shortage and critical-escalation handling. |
| Existing workflows | Inventory and recipe editing, order ingredient deductions, insufficient-stock checks, weekday-based demand forecasts, purchase estimates, history, import/export. |
| Reliability | Existing-data migration, visible storage-failure warnings, safer quantity parsing, output escaping, CSV formula neutralization, responsive views and labelled dialogs. |

## Try the assistant

These tools work offline without downloading the model:

```text
What is our favorite dish?
What does reorder point mean?
How much does 500 g of rice cost?
I bought 5 kg of rice
Add 24 eggs
Add 2 dozen eggs
Set rice stock to 20 kg
Remove 500 g of rice
Set rice reorder point to 10 kg
Set rice unit cost to 2.50 per kg
Set my business name to Maple Street Kitchen
Set my email to owner@mybusiness.com
Change my website color to blue
Set my theme to #7543a0
Set my default forecast to 14 days
Turn off low stock reminders
Undo
```

A proposed change always displays the old and new values first. Choose **Apply change**, type **yes**, or cancel. Undo is another preview, not a silent mutation. Exact arithmetic and writes are handled by deterministic tools; generated model text has no write privileges and is never executed.

Use one ingredient and one quantity per request. Weight and volume conversions stay within their own measurement families. Count units must be whole numbers. Unknown package sizes, multiple quantities and mass-to-volume requests are not guessed. For example, `2 boxes of eggs` asks for the actual egg count. English command patterns are supported; arbitrary phrasing and every possible setting are not guaranteed. Other edits remain available in their forms.

Open-ended questions, such as asking for a short customer message, use the installed and enabled local model. It has no web access and can be wrong. The selected compact model is intended for modest local assistance, not guaranteed expert advice. Confirm important answers independently.

Customer favorites are ranked by **servings in the last 28 calendar days**, not by revenue. Forecasting is a transparent, weekday-weighted calculation using recorded orders and recipes; it does not fine-tune a neural model on your business data. Estimates exclude unknown holidays, lead times, weather, promotions, delivery fees and overhead.

## Email: preparation is not delivery

Save your own email under **Account & email**. The initial address, `owner@harborbowl.example`, is fictional.

**Download email draft & attachments** produces an unsent `.eml` containing a text summary, current JSON workspace backup and inventory CSV. Draft generation works offline. Open the file with a compatible mail application and send when connected. Mail clients vary: some open `.eml` files as received messages rather than editable drafts; use that client's edit-as-new/forward function or attach the standalone exports to a new message.

**Open summary in email app** creates a `mailto:` request with the recipient, subject and summary. It does not attach files. The app cannot determine whether a mail application opened or whether a message was sent.

The history is labelled **Prepared reports**, never a sent folder. It retains at most eight preparation records; snapshots exclude earlier embedded snapshots to avoid recursive backup growth. There is no SMTP server, OAuth mailbox connection, automatic email queue, background delivery or delivery tracking. No password or API key is requested.

## Reminder behavior

An ingredient is low at or below its reorder point; it is critical at half that level or less, or at zero. The sample workspace opens with four affected ingredients.

- **Remind me later:** dismisses the displayed items for this page visit. They return when the workspace is opened or reloaded, if still low.
- **OK:** acknowledges the current shortage and severity across visits. It can reappear when low becomes critical, or after stock recovers and becomes low again.
- Dashboard warnings remain visible. **Review low-stock items now** opens the current list manually, even when automatic pop-ups are disabled.

A visit means a document open/reload, not a login session. This app has one local business profile and no authenticated accounts. Pop-ups wait until other app dialogs close.

## Sample workspace

Fresh browser storage starts with Harbor Bowl Kitchen: 16 inventory ingredients, six menu recipes, 56 days of generated sales history (112 order batches), ingredient costs and suppliers, four low-stock examples, a business profile, a fictional report email and a clearly marked sample report record. Historical dates are relative to the first run, so forecast pages are useful immediately.

Resetting the demo replaces local business data after confirmation. Export a backup before resetting. There is no hidden real customer data and no invented model conversation presented as genuine inference.

## Privacy and storage

Workspace data is stored in browser localStorage for the server origin. It is not encrypted, synchronized to a cloud or protected by a login. Anyone with access to that browser profile may access the workspace. Clearing site data removes it; export backups regularly. If saving fails, a persistent warning appears: changes in memory must be exported before closing.

Email drafts and JSON files contain business data. Protect them accordingly. AI context is assembled locally from the current business name, a bounded inventory/menu summary and sales rankings. No cloud inference endpoint is configured. Serving only on `127.0.0.1` avoids exposing the app through the local network.

## Files and testing

See `ARCHITECTURE.md`, `CHANGELOG.md`, `TEST_REPORT.md`, and `THIRD_PARTY_NOTICES.md`.

```sh
# Optional developer checks; not required to run the app.
node tests/test_actions.cjs
python tests/test_browser.py
python tests/test_edge_cases.py
```

The two browser scripts require developer-installed Playwright and a Chromium executable. Set `CHROMIUM_PATH` when it is not `/usr/bin/chromium`. These are isolated DOM tests with storage/fetch adapters, not proof of the real WebLLM installation, real mailbox delivery, HTTP module loading, or GPU execution. The app itself has none of those test-tool dependencies.
