#!/usr/bin/env python3
"""Install genuine, pinned WebLLM assets for entirely local serving.

Python 3.9+ standard library only. No package manager or build step.
Run once online: python install_ai.py
Audit a copied offline folder: python install_ai.py --verify
Network installation could not be exercised in the authoring environment.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import re
import shutil
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION = "0.2.85"
MODEL_ID = "Qwen2.5-0.5B-Instruct-q4f32_1-MLC"
REPO = f"mlc-ai/{MODEL_ID}"
MODEL_DIR = ROOT / "models" / MODEL_ID
VENDOR_DIR = ROOT / "vendor" / "webllm"
MANIFEST = ROOT / "vendor" / "manifest.json"
NPM_META = f"https://registry.npmjs.org/@mlc-ai%2Fweb-llm/{VERSION}"
LIB_VERSION = "v0_2_84/base"
LIB_FILE = "Qwen2-0.5B-Instruct-q4f32_1_cs1k-webgpu.wasm"
LIB_URL = f"https://raw.githubusercontent.com/mlc-ai/binary-mlc-llm-libs/main/web-llm-models/{LIB_VERSION}/{LIB_FILE}"
HEADERS = {"User-Agent": "StockWise-offline-asset-installer/2.0"}
SOURCES: dict[str, str] = {}

def request(url: str):
    if not url.startswith("https://"):
        raise ValueError(f"Only HTTPS download sources are supported: {url}")
    return urllib.request.urlopen(urllib.request.Request(url, headers=HEADERS), timeout=90)

def get_json(url: str) -> dict:
    with request(url) as response:
        return json.load(response)

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()

def download(url: str, destination: Path, expected_bytes: int | None = None) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Files with a known expected byte length may be resumed across installer runs.
    if expected_bytes and destination.is_file() and destination.stat().st_size == expected_bytes:
        print(f"Using existing {destination.name}", flush=True)
        SOURCES[str(destination.relative_to(ROOT))] = url
        return
    partial = destination.with_name(destination.name + ".part")
    for attempt in range(3):
        try:
            print(f"Downloading {destination.name} ...", flush=True)
            with request(url) as response, partial.open("wb") as output:
                length = int(response.headers.get("Content-Length", "0"))
                total = 0
                for chunk in iter(lambda: response.read(1024 * 1024), b""):
                    output.write(chunk)
                    total += len(chunk)
            if (length and total != length) or (expected_bytes and total != expected_bytes):
                raise ValueError(f"Incomplete {destination.name}: {total} bytes")
            if total < 1:
                raise ValueError(f"Empty download: {destination.name}")
            partial.replace(destination)
            SOURCES[str(destination.relative_to(ROOT))] = url
            return
        except (OSError, ValueError, urllib.error.URLError):
            partial.unlink(missing_ok=True)
            if attempt == 2:
                raise
            time.sleep(1 + attempt)

def safe_name(name: str) -> str:
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_.\-/]+", name) or ".." in name or name.startswith("/"):
        raise ValueError(f"Unsafe asset name in upstream manifest: {name!r}")
    return name

def install_runtime() -> None:
    meta = get_json(NPM_META)
    if meta.get("version") != VERSION:
        raise ValueError("NPM metadata returned a different version.")
    tar_url = meta["dist"]["tarball"]
    integrity = meta["dist"].get("integrity", "")
    with tempfile.TemporaryDirectory(prefix="stockwise-ai-") as tmp:
        archive = Path(tmp) / "runtime.tgz"
        print(f"Downloading official WebLLM {VERSION} package ...", flush=True)
        with request(tar_url) as response, archive.open("wb") as out:
            shutil.copyfileobj(response, out)
        if integrity:
            spec = next((part for part in integrity.split() if part.startswith("sha512-")), integrity.split()[0])
            algorithm, expected = spec.split("-", 1)
            digest = hashlib.new(algorithm, archive.read_bytes()).digest()
            if base64.b64encode(digest).decode() != expected:
                raise ValueError("NPM package integrity check failed.")
        else:
            expected = meta["dist"].get("shasum")
            if not expected or hashlib.sha1(archive.read_bytes()).hexdigest() != expected:
                raise ValueError("NPM package checksum is missing or invalid.")
        VENDOR_DIR.mkdir(parents=True, exist_ok=True)
        with tarfile.open(archive, "r:gz") as bundle:
            # No general tar extraction: ignore symlinks, path traversal, dev files.
            for member in bundle.getmembers():
                if not member.isfile():
                    continue
                name = member.name
                if name.startswith("package/lib/") and name.endswith((".js", ".wasm", ".json")):
                    relative = safe_name(name.removeprefix("package/lib/"))
                    dest = VENDOR_DIR / relative
                elif name in ("package/LICENSE", "package/LICENSE.txt", "package/NOTICE", "package/package.json"):
                    dest = VENDOR_DIR / ("package-info.json" if name.endswith("package.json") else name.split("/")[-1])
                else:
                    continue
                source = bundle.extractfile(member)
                if source is None:
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                with source, dest.open("wb") as out:
                    shutil.copyfileobj(source, out)
                SOURCES[str(dest.relative_to(ROOT))] = tar_url
        entry = VENDOR_DIR / "index.js"
        if not entry.is_file() or entry.stat().st_size < 10000:
            raise ValueError("The NPM archive has no valid bundled lib/index.js.")
        code = entry.read_text(encoding="utf-8")
        # This must be the browser-ready bundle, not a bare-import source module.
        static_imports = re.findall(r"(?m)^\s*(?:import|export)\s+(?:[^;\n]*?\s+from\s+)?[\"']([^\"']+)[\"']", code)
        dynamic_imports = re.findall(r"\bimport\s*\(\s*[\"']([^\"']+)[\"']", code)
        for module in static_imports + dynamic_imports:
            if not module.startswith(("./", "../")):
                raise ValueError(f"Unexpected nonlocal import in runtime: {module}. No build tools or remote runtime fallback will be used.")
    print("WebLLM runtime package verified.", flush=True)

def install_model() -> str:
    meta = get_json(f"https://huggingface.co/api/models/{REPO}?blobs=true")
    revision = meta["sha"]
    if not re.fullmatch(r"[a-f0-9]{40,64}", revision):
        raise ValueError("Invalid model revision from Hugging Face.")
    base = f"https://huggingface.co/{REPO}/resolve/{revision}/"
    siblings = {item["rfilename"]: item for item in meta.get("siblings", [])}
    def fetch_file(name: str, expected: int | None = None):
        safe_name(name)
        entry = siblings.get(name, {})
        size = expected or entry.get("size") or entry.get("lfs", {}).get("size")
        download(base + urllib.parse.quote(name, safe="/"), MODEL_DIR / name, size)
        known_hash = entry.get("lfs", {}).get("sha256")
        if known_hash and sha256(MODEL_DIR / name) != known_hash:
            (MODEL_DIR / name).unlink(missing_ok=True)
            raise ValueError(f"Upstream SHA-256 mismatch for {name}; rerun installation.")
    fetch_file("mlc-chat-config.json")
    fetch_file("ndarray-cache.json")
    config = json.loads((MODEL_DIR / "mlc-chat-config.json").read_text())
    cache = json.loads((MODEL_DIR / "ndarray-cache.json").read_text())
    tokenizer_files = config.get("tokenizer_files", [])
    if not tokenizer_files:
        raise ValueError("No tokenizer files listed in model configuration.")
    for name in dict.fromkeys(tokenizer_files):
        fetch_file(name)
    records = cache.get("records", [])
    if not records:
        raise ValueError("No weight shards listed in ndarray-cache.json.")
    shards = {}
    for record in records:
        path = record.get("dataPath")
        if not path:
            raise ValueError("A weight shard has no dataPath.")
        shards[safe_name(path)] = record.get("nbytes")
    for name, size in shards.items():
        fetch_file(name, size)
    # Newer runtimes may prefer this additional manifest when present upstream.
    if "tensor-cache.json" in siblings:
        fetch_file("tensor-cache.json")
    for name in ("README.md", "LICENSE", "LICENSE.txt", "NOTICE"):
        if name in siblings:
            fetch_file(name)
    download(LIB_URL, MODEL_DIR / "model.wasm")
    with (MODEL_DIR / "model.wasm").open("rb") as wasm:
        if wasm.read(4) != b"\x00asm":
            raise ValueError("The model library download is not WebAssembly.")
    # Keep the original model license even when the MLC conversion omits it.
    if not (MODEL_DIR / "LICENSE").exists():
        download("https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct/resolve/main/LICENSE", MODEL_DIR / "LICENSE")
    return revision

def write_manifest(revision: str) -> None:
    files = []
    for directory in (VENDOR_DIR, MODEL_DIR):
        for path in sorted(directory.rglob("*")):
            if path.is_file() and not path.name.endswith(".part"):
                relative = path.relative_to(ROOT).as_posix()
                files.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path), "source": SOURCES.get(relative, "retained local file")})
    data = {"installed": True, "webllm_version": VERSION, "model_id": MODEL_ID, "model_revision": revision, "model_library_version": LIB_VERSION, "created_at": datetime.now(timezone.utc).isoformat(), "total_bytes": sum(item["bytes"] for item in files), "files": files}
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    temporary = MANIFEST.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    temporary.replace(MANIFEST)

def verify() -> bool:
    if not MANIFEST.exists():
        print("AI assets are not installed. Run python install_ai.py while online.")
        return False
    manifest = json.loads(MANIFEST.read_text())
    if not manifest.get("installed") or not manifest.get("files"):
        print("AI assets are not installed. The core app and built-in tools work offline now.")
        print("Run python install_ai.py once with internet access, then copy this entire folder.")
        return False
    for item in manifest["files"]:
        path = ROOT / safe_name(item["path"])
        if not path.is_file() or path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
            print(f"FAILED: {item['path']} is missing, truncated or modified.")
            return False
    print(f"Verified {len(manifest['files'])} local assets ({manifest['total_bytes'] / 1024**2:.1f} MiB).")
    print("All asset bytes are local. GPU inference still requires a compatible WebGPU browser.")
    return True

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", action="store_true", help="Check local assets and hashes without network access")
    args = parser.parse_args()
    try:
        if args.verify:
            return 0 if verify() else 1
        print(f"Installing WebLLM {VERSION} and {MODEL_ID}.")
        print("This setup downloads several hundred MB once. The app itself never uses a CDN.")
        print("Official model/library sources and SHA-256 hashes will be recorded in vendor/manifest.json.")
        install_runtime()
        revision = install_model()
        write_manifest(revision)
        if not verify():
            return 1
        print("\nReady. Run: python -m http.server 8000 --bind 127.0.0.1")
        print("Open http://localhost:8000, then Assistant > Enable local AI.")
        print("Copy the whole folder, including vendor/ and models/, for first-run offline use elsewhere.")
        return 0
    except (OSError, ValueError, KeyError, TypeError, urllib.error.URLError, tarfile.TarError) as error:
        print(f"\nInstallation did not complete: {error}", file=sys.stderr)
        print("No fake runtime or model is substituted. The built-in app remains usable.", file=sys.stderr)
        print("Check your connection, free disk space and access to npmjs.org, huggingface.co and raw.githubusercontent.com, then rerun.", file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
