import { WebWorkerMLCEngineHandler } from "./vendor/webllm/index.js";
const handler = new WebWorkerMLCEngineHandler();
self.onmessage = event => handler.onmessage(event);
