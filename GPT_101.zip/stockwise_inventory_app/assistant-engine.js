/* Real WebLLM integration. All executable/model URLs are same-origin. */
const MODEL_ID = "Qwen2.5-0.5B-Instruct-q4f32_1-MLC";
export class LocalAssistant {
  constructor() { this.engine=null; this.worker=null; this.ready=false; this.sequence=0; }
  async load(onProgress = () => {}) {
    if (!globalThis.isSecureContext) throw new Error("WebGPU needs localhost or HTTPS. Open http://localhost:8000 on the machine running the server. On another device, use a trusted HTTPS server.");
    if (!navigator.gpu) throw new Error("This browser/device does not expose WebGPU. Use a WebGPU-capable browser with hardware acceleration. All built-in inventory tools still work.");
    const adapter=await navigator.gpu.requestAdapter();
    if (!adapter) throw new Error("No compatible WebGPU adapter was found. Check browser hardware acceleration and GPU support. Built-in tools do not require a GPU.");
    const manifestResponse=await fetch(new URL("./vendor/manifest.json",import.meta.url),{cache:"no-store"});
    const manifest=await manifestResponse.json();
    if (!manifestResponse.ok || manifest.installed !== true || !Array.isArray(manifest.files)) throw new Error("Local AI assets are not installed. Run python install_ai.py while online, then refresh.");
    onProgress({progress:0,text:"Checking local model files..."});
    // Check every file, not just a flag, so an incomplete copied package fails clearly.
    for (const file of manifest.files) {
      if (!/^(vendor|models)\/[a-zA-Z0-9_./-]+$/.test(file.path) || file.path.includes("..")) throw new Error("The local AI manifest contains an invalid file path.");
      const response=await fetch(new URL(file.path,import.meta.url),{method:"HEAD",cache:"no-store"});
      const length=Number(response.headers.get("content-length"));
      if (!response.ok || (length && length !== file.bytes)) throw new Error(`Missing or incomplete local asset: ${file.path}. Run python install_ai.py --verify or reinstall the assets.`);
    }
    const webllm=await import("./vendor/webllm/index.js");
    const base=new URL(`./models/${MODEL_ID}/`,import.meta.url);
    const appConfig={
      cacheBackend:"cache",
      model_list:[{
        model_id:MODEL_ID,
        model:base.href,
        model_lib:new URL("model.wasm",base).href,
        overrides:{context_window_size:4096},
        low_resource_required:true
      }]
    };
    this.worker=new Worker(new URL("./webllm-worker.js",import.meta.url),{type:"module"});
    let timer;
    const failure=new Promise((_,reject)=>{
      this.worker.addEventListener("error",event=>reject(new Error(event.message || "The local AI worker failed to start.")),{once:true});
      timer=setTimeout(()=>reject(new Error("Model loading timed out. Close memory-heavy tabs and try again. No remote download will be attempted.")),180000);
    });
    try {
      this.engine=await Promise.race([
        webllm.CreateWebWorkerMLCEngine(this.worker,MODEL_ID,{appConfig,initProgressCallback:onProgress,logLevel:"WARN"}),failure
      ]);
      this.ready=true;
    } catch (error) {
      this.worker?.terminate(); this.worker=null; this.engine=null;
      throw error;
    } finally { clearTimeout(timer); }
  }
  async ask(messages,onText) {
    if (!this.ready || !this.engine) throw new Error("Enable the local model first.");
    const request=++this.sequence;
    const clean=messages.map(message=>({role:message.role,content:message.content}));
    while (clean.length>1 && clean[1].role!=="user") clean.splice(1,1);
    let timer;
    const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{this.stop();reject(new Error("Generation stopped after a timeout. Try a shorter question."));},90000);});
    const generate=async()=>{
      const stream=await this.engine.chat.completions.create({messages:clean,stream:true,max_tokens:360,temperature:.4,top_p:.9,repetition_penalty:1.05});
      let text="";
      for await (const chunk of stream) {
        if (request!==this.sequence) break;
        text += chunk.choices?.[0]?.delta?.content || "";
        onText(text);
      }
      return text;
    };
    try { return await Promise.race([generate(),timeout]); }
    finally { clearTimeout(timer); }
  }
  stop() { this.sequence++; try { this.engine?.interruptGenerate(); } catch (_) {} }
  async unload() {
    this.stop(); this.ready=false;
    // Termination is deterministic even when a GPU operation is hung.
    this.worker?.terminate(); this.worker=null; this.engine=null;
  }
}
