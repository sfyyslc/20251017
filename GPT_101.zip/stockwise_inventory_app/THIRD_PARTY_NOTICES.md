# Third-party assets and sources

The delivered archive does not include the WebLLM browser runtime, compiled model library or model weights. It contains integration code and a downloader. After a successful install, retain the downloaded LICENSE/NOTICE files with any redistributed installed folder. No fonts, CDN assets or UI framework libraries are included.

## Official sources used by the installer

- WebLLM 0.2.85 npm metadata: https://registry.npmjs.org/@mlc-ai%2Fweb-llm/0.2.85
- Official documentation: https://webllm.mlc.ai/docs/
- Runtime project and supported model configuration: https://github.com/mlc-ai/web-llm/tree/v0.2.85
- Converted model repository: https://huggingface.co/mlc-ai/Qwen2.5-0.5B-Instruct-q4f32_1-MLC
- Model library repository: https://github.com/mlc-ai/binary-mlc-llm-libs
- Original model and license fallback: https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct

The installer extracts runtime license/notice files where present and downloads model license files. The installed asset manifest records exact local file sizes, SHA-256 hashes, source URLs, runtime version and model repository revision. It is an audit inventory, not a substitute for reviewing applicable upstream licenses or for verifying GPU behavior.

Playwright and Chromium are optional developer test tools only. They are not application dependencies or bundled assets. Python's standard library is used for serving and installation; Node can run the pure parser tests without installing any packages.
