# Test report - 2026-10-17

## Executed automated checks

**63 parser/validation assertions passed**, **79 main isolated browser assertions passed**, and **10 additional isolated browser assertions passed**: 152 assertions in total. The optional test scripts are included under `tests/`.

Parser checks cover stock delivery/count/removal previews, unchanged pre-confirmation state, metric and imperial weight conversions, liters/milliliters, dozens, whole-count limits, ambiguous numbers, negatives, oversize values, unknown package sizes, mass/volume mismatches, negation, overlapping ingredient aliases, settings, email/header validation and stale-action rejection.

Main browser checks exercise the actual application JavaScript and DOM: populated sample data, reminder initial display, same-visit snooze, next-visit recurrence, persistent acknowledgement, fresh shortage episodes, critical escalation, delivery confirmation, undo, cancellation, grams conversion, stale preview refusal, glossary, live favorites, exact costs, truthful missing-model UI, business/email/theme/forecast settings, orders and ingredient deductions, insufficient-stock blocking, Unicode profile updates, MIME email drafts and their parsed JSON/CSV attachments, non-recursive snapshots, export files, reminder preferences, old-state migration and persistence.

The same suite checks all eight views at **320, 390, 768 and 1440 CSS pixels**, with no page-level horizontal overflow. Inventory and report tables intentionally retain their own horizontal scroll containers.

Additional browser checks cover mobile menu focusability and navigation, HTML-like business names rendered as text, storage failure/recovery warnings, malformed import rejection, real JSON file-input restoration with confirmation, and CSV formula-marker escaping.

JavaScript syntax checks passed for application and module files. Python installer syntax compiled. The standard Python HTTP server served the application successfully on localhost. `python install_ai.py --verify` correctly reports missing assets and exits nonzero for this delivered uninstalled package; this is expected, not a claim that model validation passed.

## Test environment and adaptations

Node 22, Python 3.13, Chromium, and Playwright were available. Managed Chromium policy blocked direct HTTP and file URL navigation, including localhost. Those policies were not changed or bypassed.

Browser tests therefore mounted the actual HTML, CSS and application scripts into an isolated blank document. Explicit adapters provided in-memory localStorage, the local missing-assets manifest, and captured download blobs. The production CSP was removed only from that isolated test document to allow test-source injection. Native DOM elements, forms, dialogs, calculations, application state, layout and event handlers were still exercised.

These are **isolated DOM regression tests**, not full end-to-end tests of an ordinary served origin. Layout screenshots were inspected in this same harness. The scripts let the Playwright context manager clean up browser processes rather than depending on an explicit browser-close call in this constrained environment.

## Not verified here

External binary downloads were blocked. No real WebLLM runtime, model shards or compiled model library were obtained. Consequently, **the complete installer download, real module startup, model cache behavior, GPU inference, first-load offline inference, performance and answer quality remain unverified**.

Real browser-origin persistence, production CSP/worker compatibility and physical mobile-device behavior were not exercised in an ordinary URL navigation. No actual mailbox was connected, no email was sent, and native email-client draft handling was not tested. The app does not claim those capabilities were validated.

## Target-device acceptance checklist

After making a backup, serve the folder normally and confirm your existing records migrate at the same browser origin. Save and reopen profile/color changes; snooze a low-stock reminder and reload; create an order and inspect its ingredient deductions; test JSON export/import.

On an internet-connected machine, run `python install_ai.py`, then `python install_ai.py --verify`. Serve that completed folder, disconnect the internet before loading the model, enable local AI and ask an open-ended question on a supported WebGPU device. Test Stop and Unload. Review browser network logs for unexpected remote requests; the configuration is same-origin only.

Use a compatible mail client with a real report destination to verify `.eml` draft opening or send a new message with the separate JSON/CSV exports. Delivery belongs to that mail client, not to StockWise.
