/*
  StockWise Inventory Assistant
  ------------------------------------------------------------
  An offline inventory and demand planning app with a local WebLLM integration.
  Data is saved in localStorage. Forecasting is intentionally transparent:
  it uses weighted averages of recent sales on matching weekdays.
*/

(() => {
  "use strict";

  const STORAGE_KEY = "stockwise-inventory-app-v1";
  const APP_VERSION = 2;
  const FORECAST_LOOKBACK_DAYS = 70;
  const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const SHORT_DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const VIEW_META = {
    dashboard: { title: "Dashboard", eyebrow: "Overview" },
    inventory: { title: "Inventory", eyebrow: "Ingredients & supplies" },
    recipes: { title: "Menu & recipes", eyebrow: "Products & usage" },
    orders: { title: "Log orders", eyebrow: "Daily sales input" },
    forecast: { title: "Forecast", eyebrow: "Demand planning" },
    assistant: { title: "Assistant", eyebrow: "Your local business copilot" },
    account: { title: "Account & email", eyebrow: "Your workspace" },
    preferences: { title: "Appearance & settings", eyebrow: "Make it yours" }
  };

  const currencyFormatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

  const integerFormatter = new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0
  });

  const decimalFormatter = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  });

  const ui = {
    activeView: "dashboard",
    inventorySearch: "",
    inventoryCategory: "all",
    inventoryStatus: "all",
    orderDraft: {},
    recipeIngredientsDraft: [],
    forecastHorizon: 7,
    chat: []
  };

  let state = loadState();

  const els = {};

  // ---------------------------------------------------------------------------
  // Sample data
  // ---------------------------------------------------------------------------

  function createSampleState() {
    const inventory = [
      { id: "ing-rice", name: "Jasmine Rice", category: "Grains", unit: "kg", stock: 18.6, reorderPoint: 12, parLevel: 34, unitCost: 2.35, supplier: "Sunrise Foods" },
      { id: "ing-water", name: "Filtered Water", category: "Beverages & liquids", unit: "L", stock: 62, reorderPoint: 20, parLevel: 80, unitCost: 0.03, supplier: "On-site filtration" },
      { id: "ing-salt", name: "Sea Salt", category: "Seasonings", unit: "kg", stock: 1.45, reorderPoint: 1.2, parLevel: 4, unitCost: 1.1, supplier: "Kitchen Supply Co." },
      { id: "ing-eggs", name: "Eggs", category: "Protein", unit: "each", stock: 72, reorderPoint: 36, parLevel: 144, unitCost: 0.28, supplier: "Green Meadow Farm" },
      { id: "ing-soy", name: "Soy Sauce", category: "Sauces", unit: "L", stock: 3.4, reorderPoint: 2.5, parLevel: 8, unitCost: 3.9, supplier: "East Market Foods" },
      { id: "ing-oil", name: "Cooking Oil", category: "Oils", unit: "L", stock: 4.8, reorderPoint: 3, parLevel: 10, unitCost: 2.8, supplier: "Kitchen Supply Co." },
      { id: "ing-peas", name: "Green Peas", category: "Produce", unit: "kg", stock: 5.2, reorderPoint: 3, parLevel: 10, unitCost: 3.4, supplier: "Fresh Route Produce" },
      { id: "ing-carrots", name: "Carrots", category: "Produce", unit: "kg", stock: 1.1, reorderPoint: 2.5, parLevel: 9, unitCost: 1.75, supplier: "Fresh Route Produce" },
      { id: "ing-onions", name: "Yellow Onions", category: "Produce", unit: "kg", stock: 3.1, reorderPoint: 2.5, parLevel: 9, unitCost: 1.55, supplier: "Fresh Route Produce" },
      { id: "ing-chicken", name: "Chicken Breast", category: "Protein", unit: "kg", stock: 6.2, reorderPoint: 5, parLevel: 16, unitCost: 7.6, supplier: "Harbor Protein Co." },
      { id: "ing-shrimp", name: "Peeled Shrimp", category: "Protein", unit: "kg", stock: 2.2, reorderPoint: 3, parLevel: 10, unitCost: 12.9, supplier: "Harbor Protein Co." },
      { id: "ing-noodles", name: "Wheat Noodles", category: "Grains", unit: "kg", stock: 8.5, reorderPoint: 4, parLevel: 14, unitCost: 3.15, supplier: "East Market Foods" },
      { id: "ing-garlic", name: "Garlic", category: "Produce", unit: "kg", stock: 0.35, reorderPoint: 0.8, parLevel: 2.5, unitCost: 4.8, supplier: "Fresh Route Produce" },
      { id: "ing-cabbage", name: "Green Cabbage", category: "Produce", unit: "kg", stock: 3.8, reorderPoint: 2, parLevel: 8, unitCost: 1.65, supplier: "Fresh Route Produce" },
      { id: "ing-scallions", name: "Spring Onions", category: "Produce", unit: "kg", stock: 0.8, reorderPoint: 1.2, parLevel: 4, unitCost: 5.25, supplier: "Fresh Route Produce" },
      { id: "ing-tofu", name: "Firm Tofu", category: "Protein", unit: "kg", stock: 3.2, reorderPoint: 2.5, parLevel: 9, unitCost: 4.35, supplier: "East Market Foods" }
    ];

    const recipes = [
      {
        id: "recipe-classic-rice",
        name: "Classic Fried Rice",
        category: "Rice bowls",
        icon: "🍚",
        price: 11.5,
        active: true,
        ingredients: [
          { itemId: "ing-rice", quantity: 0.18 },
          { itemId: "ing-water", quantity: 0.2 },
          { itemId: "ing-salt", quantity: 0.003 },
          { itemId: "ing-eggs", quantity: 1 },
          { itemId: "ing-soy", quantity: 0.014 },
          { itemId: "ing-oil", quantity: 0.01 },
          { itemId: "ing-peas", quantity: 0.03 },
          { itemId: "ing-carrots", quantity: 0.025 },
          { itemId: "ing-onions", quantity: 0.02 },
          { itemId: "ing-garlic", quantity: 0.004 },
          { itemId: "ing-scallions", quantity: 0.008 }
        ]
      },
      {
        id: "recipe-chicken-rice",
        name: "Chicken Fried Rice",
        category: "Rice bowls",
        icon: "🍗",
        price: 14.25,
        active: true,
        ingredients: [
          { itemId: "ing-rice", quantity: 0.17 },
          { itemId: "ing-water", quantity: 0.19 },
          { itemId: "ing-salt", quantity: 0.003 },
          { itemId: "ing-eggs", quantity: 1 },
          { itemId: "ing-soy", quantity: 0.016 },
          { itemId: "ing-oil", quantity: 0.012 },
          { itemId: "ing-peas", quantity: 0.025 },
          { itemId: "ing-carrots", quantity: 0.025 },
          { itemId: "ing-onions", quantity: 0.02 },
          { itemId: "ing-garlic", quantity: 0.004 },
          { itemId: "ing-scallions", quantity: 0.008 },
          { itemId: "ing-chicken", quantity: 0.11 }
        ]
      },
      {
        id: "recipe-shrimp-rice",
        name: "Shrimp Fried Rice",
        category: "Rice bowls",
        icon: "🍤",
        price: 15.5,
        active: true,
        ingredients: [
          { itemId: "ing-rice", quantity: 0.17 },
          { itemId: "ing-water", quantity: 0.19 },
          { itemId: "ing-salt", quantity: 0.003 },
          { itemId: "ing-eggs", quantity: 1 },
          { itemId: "ing-soy", quantity: 0.016 },
          { itemId: "ing-oil", quantity: 0.012 },
          { itemId: "ing-peas", quantity: 0.025 },
          { itemId: "ing-carrots", quantity: 0.025 },
          { itemId: "ing-onions", quantity: 0.02 },
          { itemId: "ing-garlic", quantity: 0.004 },
          { itemId: "ing-scallions", quantity: 0.008 },
          { itemId: "ing-shrimp", quantity: 0.1 }
        ]
      },
      {
        id: "recipe-vegetable-noodles",
        name: "Vegetable Noodles",
        category: "Noodles",
        icon: "🍜",
        price: 12.75,
        active: true,
        ingredients: [
          { itemId: "ing-noodles", quantity: 0.2 },
          { itemId: "ing-salt", quantity: 0.002 },
          { itemId: "ing-soy", quantity: 0.018 },
          { itemId: "ing-oil", quantity: 0.012 },
          { itemId: "ing-carrots", quantity: 0.03 },
          { itemId: "ing-cabbage", quantity: 0.05 },
          { itemId: "ing-onions", quantity: 0.025 },
          { itemId: "ing-garlic", quantity: 0.004 },
          { itemId: "ing-scallions", quantity: 0.008 }
        ]
      },
      {
        id: "recipe-tofu-bowl",
        name: "Tofu Rice Bowl",
        category: "Rice bowls",
        icon: "🥢",
        price: 13.25,
        active: true,
        ingredients: [
          { itemId: "ing-rice", quantity: 0.18 },
          { itemId: "ing-water", quantity: 0.2 },
          { itemId: "ing-tofu", quantity: 0.14 },
          { itemId: "ing-soy", quantity: 0.015 },
          { itemId: "ing-oil", quantity: 0.008 },
          { itemId: "ing-carrots", quantity: 0.03 },
          { itemId: "ing-cabbage", quantity: 0.04 },
          { itemId: "ing-garlic", quantity: 0.004 },
          { itemId: "ing-scallions", quantity: 0.01 }
        ]
      },
      {
        id: "recipe-egg-rolls",
        name: "Vegetable Egg Rolls",
        category: "Sides",
        icon: "🥟",
        price: 7.5,
        active: true,
        ingredients: [
          { itemId: "ing-eggs", quantity: 0.25 },
          { itemId: "ing-oil", quantity: 0.02 },
          { itemId: "ing-carrots", quantity: 0.02 },
          { itemId: "ing-cabbage", quantity: 0.08 },
          { itemId: "ing-onions", quantity: 0.015 },
          { itemId: "ing-garlic", quantity: 0.003 },
          { itemId: "ing-scallions", quantity: 0.006 }
        ]
      }
    ];

    const inventoryById = Object.fromEntries(inventory.map((item) => [item.id, item]));
    const recipeCost = (recipe) => recipe.ingredients.reduce((sum, ingredient) => {
      const item = inventoryById[ingredient.itemId];
      return sum + (item ? item.unitCost * ingredient.quantity : 0);
    }, 0);

    // Base demand by weekday (Sunday = 0). Friday and Saturday are deliberately
    // busiest so the forecast has a clear, realistic pattern to detect.
    const demandByRecipe = {
      "recipe-classic-rice": [10, 9, 10, 11, 14, 18, 20],
      "recipe-chicken-rice": [6, 6, 7, 8, 10, 14, 15],
      "recipe-shrimp-rice": [3, 2, 3, 3, 5, 8, 9],
      "recipe-vegetable-noodles": [5, 5, 6, 6, 8, 10, 11],
      "recipe-tofu-bowl": [4, 4, 4, 5, 6, 7, 7],
      "recipe-egg-rolls": [5, 4, 5, 6, 8, 10, 12]
    };

    const today = startOfDay(new Date());
    const orders = [];

    for (let offset = 56; offset >= 1; offset -= 1) {
      const date = addDays(today, -offset);
      const dateKey = toDateKey(date);
      const historyIndex = 56 - offset;
      const trendFactor = 0.91 + (historyIndex / 55) * 0.14;
      const lunchLines = [];
      const dinnerLines = [];

      recipes.forEach((recipe, recipeIndex) => {
        const base = demandByRecipe[recipe.id][date.getDay()];
        const patternVariation = 1 + Math.sin((historyIndex + 1) * 0.77 + recipeIndex * 1.13) * 0.08;
        const eventBump = historyIndex === 45 && date.getDay() === 5 ? 1.18 : 1;
        const totalQuantity = Math.max(0, Math.round(base * trendFactor * patternVariation * eventBump));
        const lunchShare = 0.43 + ((historyIndex + recipeIndex) % 3) * 0.025;
        const lunchQuantity = Math.max(0, Math.round(totalQuantity * lunchShare));
        const dinnerQuantity = Math.max(0, totalQuantity - lunchQuantity);
        const unitCost = recipeCost(recipe);

        if (lunchQuantity > 0) {
          lunchLines.push({
            recipeId: recipe.id,
            name: recipe.name,
            quantity: lunchQuantity,
            unitPrice: recipe.price,
            unitCost
          });
        }
        if (dinnerQuantity > 0) {
          dinnerLines.push({
            recipeId: recipe.id,
            name: recipe.name,
            quantity: dinnerQuantity,
            unitPrice: recipe.price,
            unitCost
          });
        }
      });

      const lunchDate = new Date(date);
      lunchDate.setHours(12, 20, 0, 0);
      const dinnerDate = new Date(date);
      dinnerDate.setHours(18, 15, 0, 0);

      orders.push({
        id: `sample-lunch-${dateKey}`,
        date: dateKey,
        createdAt: lunchDate.toISOString(),
        note: "Lunch service (sample)",
        lines: lunchLines
      });
      orders.push({
        id: `sample-dinner-${dateKey}`,
        date: dateKey,
        createdAt: dinnerDate.toISOString(),
        note: "Dinner service (sample)",
        lines: dinnerLines
      });
    }

    const activityDate = (daysAgo, hour) => {
      const date = addDays(today, -daysAgo);
      date.setHours(hour, 0, 0, 0);
      return date.toISOString();
    };

    return {
      version: APP_VERSION,
      settings: {
        businessName: "Harbor Bowl Kitchen",
        currency: "USD",
        ownerName: "Morgan Lee",
        email: "owner@harborbowl.example",
        themeColor: "#195f3e",
        defaultHorizon: 7,
        remindersEnabled: true,
        autoLoadAI: false
      },
      reminders: {},
      reportHistory: [{ id: "sample-report", createdAt: activityDate(1, 18), recipient: "owner@harborbowl.example", status: "sample", subject: "Harbor Bowl Kitchen - inventory report", snapshot: null }],
      inventory,
      recipes,
      orders,
      activities: [
        { id: "act-1", type: "order", message: "Dinner service logged", detail: "58 menu units recorded from sample data", createdAt: activityDate(1, 18) },
        { id: "act-2", type: "stock", message: "Carrot count updated", detail: "Stock adjusted after a physical count", createdAt: activityDate(2, 9) },
        { id: "act-3", type: "delivery", message: "Egg delivery received", detail: "48 eggs added from Green Meadow Farm", createdAt: activityDate(3, 8) },
        { id: "act-4", type: "recipe", message: "Tofu Rice Bowl recipe reviewed", detail: "Per-serving ingredient amounts confirmed", createdAt: activityDate(5, 15) },
        { id: "act-5", type: "system", message: "Sample workspace created", detail: "Eight weeks of realistic history loaded", createdAt: activityDate(56, 9) }
      ]
    };
  }

  // ---------------------------------------------------------------------------
  // Utilities and persistence
  // ---------------------------------------------------------------------------

  function startOfDay(date) {
    const result = new Date(date);
    result.setHours(0, 0, 0, 0);
    return result;
  }

  function addDays(date, amount) {
    const result = new Date(date);
    result.setDate(result.getDate() + amount);
    return result;
  }

  function toDateKey(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function dateFromKey(dateKey) {
    const [year, month, day] = String(dateKey).split("-").map(Number);
    return new Date(year, month - 1, day, 12, 0, 0, 0);
  }

  function daysBetween(laterDate, earlierDate) {
    const milliseconds = startOfDay(laterDate) - startOfDay(earlierDate);
    return Math.round(milliseconds / 86400000);
  }

  function formatCurrency(value) {
    return currencyFormatter.format(Number.isFinite(Number(value)) ? Number(value) : 0);
  }

  function formatNumber(value, maxDecimals = 2) {
    const numeric = Number.isFinite(Number(value)) ? Number(value) : 0;
    return new Intl.NumberFormat("en-US", { maximumFractionDigits: maxDecimals }).format(numeric);
  }

  function formatQuantity(value, unit, options = {}) {
    const numeric = Math.max(0, Number(value) || 0);
    const decimals = options.precise ? 3 : (unit === "each" || unit === "pack" || unit === "case" ? 0 : 2);
    const formatted = new Intl.NumberFormat("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: decimals
    }).format(numeric);
    return `${formatted} ${unit}`;
  }

  function formatDate(dateOrKey, options = {}) {
    const date = typeof dateOrKey === "string" && /^\d{4}-\d{2}-\d{2}$/.test(dateOrKey)
      ? dateFromKey(dateOrKey)
      : new Date(dateOrKey);
    return new Intl.DateTimeFormat("en-US", {
      month: options.long ? "long" : "short",
      day: "numeric",
      year: options.year ? "numeric" : undefined,
      weekday: options.weekday ? "short" : undefined
    }).format(date);
  }

  function formatRelativeDate(dateString) {
    const date = new Date(dateString);
    const today = startOfDay(new Date());
    const diff = daysBetween(today, date);
    if (diff === 0) return "Today";
    if (diff === 1) return "Yesterday";
    if (diff > 1 && diff < 7) return `${diff} days ago`;
    return formatDate(date, { year: date.getFullYear() !== today.getFullYear() });
  }

  function escapeHTML(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function roundTo(value, decimals = 4) {
    const factor = 10 ** decimals;
    return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function sum(values) {
    return values.reduce((total, value) => total + (Number(value) || 0), 0);
  }

  function uniqueId(prefix) {
    return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }

  function getInitials(name) {
    return String(name || "Business")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0].toUpperCase())
      .join("");
  }

  function getCategoryIcon(category) {
    const normalized = String(category || "").toLowerCase();
    if (normalized.includes("produce")) return "◉";
    if (normalized.includes("protein")) return "◆";
    if (normalized.includes("grain")) return "≋";
    if (normalized.includes("sauce")) return "◒";
    if (normalized.includes("oil")) return "◐";
    if (normalized.includes("season")) return "✦";
    if (normalized.includes("liquid") || normalized.includes("beverage")) return "◌";
    return "□";
  }

  function getActivityIcon(type) {
    const icons = {
      order: "＋",
      stock: "▦",
      delivery: "↓",
      recipe: "◫",
      system: "✦"
    };
    return icons[type] || "•";
  }

  function normalizeState(candidate) {
    if (!candidate || typeof candidate !== "object") throw new Error("Backup is not a valid object.");
    if (!Array.isArray(candidate.inventory) || !Array.isArray(candidate.recipes) || !Array.isArray(candidate.orders)) {
      throw new Error("Backup is missing inventory, recipes, or orders.");
    }

    if (candidate.inventory.length > 5000 || candidate.recipes.length > 2000 || candidate.orders.length > 100000) throw new Error("This backup exceeds the local workspace limits.");
    const checkNumbers = (record, keys) => keys.forEach(key => {
      if (record[key] !== undefined && (!Number.isFinite(Number(record[key])) || Number(record[key]) < 0 || Number(record[key]) > 1e12)) throw new Error("Invalid nonnegative number in backup: " + key);
    });
    for (const item of candidate.inventory) {
      if (!item || typeof item !== "object") throw new Error("Invalid inventory record.");
      checkNumbers(item, ["stock", "reorderPoint", "parLevel", "unitCost"]);
    }
    for (const recipe of candidate.recipes) {
      if (!recipe || typeof recipe !== "object") throw new Error("Invalid recipe record.");
      checkNumbers(recipe, ["price"]);
      (recipe.ingredients || []).forEach(ingredient => checkNumbers(ingredient, ["quantity"]));
    }
    for (const collection of [candidate.inventory, candidate.recipes, candidate.orders]) {
      const ids = collection.map(record => record.id).filter(Boolean);
      if (new Set(ids).size !== ids.length) throw new Error("Duplicate record IDs in backup.");
    }

    const normalized = {
      version: APP_VERSION,
      settings: {
        businessName: String(candidate.settings?.businessName || "My Business").slice(0, 60),
        currency: "USD",
        ownerName: String(candidate.settings?.ownerName || "").slice(0, 60),
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(candidate.settings?.email || "") ? String(candidate.settings.email).slice(0, 254) : "",
        themeColor: /^#[0-9a-f]{6}$/i.test(candidate.settings?.themeColor || "") ? candidate.settings.themeColor : "#195f3e",
        defaultHorizon: [7, 14, 30].includes(candidate.settings?.defaultHorizon) ? candidate.settings.defaultHorizon : 7,
        remindersEnabled: candidate.settings?.remindersEnabled !== false,
        autoLoadAI: candidate.settings?.autoLoadAI === true
      },
      reminders: Object.fromEntries(Object.entries(candidate.reminders || {}).filter(([key, value]) => typeof key === "string" && value && ["ok", "later"].includes(value.choice)).map(([key, value]) => [key, {choice: value.choice, severity: value.severity === "critical" ? "critical" : "low", visit: String(value.visit || "").slice(0, 80)}])),
      reportHistory: Array.isArray(candidate.reportHistory) ? candidate.reportHistory.slice(0, 8).filter(report => report && typeof report === "object").map(report => ({
        id: String(report.id || uniqueId("report")).slice(0, 100),
        createdAt: Number.isFinite(Date.parse(report.createdAt)) ? new Date(report.createdAt).toISOString() : new Date().toISOString(),
        recipient: String(report.recipient || "").slice(0, 254),
        status: ["sample", "prepared", "opened"].includes(report.status) ? report.status : "prepared",
        subject: String(report.subject || "StockWise inventory report").replace(/[\r\n]/g, " ").slice(0, 160),
        snapshot: typeof report.snapshot === "string" && report.snapshot.length < 1500000 ? report.snapshot : null
      })) : [],
      inventory: candidate.inventory.map((item) => ({
        id: String(item.id || uniqueId("item")),
        name: String(item.name || "Unnamed item").slice(0, 50),
        category: String(item.category || "Other").slice(0, 30),
        unit: ["kg", "g", "L", "mL", "each", "pack", "case"].includes(item.unit) ? item.unit : "each",
        stock: Math.max(0, Number(item.stock) || 0),
        reorderPoint: Math.max(0, Number(item.reorderPoint) || 0),
        parLevel: Math.max(0, Number(item.parLevel) || 0),
        unitCost: Math.max(0, Number(item.unitCost) || 0),
        supplier: String(item.supplier || "").slice(0, 50)
      })),
      recipes: candidate.recipes.map((recipe) => ({
        id: String(recipe.id || uniqueId("recipe")),
        name: String(recipe.name || "Unnamed menu item").slice(0, 50),
        category: String(recipe.category || "Other").slice(0, 30),
        icon: String(recipe.icon || "🍽️").slice(0, 4),
        price: Math.max(0, Number(recipe.price) || 0),
        active: recipe.active !== false,
        ingredients: Array.isArray(recipe.ingredients)
          ? recipe.ingredients
              .map((ingredient) => ({
                itemId: String(ingredient.itemId || ""),
                quantity: Math.max(0, Number(ingredient.quantity) || 0)
              }))
              .filter((ingredient) => ingredient.itemId && ingredient.quantity > 0)
          : []
      })),
      orders: candidate.orders.map((order) => ({
        id: String(order.id || uniqueId("order")),
        date: /^\d{4}-\d{2}-\d{2}$/.test(order.date) ? order.date : toDateKey(new Date(order.createdAt || Date.now())),
        createdAt: new Date(order.createdAt || Date.now()).toISOString(),
        note: String(order.note || "Order").slice(0, 80),
        lines: Array.isArray(order.lines)
          ? order.lines.map((line) => ({
              recipeId: String(line.recipeId || ""),
              name: String(line.name || "Menu item").slice(0, 50),
              quantity: Math.max(0, Number(line.quantity) || 0),
              unitPrice: Math.max(0, Number(line.unitPrice) || 0),
              unitCost: Math.max(0, Number(line.unitCost) || 0)
            })).filter((line) => line.quantity > 0)
          : []
      })),
      activities: Array.isArray(candidate.activities)
        ? candidate.activities.map((activity) => ({
            id: String(activity.id || uniqueId("activity")),
            type: String(activity.type || "system"),
            message: String(activity.message || "Workspace updated").slice(0, 100),
            detail: String(activity.detail || "").slice(0, 160),
            createdAt: new Date(activity.createdAt || Date.now()).toISOString()
          }))
        : []
    };

    const itemIds = new Set(normalized.inventory.map((item) => item.id));
    normalized.recipes.forEach((recipe) => {
      recipe.ingredients = recipe.ingredients.filter((ingredient) => itemIds.has(ingredient.itemId));
    });

    return normalized;
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        const sample = normalizeState(createSampleState());
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sample));
        return sample;
      }
      return normalizeState(JSON.parse(raw));
    } catch (error) {
      console.warn("Could not load saved StockWise data. Loading sample data instead.", error);
      try { const raw = localStorage.getItem(STORAGE_KEY); if (raw) localStorage.setItem(STORAGE_KEY + "-recovery", raw); } catch (_) {}
      const sample = normalizeState(createSampleState());
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sample));
      } catch (storageError) {
        console.warn("Could not save sample data.", storageError);
      }
      return sample;
    }
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      document.dispatchEvent(new CustomEvent("stockwise:storage", {detail:{saved:true}}));
      return true;
    } catch (error) {
      showToast("Could not save data", "Browser storage may be unavailable or full.", "error");
      console.error(error);
      document.dispatchEvent(new CustomEvent("stockwise:storage", {detail:{saved:false}}));
      return false;
    }
  }

  function addActivity(type, message, detail) {
    state.activities.unshift({
      id: uniqueId("activity"),
      type,
      message,
      detail,
      createdAt: new Date().toISOString()
    });
    state.activities = state.activities.slice(0, 100);
  }

  // ---------------------------------------------------------------------------
  // Core calculations
  // ---------------------------------------------------------------------------

  function getInventoryById(itemId) {
    return state.inventory.find((item) => item.id === itemId);
  }

  function getRecipeById(recipeId) {
    return state.recipes.find((recipe) => recipe.id === recipeId);
  }

  function getStockStatus(item) {
    if (item.stock <= 0 || (item.reorderPoint > 0 && item.stock <= item.reorderPoint * 0.5)) {
      return { key: "critical", label: "Critical", className: "status-pill-danger" };
    }
    if (item.stock <= item.reorderPoint) {
      return { key: "low", label: "Low", className: "status-pill-warning" };
    }
    return { key: "healthy", label: "Healthy", className: "status-pill-success" };
  }

  function getLowStockItems() {
    return state.inventory
      .filter((item) => getStockStatus(item).key !== "healthy")
      .sort((a, b) => {
        const aRatio = a.reorderPoint > 0 ? a.stock / a.reorderPoint : Infinity;
        const bRatio = b.reorderPoint > 0 ? b.stock / b.reorderPoint : Infinity;
        return aRatio - bRatio;
      });
  }

  function getRecipeCost(recipe) {
    return recipe.ingredients.reduce((total, ingredient) => {
      const item = getInventoryById(ingredient.itemId);
      return total + (item ? item.unitCost * ingredient.quantity : 0);
    }, 0);
  }

  function getRecipeCapacity(recipe) {
    if (!recipe.ingredients.length) {
      return { servings: 0, limitingItem: null };
    }

    let servings = Infinity;
    let limitingItem = null;

    recipe.ingredients.forEach((ingredient) => {
      const item = getInventoryById(ingredient.itemId);
      if (!item || ingredient.quantity <= 0) return;
      const possible = Math.floor(item.stock / ingredient.quantity);
      if (possible < servings) {
        servings = possible;
        limitingItem = item;
      }
    });

    if (!Number.isFinite(servings)) servings = 0;
    return { servings: Math.max(0, servings), limitingItem };
  }

  function getOrderRevenue(order) {
    return order.lines.reduce((total, line) => total + line.quantity * line.unitPrice, 0);
  }

  function getOrderCost(order) {
    return order.lines.reduce((total, line) => total + line.quantity * line.unitCost, 0);
  }

  function getOrderUnitCount(order) {
    return sum(order.lines.map((line) => line.quantity));
  }

  function aggregateDailySales() {
    const byDate = new Map();

    state.orders.forEach((order) => {
      if (!byDate.has(order.date)) {
        byDate.set(order.date, { date: order.date, units: 0, revenue: 0, cost: 0, recipes: {} });
      }
      const day = byDate.get(order.date);
      day.units += getOrderUnitCount(order);
      day.revenue += getOrderRevenue(order);
      day.cost += getOrderCost(order);
      order.lines.forEach((line) => {
        day.recipes[line.recipeId] = (day.recipes[line.recipeId] || 0) + line.quantity;
      });
    });

    return byDate;
  }

  function getPeriodStats(days, offsetDays = 0) {
    const today = startOfDay(new Date());
    const periodEnd = addDays(today, -offsetDays);
    const periodStart = addDays(periodEnd, -days);
    const orders = state.orders.filter((order) => {
      const date = dateFromKey(order.date);
      return date >= periodStart && date < periodEnd;
    });

    return {
      units: sum(orders.map(getOrderUnitCount)),
      revenue: sum(orders.map(getOrderRevenue)),
      cost: sum(orders.map(getOrderCost)),
      orderCount: orders.length
    };
  }

  function getRecipeSales(days = 28) {
    const today = startOfDay(new Date());
    const start = addDays(today, -days);
    const totals = {};

    state.orders.forEach((order) => {
      if (dateFromKey(order.date) < start) return;
      order.lines.forEach((line) => {
        totals[line.recipeId] = (totals[line.recipeId] || 0) + line.quantity;
      });
    });

    return totals;
  }

  function getWeekdayAverages() {
    const dailySales = aggregateDailySales();
    const buckets = DAY_NAMES.map((name, index) => ({ index, name, units: 0, days: 0 }));
    const today = startOfDay(new Date());
    const lookbackStart = addDays(today, -FORECAST_LOOKBACK_DAYS);

    dailySales.forEach((day) => {
      const date = dateFromKey(day.date);
      if (date >= lookbackStart && date < addDays(today, 1)) {
        const bucket = buckets[date.getDay()];
        bucket.units += day.units;
        bucket.days += 1;
      }
    });

    return buckets.map((bucket) => ({
      ...bucket,
      average: bucket.days ? bucket.units / bucket.days : 0
    }));
  }

  function getDemandTrend() {
    const recent = getPeriodStats(14, 0).units;
    const previous = getPeriodStats(14, 14).units;
    if (previous <= 0) return { ratio: 1, percent: 0, direction: "steady" };
    const ratio = recent / previous;
    const percent = Math.round((ratio - 1) * 100);
    return {
      ratio,
      percent,
      direction: percent > 2 ? "up" : percent < -2 ? "down" : "steady"
    };
  }

  function predictRecipeForDate(recipeId, targetDate, dailySales) {
    const targetWeekday = targetDate.getDay();
    const today = startOfDay(new Date());
    const lookbackStart = addDays(today, -FORECAST_LOOKBACK_DAYS);
    const samples = [];

    dailySales.forEach((day) => {
      const date = dateFromKey(day.date);
      if (date < lookbackStart || date > today || date.getDay() !== targetWeekday) return;
      samples.push({
        date,
        quantity: day.recipes[recipeId] || 0
      });
    });

    if (!samples.length) return { quantity: 0, sampleCount: 0 };

    let weightedTotal = 0;
    let weightTotal = 0;
    samples.forEach((sample) => {
      const weeksAgo = Math.max(0, daysBetween(today, sample.date) / 7);
      const weight = Math.pow(0.83, weeksAgo);
      weightedTotal += sample.quantity * weight;
      weightTotal += weight;
    });

    const estimate = weightTotal ? weightedTotal / weightTotal : 0;
    return {
      quantity: Math.max(0, Math.round(estimate)),
      sampleCount: samples.length
    };
  }

  function buildForecast(horizon = 7) {
    const days = [];
    const recipeTotals = {};
    const ingredientNeeds = {};
    const activeRecipes = state.recipes.filter((recipe) => recipe.active);
    const dailySales = aggregateDailySales();
    const sampleCounts = [];
    const today = startOfDay(new Date());

    for (let index = 1; index <= horizon; index += 1) {
      const date = addDays(today, index);
      const recipePredictions = {};
      let totalUnits = 0;
      let estimatedRevenue = 0;

      activeRecipes.forEach((recipe) => {
        const prediction = predictRecipeForDate(recipe.id, date, dailySales);
        recipePredictions[recipe.id] = prediction.quantity;
        recipeTotals[recipe.id] = (recipeTotals[recipe.id] || 0) + prediction.quantity;
        totalUnits += prediction.quantity;
        estimatedRevenue += prediction.quantity * recipe.price;
        sampleCounts.push(prediction.sampleCount);

        recipe.ingredients.forEach((ingredient) => {
          ingredientNeeds[ingredient.itemId] = (ingredientNeeds[ingredient.itemId] || 0) + prediction.quantity * ingredient.quantity;
        });
      });

      days.push({
        date,
        dateKey: toDateKey(date),
        totalUnits,
        estimatedRevenue,
        recipes: recipePredictions
      });
    }

    const totalUnits = sum(days.map((day) => day.totalUnits));
    const estimatedRevenue = sum(days.map((day) => day.estimatedRevenue));
    const averageSamples = sampleCounts.length ? sum(sampleCounts) / sampleCounts.length : 0;
    const confidence = averageSamples >= 6 ? "High" : averageSamples >= 3 ? "Medium" : "Low";

    return {
      horizon,
      days,
      recipeTotals,
      ingredientNeeds,
      totalUnits,
      estimatedRevenue,
      confidence,
      averageSamples
    };
  }

  function roundPurchaseQuantity(value, unit) {
    if (value <= 0) return 0;
    if (["each", "pack", "case"].includes(unit)) return Math.ceil(value);
    if (["g", "mL"].includes(unit)) return Math.ceil(value / 10) * 10;
    return Math.ceil(value * 10) / 10;
  }

  function buildPurchasePlan(forecast) {
    return state.inventory
      .map((item) => {
        const expectedUse = forecast.ingredientNeeds[item.id] || 0;
        const safetyStock = item.reorderPoint;
        const rawSuggested = expectedUse + safetyStock - item.stock;
        const suggestedBuy = roundPurchaseQuantity(Math.max(0, rawSuggested), item.unit);
        let reason = "Forecast would leave less than safety stock";
        if (item.stock <= item.reorderPoint) reason = "Already at or below reorder point";
        else if (expectedUse > item.stock) reason = "Expected use exceeds stock on hand";

        return {
          item,
          expectedUse,
          safetyStock,
          suggestedBuy,
          cost: suggestedBuy * item.unitCost,
          reason
        };
      })
      .filter((entry) => entry.suggestedBuy > 0)
      .sort((a, b) => b.cost - a.cost);
  }

  function calculateDraft() {
    const lines = [];
    const requirements = {};
    let revenue = 0;
    let cost = 0;
    let units = 0;

    Object.entries(ui.orderDraft).forEach(([recipeId, quantity]) => {
      const numericQuantity = Math.max(0, Number(quantity) || 0);
      const recipe = getRecipeById(recipeId);
      if (!recipe || numericQuantity <= 0) return;

      const unitCost = getRecipeCost(recipe);
      lines.push({ recipe, quantity: numericQuantity, unitCost });
      revenue += numericQuantity * recipe.price;
      cost += numericQuantity * unitCost;
      units += numericQuantity;

      recipe.ingredients.forEach((ingredient) => {
        requirements[ingredient.itemId] = (requirements[ingredient.itemId] || 0) + ingredient.quantity * numericQuantity;
      });
    });

    const shortages = Object.entries(requirements)
      .map(([itemId, required]) => {
        const item = getInventoryById(itemId);
        if (!item || required <= item.stock) return null;
        return { item, required, shortBy: required - item.stock };
      })
      .filter(Boolean)
      .sort((a, b) => b.shortBy - a.shortBy);

    return { lines, requirements, revenue, cost, units, shortages };
  }

  // ---------------------------------------------------------------------------
  // Rendering helpers
  // ---------------------------------------------------------------------------

  function metricCardHTML({ label, value, icon, foot, color = "var(--primary)", tint = "var(--primary-soft)" }) {
    return `
      <article class="metric-card" style="--metric-color:${color};--metric-tint:${tint}">
        <div class="metric-card-top">
          <div>
            <span class="metric-label">${escapeHTML(label)}</span>
            <strong class="metric-value">${escapeHTML(value)}</strong>
          </div>
          <span class="metric-icon" aria-hidden="true">${icon}</span>
        </div>
        <div class="metric-foot">${foot}</div>
      </article>
    `;
  }

  function statusPillHTML(status) {
    return `<span class="status-pill ${status.className}"><span class="status-dot-small" aria-hidden="true"></span>${escapeHTML(status.label)}</span>`;
  }

  function showToast(title, message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type === "error" ? "is-error" : type === "success" ? "is-success" : ""}`;
    toast.innerHTML = `
      <span class="toast-icon" aria-hidden="true">${type === "error" ? "!" : type === "success" ? "✓" : "i"}</span>
      <span class="toast-copy">
        <strong>${escapeHTML(title)}</strong>
        <span>${escapeHTML(message)}</span>
      </span>
    `;
    els.toastRegion.appendChild(toast);
    window.setTimeout(() => toast.remove(), 4200);
  }

  function renderHeader() {
    const businessName = state.settings.businessName || "My Business";
    els.businessNameHeader.textContent = businessName;
    els.businessDateHeader.textContent = new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      month: "short",
      day: "numeric"
    }).format(new Date());
    els.businessChip.querySelector(".business-avatar").textContent = getInitials(businessName);
  }

  function renderNavigationBadge() {
    const count = getLowStockItems().length;
    els.inventoryAlertBadge.textContent = String(count);
    els.inventoryAlertBadge.hidden = count === 0;
  }

  function renderDashboard() {
    const lowStock = getLowStockItems();
    const inventoryValue = sum(state.inventory.map((item) => item.stock * item.unitCost));
    const forecast = buildForecast(7);
    const purchasePlan = buildPurchasePlan(forecast);
    const purchaseCost = sum(purchasePlan.map((entry) => entry.cost));
    const last7 = getPeriodStats(7, 0);
    const previous7 = getPeriodStats(7, 7);
    const revenueChange = previous7.revenue > 0 ? Math.round(((last7.revenue / previous7.revenue) - 1) * 100) : 0;
    const weekdayAverages = getWeekdayAverages();
    const busiest = [...weekdayAverages].sort((a, b) => b.average - a.average)[0];

    els.dashboardSummary.textContent = lowStock.length
      ? `${lowStock.length} item${lowStock.length === 1 ? "" : "s"} need attention. ${busiest?.name || "Your busiest day"} is currently the strongest demand day.`
      : `Inventory is above all reorder points. ${busiest?.name || "Your busiest day"} is currently the strongest demand day.`;

    els.dashboardMetrics.innerHTML = [
      metricCardHTML({
        label: "Inventory value",
        value: formatCurrency(inventoryValue),
        icon: "▦",
        foot: `<span>Across <strong>${state.inventory.length}</strong> tracked items</span>`
      }),
      metricCardHTML({
        label: "Low-stock items",
        value: String(lowStock.length),
        icon: "!",
        foot: lowStock.length
          ? `<span><strong>${lowStock.filter((item) => getStockStatus(item).key === "critical").length}</strong> critical right now</span>`
          : "<span>Everything is above its reorder point</span>",
        color: lowStock.length ? "var(--danger)" : "var(--success)",
        tint: lowStock.length ? "var(--danger-soft)" : "var(--success-soft)"
      }),
      metricCardHTML({
        label: "7-day purchase estimate",
        value: formatCurrency(purchaseCost),
        icon: "↓",
        foot: `<span><strong>${purchasePlan.length}</strong> suggested replenishments</span>`,
        color: "var(--warning)",
        tint: "var(--warning-soft)"
      }),
      metricCardHTML({
        label: "Sales, last 7 days",
        value: formatCurrency(last7.revenue),
        icon: "↗",
        foot: `<span><strong>${revenueChange >= 0 ? "+" : ""}${revenueChange}%</strong> vs. prior week</span>`,
        color: revenueChange >= 0 ? "var(--success)" : "var(--danger)",
        tint: revenueChange >= 0 ? "var(--success-soft)" : "var(--danger-soft)"
      })
    ].join("");

    renderDemandChart();
    renderDashboardAlerts(lowStock);
    renderPurchaseSnapshot(purchasePlan);
    renderTopRecipes();
    renderRecentActivity();
  }

  function renderDemandChart() {
    const daily = aggregateDailySales();
    const today = startOfDay(new Date());
    const days = [];

    for (let offset = 13; offset >= 0; offset -= 1) {
      const date = addDays(today, -offset);
      const key = toDateKey(date);
      days.push({ date, units: daily.get(key)?.units || 0 });
    }

    const maxUnits = Math.max(1, ...days.map((day) => day.units));
    const total = sum(days.map((day) => day.units));
    const busiest = [...days].sort((a, b) => b.units - a.units)[0];
    const trend = getDemandTrend();

    els.demandChart.innerHTML = days.map((day) => {
      const height = Math.max(2, (day.units / maxUnits) * 100);
      const isWeekend = [0, 6].includes(day.date.getDay());
      return `
        <div class="chart-column ${isWeekend ? "is-weekend" : ""}" title="${escapeHTML(formatDate(day.date, { weekday: true }))}: ${integerFormatter.format(day.units)} units">
          <div class="chart-bar-shell"><div class="chart-bar" style="height:${height}%"></div></div>
          <span class="chart-label">${SHORT_DAY_NAMES[day.date.getDay()]} ${day.date.getDate()}</span>
        </div>
      `;
    }).join("");

    els.demandLegend.innerHTML = `
      <span><strong>${integerFormatter.format(total)}</strong> menu units recorded</span>
      <span>Peak: <strong>${formatDate(busiest.date, { weekday: true })}</strong> · ${integerFormatter.format(busiest.units)} units</span>
    `;
    els.demandTrendMeta.textContent = trend.direction === "steady"
      ? "Demand is steady vs. prior 14 days"
      : `Demand is ${Math.abs(trend.percent)}% ${trend.direction} vs. prior 14 days`;
  }

  function renderDashboardAlerts(lowStock) {
    if (!lowStock.length) {
      els.dashboardAlerts.innerHTML = `
        <div class="inline-empty">
          <span class="empty-icon" aria-hidden="true">✓</span>
          <strong>No stock alerts</strong>
          <span>Every item is above its reorder point.</span>
        </div>
      `;
      return;
    }

    els.dashboardAlerts.innerHTML = `<div class="alert-list">${lowStock.slice(0, 5).map((item) => {
      const status = getStockStatus(item);
      return `
        <div class="alert-row">
          <span class="item-icon ${status.key === "critical" ? "is-critical" : ""}" aria-hidden="true">${getCategoryIcon(item.category)}</span>
          <span class="alert-copy">
            <strong>${escapeHTML(item.name)}</strong>
            <span>${status.label} · reorder at ${formatQuantity(item.reorderPoint, item.unit)}</span>
          </span>
          <span class="alert-quantity">${formatQuantity(item.stock, item.unit)}</span>
        </div>
      `;
    }).join("")}</div>`;
  }

  function renderPurchaseSnapshot(plan) {
    if (!plan.length) {
      els.purchaseSnapshot.innerHTML = `
        <div class="inline-empty">
          <span class="empty-icon" aria-hidden="true">✓</span>
          <strong>No purchases suggested</strong>
          <span>Current stock covers expected demand and safety levels.</span>
        </div>
      `;
      return;
    }

    const total = sum(plan.map((entry) => entry.cost));
    els.purchaseSnapshot.innerHTML = `
      <div class="snapshot-list">
        ${plan.slice(0, 4).map((entry) => `
          <div class="snapshot-row">
            <span class="item-icon ${getStockStatus(entry.item).key === "critical" ? "is-critical" : ""}" aria-hidden="true">${getCategoryIcon(entry.item.category)}</span>
            <span class="snapshot-copy">
              <strong>${escapeHTML(entry.item.name)}</strong>
              <span>Buy ${formatQuantity(entry.suggestedBuy, entry.item.unit)}</span>
            </span>
            <span class="snapshot-cost">${formatCurrency(entry.cost)}</span>
          </div>
        `).join("")}
      </div>
      <div class="snapshot-total"><span>Estimated 7-day spend</span><strong>${formatCurrency(total)}</strong></div>
    `;
  }

  function renderTopRecipes() {
    const sales = getRecipeSales(28);
    const rankings = state.recipes
      .map((recipe) => ({ recipe, units: sales[recipe.id] || 0 }))
      .sort((a, b) => b.units - a.units)
      .slice(0, 5);

    if (!rankings.length) {
      els.topRecipes.innerHTML = '<div class="inline-empty"><strong>No menu data yet</strong><span>Add recipes and orders to see rankings.</span></div>';
      return;
    }

    els.topRecipes.innerHTML = `<div class="ranking-list">${rankings.map((entry, index) => `
      <div class="ranking-row">
        <span class="rank-number">${index + 1}</span>
        <span class="ranking-copy">
          <strong>${escapeHTML(entry.recipe.name)}</strong>
          <span>${escapeHTML(entry.recipe.category)}</span>
        </span>
        <span class="ranking-value">${integerFormatter.format(entry.units)} sold</span>
      </div>
    `).join("")}</div>`;
  }

  function renderRecentActivity() {
    const activities = [...state.activities]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 5);

    if (!activities.length) {
      els.recentActivity.innerHTML = '<div class="inline-empty"><strong>No activity yet</strong><span>Orders and stock updates will appear here.</span></div>';
      return;
    }

    els.recentActivity.innerHTML = `<div class="activity-list">${activities.map((activity) => `
      <div class="activity-row">
        <span class="activity-icon" aria-hidden="true">${getActivityIcon(activity.type)}</span>
        <span class="activity-copy">
          <strong>${escapeHTML(activity.message)}</strong>
          <span>${escapeHTML(activity.detail)} · ${formatRelativeDate(activity.createdAt)}</span>
        </span>
      </div>
    `).join("")}</div>`;
  }

  function renderInventory() {
    const categories = [...new Set(state.inventory.map((item) => item.category))].sort((a, b) => a.localeCompare(b));
    const currentCategory = ui.inventoryCategory;
    els.inventoryCategoryFilter.innerHTML = `<option value="all">All categories</option>${categories.map((category) => `
      <option value="${escapeHTML(category)}">${escapeHTML(category)}</option>
    `).join("")}`;
    els.inventoryCategoryFilter.value = categories.includes(currentCategory) ? currentCategory : "all";
    if (!categories.includes(currentCategory)) ui.inventoryCategory = "all";

    els.categorySuggestions.innerHTML = categories.map((category) => `<option value="${escapeHTML(category)}"></option>`).join("");

    const low = getLowStockItems();
    const critical = low.filter((item) => getStockStatus(item).key === "critical");
    const inventoryValue = sum(state.inventory.map((item) => item.stock * item.unitCost));
    const suppliers = new Set(state.inventory.map((item) => item.supplier).filter(Boolean));

    els.inventoryMetrics.innerHTML = [
      metricCardHTML({ label: "Tracked items", value: String(state.inventory.length), icon: "▦", foot: `<span>Across <strong>${categories.length}</strong> categories</span>` }),
      metricCardHTML({ label: "Low or critical", value: String(low.length), icon: "!", foot: `<span><strong>${critical.length}</strong> need urgent attention</span>`, color: "var(--danger)", tint: "var(--danger-soft)" }),
      metricCardHTML({ label: "Stock value", value: formatCurrency(inventoryValue), icon: "$", foot: "<span>Quantity on hand × unit cost</span>", color: "var(--info)", tint: "var(--info-soft)" }),
      metricCardHTML({ label: "Suppliers", value: String(suppliers.size), icon: "↔", foot: "<span>Named sources in the item list</span>", color: "var(--warning)", tint: "var(--warning-soft)" })
    ].join("");

    const search = ui.inventorySearch.trim().toLowerCase();
    const filtered = state.inventory
      .filter((item) => {
        const searchable = `${item.name} ${item.category} ${item.supplier}`.toLowerCase();
        const matchesSearch = !search || searchable.includes(search);
        const matchesCategory = ui.inventoryCategory === "all" || item.category === ui.inventoryCategory;
        const matchesStatus = ui.inventoryStatus === "all" || getStockStatus(item).key === ui.inventoryStatus;
        return matchesSearch && matchesCategory && matchesStatus;
      })
      .sort((a, b) => {
        const statusRank = { critical: 0, low: 1, healthy: 2 };
        const difference = statusRank[getStockStatus(a).key] - statusRank[getStockStatus(b).key];
        return difference || a.name.localeCompare(b.name);
      });

    els.inventoryTableBody.innerHTML = filtered.map((item) => {
      const status = getStockStatus(item);
      const percentage = item.parLevel > 0 ? clamp((item.stock / item.parLevel) * 100, 0, 100) : 0;
      const usedIn = state.recipes.filter((recipe) => recipe.ingredients.some((ingredient) => ingredient.itemId === item.id));
      const chips = usedIn.slice(0, 2).map((recipe) => `<span class="usage-chip">${escapeHTML(recipe.name)}</span>`).join("");
      const extra = usedIn.length > 2 ? `<span class="usage-more">+${usedIn.length - 2} more</span>` : "";

      return `
        <tr>
          <td>
            <div class="item-cell">
              <span class="item-cell-icon" aria-hidden="true">${getCategoryIcon(item.category)}</span>
              <span class="item-cell-copy">
                <strong>${escapeHTML(item.name)}</strong>
                <span>${escapeHTML(item.category)}${item.supplier ? ` · ${escapeHTML(item.supplier)}` : ""}</span>
              </span>
            </div>
          </td>
          <td><span class="stock-amount">${formatQuantity(item.stock, item.unit)}</span></td>
          <td class="stock-health-cell">
            <div class="stock-health-top"><span>${statusPillHTML(status)}</span><span>${Math.round(percentage)}% of target</span></div>
            <div class="progress-track"><div class="progress-fill ${status.key === "critical" ? "is-critical" : status.key === "low" ? "is-low" : ""}" style="width:${percentage}%"></div></div>
          </td>
          <td>${formatCurrency(item.unitCost)} <span class="order-detail">/ ${escapeHTML(item.unit)}</span></td>
          <td><div class="usage-chips">${chips || '<span class="usage-more">Not used in a recipe</span>'}${extra}</div></td>
          <td>
            <div class="row-actions">
              <button class="row-action" type="button" data-inventory-action="adjust" data-item-id="${escapeHTML(item.id)}" title="Adjust stock" aria-label="Adjust stock for ${escapeHTML(item.name)}">±</button>
              <button class="row-action" type="button" data-inventory-action="edit" data-item-id="${escapeHTML(item.id)}" title="Edit item" aria-label="Edit ${escapeHTML(item.name)}">✎</button>
              <button class="row-action is-danger" type="button" data-inventory-action="delete" data-item-id="${escapeHTML(item.id)}" title="Delete item" aria-label="Delete ${escapeHTML(item.name)}">×</button>
            </div>
          </td>
        </tr>
      `;
    }).join("");

    els.inventoryEmptyState.hidden = filtered.length > 0;
    els.inventoryTableBody.closest(".table-wrap").hidden = filtered.length === 0;
  }

  function renderRecipes() {
    const activeRecipes = state.recipes.filter((recipe) => recipe.active);
    const averageMargin = activeRecipes.length
      ? sum(activeRecipes.map((recipe) => recipe.price > 0 ? ((recipe.price - getRecipeCost(recipe)) / recipe.price) * 100 : 0)) / activeRecipes.length
      : 0;
    const totalIngredients = new Set(state.recipes.flatMap((recipe) => recipe.ingredients.map((ingredient) => ingredient.itemId))).size;
    const sales = getRecipeSales(28);
    const top = [...state.recipes].sort((a, b) => (sales[b.id] || 0) - (sales[a.id] || 0))[0];

    els.recipeSummaryStrip.innerHTML = `
      <span class="summary-chip"><strong>${state.recipes.length}</strong> menu items</span>
      <span class="summary-chip"><strong>${activeRecipes.length}</strong> active for ordering</span>
      <span class="summary-chip"><strong>${Math.round(averageMargin)}%</strong> average gross margin</span>
      <span class="summary-chip"><strong>${totalIngredients}</strong> linked ingredients</span>
      ${top ? `<span class="summary-chip">Top seller: <strong>${escapeHTML(top.name)}</strong></span>` : ""}
    `;

    els.recipeGrid.innerHTML = state.recipes.map((recipe) => {
      const cost = getRecipeCost(recipe);
      const margin = recipe.price > 0 ? ((recipe.price - cost) / recipe.price) * 100 : 0;
      const capacity = getRecipeCapacity(recipe);
      const ingredientRows = recipe.ingredients.slice(0, 6).map((ingredient) => {
        const item = getInventoryById(ingredient.itemId);
        return item ? `
          <div class="recipe-ingredient-row">
            <span>${escapeHTML(item.name)}</span>
            <strong>${formatQuantity(ingredient.quantity, item.unit, { precise: true })}</strong>
          </div>
        ` : "";
      }).join("");
      const extraIngredients = recipe.ingredients.length > 6
        ? `<div class="recipe-ingredient-row"><span>+ ${recipe.ingredients.length - 6} more ingredients</span><strong></strong></div>`
        : "";

      return `
        <article class="recipe-card ${recipe.active ? "" : "is-hidden"}">
          <div class="recipe-card-header">
            <span class="recipe-icon" aria-hidden="true">${escapeHTML(recipe.icon || "🍽️")}</span>
            <div class="recipe-title-copy">
              <h3>${escapeHTML(recipe.name)}</h3>
              <span>${escapeHTML(recipe.category)} · ${recipe.active ? "Active" : "Hidden"}</span>
            </div>
            <span class="recipe-price">${formatCurrency(recipe.price)}</span>
          </div>
          <div class="recipe-stats">
            <div class="recipe-stat"><span>Food cost</span><strong>${formatCurrency(cost)}</strong></div>
            <div class="recipe-stat"><span>Gross margin</span><strong>${Math.round(margin)}%</strong></div>
            <div class="recipe-stat"><span>Can make now</span><strong>${integerFormatter.format(capacity.servings)}</strong></div>
          </div>
          <div class="recipe-ingredients">
            <div class="recipe-ingredients-title">Per serving</div>
            <div class="recipe-ingredient-list">${ingredientRows}${extraIngredients}</div>
          </div>
          <div class="recipe-card-footer">
            <span class="${capacity.servings < 10 ? "capacity-warning" : "capacity-ok"}">
              ${capacity.limitingItem ? `${capacity.servings < 10 ? "Limited by" : "Lowest capacity:"} ${escapeHTML(capacity.limitingItem.name)}` : "No ingredients linked"}
            </span>
            <div class="row-actions">
              <button class="row-action" type="button" data-recipe-action="edit" data-recipe-id="${escapeHTML(recipe.id)}" title="Edit recipe" aria-label="Edit ${escapeHTML(recipe.name)}">✎</button>
              <button class="row-action is-danger" type="button" data-recipe-action="delete" data-recipe-id="${escapeHTML(recipe.id)}" title="Delete recipe" aria-label="Delete ${escapeHTML(recipe.name)}">×</button>
            </div>
          </div>
        </article>
      `;
    }).join("");

    els.recipeEmptyState.hidden = state.recipes.length > 0;
    els.recipeGrid.hidden = state.recipes.length === 0;
  }

  function renderOrders() {
    const activeRecipes = state.recipes.filter((recipe) => recipe.active);
    els.orderMenuGrid.innerHTML = activeRecipes.length ? activeRecipes.map((recipe) => {
      const quantity = Number(ui.orderDraft[recipe.id] || 0);
      const capacity = getRecipeCapacity(recipe);
      return `
        <article class="order-menu-card ${quantity > 0 ? "is-selected" : ""}">
          <span class="order-menu-icon" aria-hidden="true">${escapeHTML(recipe.icon || "🍽️")}</span>
          <div class="order-menu-copy">
            <strong>${escapeHTML(recipe.name)}</strong>
            <span>${escapeHTML(recipe.category)} · up to ${integerFormatter.format(capacity.servings)} available</span>
            <div class="quantity-stepper" aria-label="Quantity for ${escapeHTML(recipe.name)}">
              <button class="stepper-button" type="button" data-order-action="decrease" data-recipe-id="${escapeHTML(recipe.id)}" aria-label="Remove one ${escapeHTML(recipe.name)}">−</button>
              <span class="stepper-value" aria-live="polite">${integerFormatter.format(quantity)}</span>
              <button class="stepper-button" type="button" data-order-action="increase" data-recipe-id="${escapeHTML(recipe.id)}" aria-label="Add one ${escapeHTML(recipe.name)}">＋</button>
            </div>
          </div>
          <span class="order-menu-price">${formatCurrency(recipe.price)}</span>
        </article>
      `;
    }).join("") : `
      <div class="empty-state panel">
        <div class="empty-icon" aria-hidden="true">◫</div>
        <h3>No active menu items</h3>
        <p>Add or activate a recipe before logging an order.</p>
      </div>
    `;

    renderCurrentOrder();
    renderOrderHistory();
  }

  function renderCurrentOrder() {
    const draft = calculateDraft();
    els.orderItemCount.textContent = `${integerFormatter.format(draft.units)} item${draft.units === 1 ? "" : "s"}`;

    if (!draft.lines.length) {
      els.currentOrderLines.innerHTML = `
        <div class="current-order-empty">
          <span aria-hidden="true">＋</span>
          <p>Use the menu controls to add what this customer ordered.</p>
        </div>
      `;
    } else {
      els.currentOrderLines.innerHTML = `<div class="current-order-list">${draft.lines.map((line) => `
        <div class="current-order-row">
          <span class="current-order-row-icon" aria-hidden="true">${escapeHTML(line.recipe.icon || "🍽️")}</span>
          <span class="current-order-row-copy">
            <strong>${escapeHTML(line.recipe.name)}</strong>
            <span>${integerFormatter.format(line.quantity)} × ${formatCurrency(line.recipe.price)}</span>
          </span>
          <span class="current-order-row-total">${formatCurrency(line.quantity * line.recipe.price)}</span>
        </div>
      `).join("")}</div>`;
    }

    const margin = draft.revenue > 0 ? draft.revenue - draft.cost : 0;
    els.orderTotals.innerHTML = `
      <div class="total-row"><span>Estimated ingredient cost</span><strong>${formatCurrency(draft.cost)}</strong></div>
      <div class="total-row"><span>Estimated gross profit</span><strong>${formatCurrency(margin)}</strong></div>
      <div class="total-row is-main"><span>Order total</span><strong>${formatCurrency(draft.revenue)}</strong></div>
    `;

    if (!draft.lines.length) {
      els.orderStockCheck.innerHTML = "";
    } else if (draft.shortages.length) {
      const first = draft.shortages[0];
      const additional = draft.shortages.length > 1 ? ` and ${draft.shortages.length - 1} more item${draft.shortages.length - 1 === 1 ? "" : "s"}` : "";
      els.orderStockCheck.innerHTML = `
        <div class="stock-check-message is-warning">
          <span aria-hidden="true">!</span>
          <div><strong>Not enough stock</strong>${escapeHTML(first.item.name)} is short by ${formatQuantity(first.shortBy, first.item.unit)}${additional}.</div>
        </div>
      `;
    } else {
      els.orderStockCheck.innerHTML = `
        <div class="stock-check-message">
          <span aria-hidden="true">✓</span>
          <div><strong>Stock check passed</strong>All required ingredients are available.</div>
        </div>
      `;
    }

    els.submitOrderButton.disabled = !draft.lines.length || draft.shortages.length > 0;
  }

  function renderOrderHistory() {
    const recentOrders = [...state.orders]
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 24);

    els.orderHistoryBody.innerHTML = recentOrders.map((order) => {
      const summary = order.lines.slice(0, 2).map((line) => `${line.quantity} ${line.name}`).join(", ");
      const extra = order.lines.length > 2 ? ` +${order.lines.length - 2} more` : "";
      return `
        <tr>
          <td><strong>${formatDate(order.date, { weekday: true })}</strong><div class="order-detail">${new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(new Date(order.createdAt))}</div></td>
          <td><strong>${escapeHTML(order.note || "Order")}</strong><div class="order-detail">${escapeHTML(summary)}${escapeHTML(extra)}</div></td>
          <td>${integerFormatter.format(getOrderUnitCount(order))}</td>
          <td>${formatCurrency(getOrderRevenue(order))}</td>
          <td>${formatCurrency(getOrderCost(order))}</td>
        </tr>
      `;
    }).join("");
  }

  function renderForecast() {
    const horizon = Number(ui.forecastHorizon) || 7;
    els.forecastHorizon.value = String(horizon);
    const forecast = buildForecast(horizon);
    const plan = buildPurchasePlan(forecast);
    const purchaseCost = sum(plan.map((entry) => entry.cost));
    const trend = getDemandTrend();
    const weekdayAverages = getWeekdayAverages();
    const busiestWeekday = [...weekdayAverages].sort((a, b) => b.average - a.average)[0];
    const sales = getRecipeSales(28);
    const topRecipe = [...state.recipes].sort((a, b) => (sales[b.id] || 0) - (sales[a.id] || 0))[0];

    els.forecastMetrics.innerHTML = [
      metricCardHTML({ label: `Expected servings (${horizon}d)`, value: integerFormatter.format(forecast.totalUnits), icon: "◫", foot: `<span>Across <strong>${state.recipes.filter((recipe) => recipe.active).length}</strong> active menu items</span>` }),
      metricCardHTML({ label: "Estimated purchase", value: formatCurrency(purchaseCost), icon: "$", foot: `<span><strong>${plan.length}</strong> ingredients suggested</span>`, color: "var(--warning)", tint: "var(--warning-soft)" }),
      metricCardHTML({ label: "Expected sales", value: formatCurrency(forecast.estimatedRevenue), icon: "↗", foot: "<span>Menu price × predicted servings</span>", color: "var(--success)", tint: "var(--success-soft)" }),
      metricCardHTML({ label: "Forecast confidence", value: forecast.confidence, icon: "✦", foot: `<span>Average <strong>${formatNumber(forecast.averageSamples, 1)}</strong> matching days per estimate</span>`, color: "var(--info)", tint: "var(--info-soft)" })
    ].join("");

    const maxDaily = Math.max(0, ...forecast.days.map((day) => day.totalUnits));
    els.forecastDayGrid.innerHTML = forecast.days.map((day) => {
      const topEntry = Object.entries(day.recipes).sort((a, b) => b[1] - a[1])[0];
      const top = topEntry ? getRecipeById(topEntry[0]) : null;
      return `
        <div class="forecast-day-card ${day.totalUnits === maxDaily && maxDaily > 0 ? "is-busiest" : ""}">
          <span class="forecast-day-name">${DAY_NAMES[day.date.getDay()]}</span>
          <strong class="forecast-day-date">${formatDate(day.date)}</strong>
          <strong class="forecast-day-total">${integerFormatter.format(day.totalUnits)}</strong>
          <span class="forecast-day-caption">expected servings</span>
          <span class="forecast-day-top">${top ? `Top: ${escapeHTML(top.name)}` : "No demand history"}</span>
        </div>
      `;
    }).join("");

    els.forecastConfidenceLabel.textContent = `${forecast.confidence} confidence · ${Math.round(forecast.averageSamples)} matching days`;
    els.businessRhythm.innerHTML = `
      <div class="rhythm-list">
        <div class="rhythm-card"><span>Busiest weekday</span><strong>${escapeHTML(busiestWeekday?.name || "Not enough data")}</strong><small>${busiestWeekday ? `${integerFormatter.format(Math.round(busiestWeekday.average))} average menu units` : "Log more orders"}</small></div>
        <div class="rhythm-card"><span>Customer favorite</span><strong>${escapeHTML(topRecipe?.name || "Not enough data")}</strong><small>${topRecipe ? `${integerFormatter.format(sales[topRecipe.id] || 0)} sold in the last 28 days` : "Log more orders"}</small></div>
        <div class="rhythm-card"><span>Recent direction</span><strong>${trend.direction === "steady" ? "Steady demand" : `${Math.abs(trend.percent)}% ${trend.direction}`}</strong><small>Last 14 days compared with the prior 14</small></div>
        <div class="rhythm-card"><span>Model basis</span><strong>${Math.round(forecast.averageSamples)} matching days</strong><small>Recent weekdays receive more weight</small></div>
      </div>
    `;

    els.purchasePlanTotal.textContent = formatCurrency(purchaseCost);
    els.purchasePlanBody.innerHTML = plan.map((entry) => `
      <tr>
        <td>
          <div class="item-cell">
            <span class="item-cell-icon" aria-hidden="true">${getCategoryIcon(entry.item.category)}</span>
            <span class="item-cell-copy"><strong>${escapeHTML(entry.item.name)}</strong><span>${escapeHTML(entry.item.supplier || entry.item.category)}</span></span>
          </div>
        </td>
        <td>${formatQuantity(entry.item.stock, entry.item.unit)}</td>
        <td>${formatQuantity(entry.expectedUse, entry.item.unit)}</td>
        <td><strong>${formatQuantity(entry.suggestedBuy, entry.item.unit)}</strong></td>
        <td><strong>${formatCurrency(entry.cost)}</strong></td>
        <td><span class="reason-text">${escapeHTML(entry.reason)}</span></td>
      </tr>
    `).join("");
    els.purchasePlanEmpty.hidden = plan.length > 0;
    els.purchasePlanBody.closest(".table-wrap").hidden = plan.length === 0;

    renderCalculator();
  }

  function renderCalculator() {
    const previous = els.calculatorItem.value;
    els.calculatorItem.innerHTML = state.inventory.map((item) => `<option value="${escapeHTML(item.id)}">${escapeHTML(item.name)}</option>`).join("");
    if (state.inventory.some((item) => item.id === previous)) {
      els.calculatorItem.value = previous;
    }
    renderCalculatorResult();
  }

  function renderCalculatorResult() {
    const item = getInventoryById(els.calculatorItem.value) || state.inventory[0];
    const quantity = Math.max(0, Number(els.calculatorQuantity.value) || 0);
    if (!item) {
      els.calculatorUnit.textContent = "units";
      els.calculatorResult.innerHTML = "<span>No inventory items are available.</span>";
      return;
    }

    els.calculatorUnit.textContent = item.unit;
    const cost = quantity * item.unitCost;
    els.calculatorResult.innerHTML = `
      <div><span>Estimated purchase cost</span><strong>${formatCurrency(cost)}</strong></div>
      <small>${formatQuantity(quantity, item.unit)} × ${formatCurrency(item.unitCost)} per ${escapeHTML(item.unit)}</small>
    `;
  }

  function renderAssistant() {
    const prompts = [
      "I bought 5 kg of rice",
      "Change my website color to blue",
      "What does reorder point mean?",
      "What is running low?",
      "How much rice should I buy for next week?",
      "What will 12 kg of chicken cost?",
      "What is my busiest day?",
      "How many Classic Fried Rice servings can I make?",
      "What is my most popular dish?"
    ];

    els.assistantPromptList.innerHTML = prompts.map((prompt) => `
      <button class="prompt-button" type="button" data-assistant-prompt="${escapeHTML(prompt)}">${escapeHTML(prompt)}</button>
    `).join("");

    const low = getLowStockItems();
    const forecast = buildForecast(7);
    const plan = buildPurchasePlan(forecast);
    const topRecipeEntry = Object.entries(getRecipeSales(28)).sort((a, b) => b[1] - a[1])[0];
    const topRecipe = topRecipeEntry ? getRecipeById(topRecipeEntry[0]) : null;
    const busiest = [...getWeekdayAverages()].sort((a, b) => b.average - a.average)[0];

    els.assistantContext.innerHTML = `
      <div class="context-list">
        <div class="context-row"><span>Inventory items</span><strong>${state.inventory.length}</strong></div>
        <div class="context-row"><span>Low stock</span><strong>${low.length}</strong></div>
        <div class="context-row"><span>Active menu items</span><strong>${state.recipes.filter((recipe) => recipe.active).length}</strong></div>
        <div class="context-row"><span>Busiest day</span><strong>${escapeHTML(busiest?.name || "Unknown")}</strong></div>
        <div class="context-row"><span>Top dish</span><strong>${escapeHTML(topRecipe?.name || "Unknown")}</strong></div>
        <div class="context-row"><span>7-day buy estimate</span><strong>${formatCurrency(sum(plan.map((entry) => entry.cost)))}</strong></div>
      </div>
    `;

    renderChatMessages();
  }

  function renderChatMessages() {
    els.chatMessages.innerHTML = "";
    ui.chat.forEach((message) => {
      const wrapper = document.createElement("div");
      wrapper.className = `chat-message ${message.role === "user" ? "is-user" : "is-assistant"}`;

      const avatar = document.createElement("span");
      avatar.className = "chat-message-avatar";
      avatar.setAttribute("aria-hidden", "true");
      avatar.textContent = message.role === "user" ? getInitials(state.settings.businessName).slice(0, 1) : "✦";

      const bubble = document.createElement("div");
      bubble.className = "chat-bubble";
      bubble.textContent = message.text;

      const time = document.createElement("span");
      time.className = "chat-time";
      time.textContent = [message.source, message.time || "Now"].filter(Boolean).join(" / ");
      bubble.appendChild(time);

      wrapper.append(avatar, bubble);
      els.chatMessages.appendChild(wrapper);
    });
    els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
  }

  function renderAll() {
    renderHeader();
    renderNavigationBadge();
    renderDashboard();
    renderInventory();
    renderRecipes();
    renderOrders();
    renderForecast();
    renderAssistant();
    document.dispatchEvent(new CustomEvent("stockwise:render"));
  }

  // ---------------------------------------------------------------------------
  // Navigation and dialogs
  // ---------------------------------------------------------------------------

  function navigateTo(view, focusMain = false) {
    if (!VIEW_META[view]) return;
    ui.activeView = view;

    document.querySelectorAll(".page-view").forEach((section) => {
      const active = section.dataset.view === view;
      section.hidden = !active;
      section.classList.toggle("is-active", active);
    });

    document.querySelectorAll("[data-view-target]").forEach((button) => {
      const active = button.dataset.viewTarget === view;
      button.classList.toggle("is-active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });

    els.pageTitle.textContent = VIEW_META[view].title;
    els.pageEyebrow.textContent = VIEW_META[view].eyebrow;
    document.title = `${VIEW_META[view].title} · StockWise`;
    closeMobileMenu();
    window.scrollTo({ top: 0, behavior: "smooth" });
    if (focusMain) els.mainContent.focus({ preventScroll: true });

    if (view === "forecast") renderForecast();
    if (view === "assistant") renderAssistant();
    document.dispatchEvent(new CustomEvent("stockwise:navigate", { detail: { view } }));
  }

  function openMobileMenu() {
    els.sidebar.classList.add("is-open");
    els.mobileOverlay.hidden = false;
    els.mobileMenuButton.setAttribute("aria-expanded", "true");
    document.body.style.overflow = "hidden";
  }

  function closeMobileMenu() {
    els.sidebar.classList.remove("is-open");
    els.mobileOverlay.hidden = true;
    els.mobileMenuButton.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
  }

  function showDialog(dialog) {
    if (typeof dialog.showModal === "function") dialog.showModal();
    else dialog.setAttribute("open", "");
  }

  function closeDialog(dialog) {
    if (typeof dialog.close === "function") dialog.close();
    else dialog.removeAttribute("open");
  }

  function openInventoryDialog(item = null) {
    els.inventoryDialogTitle.textContent = item ? "Edit inventory item" : "Add inventory item";
    els.inventoryId.value = item?.id || "";
    els.inventoryName.value = item?.name || "";
    els.inventoryCategory.value = item?.category || "";
    els.inventoryUnit.value = item?.unit || "kg";
    els.inventoryStock.value = item?.stock ?? "";
    els.inventoryCost.value = item?.unitCost ?? "";
    els.inventoryReorderPoint.value = item?.reorderPoint ?? "";
    els.inventoryParLevel.value = item?.parLevel ?? "";
    els.inventorySupplier.value = item?.supplier || "";
    showDialog(els.inventoryDialog);
    window.setTimeout(() => els.inventoryName.focus(), 0);
  }

  function openStockAdjustDialog(item) {
    els.stockAdjustItemId.value = item.id;
    els.stockAdjustTitle.textContent = `Adjust ${item.name}`;
    els.stockAdjustCurrent.innerHTML = `Current quantity: <strong>${formatQuantity(item.stock, item.unit)}</strong> · Reorder point: <strong>${formatQuantity(item.reorderPoint, item.unit)}</strong>`;
    els.stockAdjustQuantity.value = item.stock;
    els.stockAdjustQuantity.step = ["each", "pack", "case"].includes(item.unit) ? "1" : "0.001";
    els.stockAdjustUnit.textContent = item.unit;
    els.stockAdjustReason.value = "Manual stock count";
    showDialog(els.stockAdjustDialog);
    window.setTimeout(() => els.stockAdjustQuantity.select(), 0);
  }

  function openRecipeDialog(recipe = null) {
    els.recipeDialogTitle.textContent = recipe ? "Edit menu item" : "Add menu item";
    els.recipeId.value = recipe?.id || "";
    els.recipeName.value = recipe?.name || "";
    els.recipeCategory.value = recipe?.category || "";
    els.recipePrice.value = recipe?.price ?? "";
    els.recipeIcon.value = recipe?.icon || "🍚";
    els.recipeActive.value = String(recipe?.active ?? true);
    ui.recipeIngredientsDraft = recipe
      ? recipe.ingredients.map((ingredient) => ({ ...ingredient }))
      : [{ itemId: "", quantity: 0 }];
    renderRecipeIngredientRows();
    showDialog(els.recipeDialog);
    window.setTimeout(() => els.recipeName.focus(), 0);
  }

  function renderRecipeIngredientRows() {
    if (!ui.recipeIngredientsDraft.length) {
      els.recipeIngredientRows.innerHTML = '<div class="builder-empty">No ingredients yet. Add at least one ingredient per serving.</div>';
      return;
    }

    els.recipeIngredientRows.innerHTML = ui.recipeIngredientsDraft.map((row, index) => {
      const item = getInventoryById(row.itemId);
      const unit = item?.unit || "unit";
      return `
        <div class="ingredient-builder-row" data-ingredient-index="${index}">
          <label>
            <span class="visually-hidden">Ingredient ${index + 1}</span>
            <select data-builder-field="itemId" required>
              <option value="">Choose ingredient</option>
              ${state.inventory.map((inventoryItem) => `<option value="${escapeHTML(inventoryItem.id)}" ${inventoryItem.id === row.itemId ? "selected" : ""}>${escapeHTML(inventoryItem.name)} (${escapeHTML(inventoryItem.unit)})</option>`).join("")}
            </select>
          </label>
          <label class="quantity-input-group ingredient-quantity-wrap">
            <span class="visually-hidden">Quantity per serving</span>
            <input data-builder-field="quantity" type="number" min="0.001" step="0.001" value="${row.quantity || ""}" placeholder="Quantity" required>
            <span>${escapeHTML(unit)}</span>
          </label>
          <button class="row-action is-danger" type="button" data-builder-action="remove" aria-label="Remove ingredient">×</button>
        </div>
      `;
    }).join("");
  }

  // ---------------------------------------------------------------------------
  // Inventory and recipe actions
  // ---------------------------------------------------------------------------

  function handleInventorySubmit(event) {
    event.preventDefault();
    if (event.submitter?.value === "cancel") {
      closeDialog(els.inventoryDialog);
      return;
    }
    if (!els.inventoryForm.reportValidity()) return;

    const itemId = els.inventoryId.value;
    const values = {
      name: els.inventoryName.value.trim(),
      category: els.inventoryCategory.value.trim(),
      unit: els.inventoryUnit.value,
      stock: Math.max(0, Number(els.inventoryStock.value)),
      unitCost: Math.max(0, Number(els.inventoryCost.value)),
      reorderPoint: Math.max(0, Number(els.inventoryReorderPoint.value)),
      parLevel: Math.max(0, Number(els.inventoryParLevel.value)),
      supplier: els.inventorySupplier.value.trim()
    };

    if (values.parLevel < values.reorderPoint) {
      showToast("Check stock targets", "Target stock should be at least as high as the reorder point.", "error");
      return;
    }

    if (itemId) {
      const item = getInventoryById(itemId);
      if (!item) return;
      Object.assign(item, values);
      addActivity("stock", `${values.name} updated`, `Stock settings and cost were edited`);
      showToast("Inventory item updated", `${values.name} was saved.`, "success");
    } else {
      const item = { id: uniqueId("item"), ...values };
      state.inventory.push(item);
      addActivity("stock", `${values.name} added`, `${formatQuantity(values.stock, values.unit)} entered as opening stock`);
      showToast("Inventory item added", `${values.name} is ready to use in recipes.`, "success");
    }

    saveState();
    closeDialog(els.inventoryDialog);
    renderAll();
  }

  function handleStockAdjustSubmit(event) {
    event.preventDefault();
    if (event.submitter?.value === "cancel") {
      closeDialog(els.stockAdjustDialog);
      return;
    }
    if (!els.stockAdjustForm.reportValidity()) return;

    const item = getInventoryById(els.stockAdjustItemId.value);
    if (!item) return;
    const previous = item.stock;
    const next = Math.max(0, Number(els.stockAdjustQuantity.value));
    item.stock = roundTo(next, 4);
    const reason = els.stockAdjustReason.value;
    const change = next - previous;
    addActivity(
      reason === "Supplier delivery" ? "delivery" : "stock",
      `${item.name} stock adjusted`,
      `${change >= 0 ? "+" : ""}${formatQuantity(Math.abs(change), item.unit)} · ${reason}`
    );
    saveState();
    closeDialog(els.stockAdjustDialog);
    renderAll();
    showToast("Stock updated", `${item.name} now has ${formatQuantity(item.stock, item.unit)} on hand.`, "success");
  }

  function deleteInventoryItem(item) {
    const usedIn = state.recipes.filter((recipe) => recipe.ingredients.some((ingredient) => ingredient.itemId === item.id));
    if (usedIn.length) {
      showToast("Item is used in recipes", `Remove ${item.name} from ${usedIn.length} recipe${usedIn.length === 1 ? "" : "s"} before deleting it.`, "error");
      return;
    }
    if (!window.confirm(`Delete ${item.name}? This cannot be undone.`)) return;
    state.inventory = state.inventory.filter((candidate) => candidate.id !== item.id);
    addActivity("stock", `${item.name} deleted`, "Inventory record removed");
    saveState();
    renderAll();
    showToast("Inventory item deleted", `${item.name} was removed.`, "success");
  }

  function handleRecipeSubmit(event) {
    event.preventDefault();
    if (event.submitter?.value === "cancel") {
      closeDialog(els.recipeDialog);
      return;
    }
    if (!els.recipeForm.reportValidity()) return;

    syncRecipeDraftFromDOM();
    const validIngredients = ui.recipeIngredientsDraft.filter((ingredient) => ingredient.itemId && Number(ingredient.quantity) > 0);
    if (!validIngredients.length) {
      showToast("Add an ingredient", "A menu item needs at least one ingredient per serving.", "error");
      return;
    }

    const uniqueItems = new Set(validIngredients.map((ingredient) => ingredient.itemId));
    if (uniqueItems.size !== validIngredients.length) {
      showToast("Duplicate ingredient", "Each inventory item should appear only once in a recipe.", "error");
      return;
    }

    const recipeId = els.recipeId.value;
    const values = {
      name: els.recipeName.value.trim(),
      category: els.recipeCategory.value.trim(),
      price: Math.max(0, Number(els.recipePrice.value)),
      icon: els.recipeIcon.value.trim() || "🍽️",
      active: els.recipeActive.value === "true",
      ingredients: validIngredients.map((ingredient) => ({
        itemId: ingredient.itemId,
        quantity: roundTo(Number(ingredient.quantity), 4)
      }))
    };

    if (recipeId) {
      const recipe = getRecipeById(recipeId);
      if (!recipe) return;
      Object.assign(recipe, values);
      addActivity("recipe", `${values.name} updated`, `${values.ingredients.length} per-serving ingredients saved`);
      showToast("Menu item updated", `${values.name} was saved.`, "success");
    } else {
      state.recipes.push({ id: uniqueId("recipe"), ...values });
      addActivity("recipe", `${values.name} added`, `${values.ingredients.length} ingredients linked`);
      showToast("Menu item added", `${values.name} can now be used in orders.`, "success");
    }

    saveState();
    closeDialog(els.recipeDialog);
    renderAll();
  }

  function syncRecipeDraftFromDOM() {
    const rows = [...els.recipeIngredientRows.querySelectorAll("[data-ingredient-index]")];
    ui.recipeIngredientsDraft = rows.map((row) => ({
      itemId: row.querySelector('[data-builder-field="itemId"]').value,
      quantity: Number(row.querySelector('[data-builder-field="quantity"]').value) || 0
    }));
  }

  function deleteRecipe(recipe) {
    if (!window.confirm(`Delete ${recipe.name}? Historical orders will remain, but this item will no longer be available for new orders.`)) return;
    state.recipes = state.recipes.filter((candidate) => candidate.id !== recipe.id);
    delete ui.orderDraft[recipe.id];
    addActivity("recipe", `${recipe.name} deleted`, "Menu item removed from active planning");
    saveState();
    renderAll();
    showToast("Menu item deleted", `${recipe.name} was removed.`, "success");
  }

  // ---------------------------------------------------------------------------
  // Orders
  // ---------------------------------------------------------------------------

  function adjustDraftQuantity(recipeId, delta) {
    const current = Number(ui.orderDraft[recipeId] || 0);
    const next = Math.max(0, current + delta);
    if (next === 0) delete ui.orderDraft[recipeId];
    else ui.orderDraft[recipeId] = next;
    renderOrders();
  }

  function clearOrderDraft() {
    ui.orderDraft = {};
    els.orderNote.value = "";
    renderOrders();
  }

  function submitOrder() {
    const draft = calculateDraft();
    if (!draft.lines.length || draft.shortages.length) return;

    const now = new Date();
    const order = {
      id: uniqueId("order"),
      date: toDateKey(now),
      createdAt: now.toISOString(),
      note: els.orderNote.value.trim() || "Customer order",
      lines: draft.lines.map((line) => ({
        recipeId: line.recipe.id,
        name: line.recipe.name,
        quantity: line.quantity,
        unitPrice: line.recipe.price,
        unitCost: line.unitCost
      }))
    };

    Object.entries(draft.requirements).forEach(([itemId, required]) => {
      const item = getInventoryById(itemId);
      if (item) item.stock = roundTo(Math.max(0, item.stock - required), 4);
    });

    state.orders.push(order);
    addActivity("order", `${integerFormatter.format(draft.units)} menu units logged`, `${order.note} · ${formatCurrency(draft.revenue)} sales`);
    saveState();

    const low = getLowStockItems();
    ui.orderDraft = {};
    els.orderNote.value = "";
    renderAll();

    const lowMessage = low.length
      ? ` ${low.length} item${low.length === 1 ? " is" : "s are"} now at or below the reorder threshold.`
      : " All remaining stock is above its reorder point.";
    showToast("Order saved and stock deducted", `${formatCurrency(draft.revenue)} recorded.${lowMessage}`, "success");
  }

  // ---------------------------------------------------------------------------
  // Assistant
  // ---------------------------------------------------------------------------

  function resetChat() {
    window.StockWiseAssistant?.cancel(true);
    ui.chat = [{
      role: "assistant",
      text: "Hi! I can explain StockWise, check customer favorites, estimate purchases, and prepare inventory or settings changes for your approval. Try: 'I bought 5 kg of rice' or 'What does reorder point mean?' Built-in tools work immediately. Enable the local WebLLM model for open-ended AI questions.",
      time: "Now"
    }];
    renderChatMessages();
  }

  function addChatMessage(role, text) {
    ui.chat.push({
      role,
      text,
      time: new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(new Date())
    });
    if (ui.chat.length > 60) ui.chat = ui.chat.slice(-60);
    renderChatMessages();
  }

  function findInventoryMention(query) {
    const normalized = query.toLowerCase();
    const direct = [...state.inventory]
      .sort((a, b) => b.name.length - a.name.length)
      .find((item) => normalized.includes(item.name.toLowerCase()));
    if (direct) return direct;

    const aliases = [
      ["rice", "ing-rice"],
      ["water", "ing-water"],
      ["salt", "ing-salt"],
      ["egg", "ing-eggs"],
      ["soy", "ing-soy"],
      ["oil", "ing-oil"],
      ["pea", "ing-peas"],
      ["carrot", "ing-carrots"],
      ["yellow onion", "ing-onions"],
      ["onion", "ing-onions"],
      ["chicken", "ing-chicken"],
      ["shrimp", "ing-shrimp"],
      ["noodle", "ing-noodles"],
      ["garlic", "ing-garlic"],
      ["cabbage", "ing-cabbage"],
      ["scallion", "ing-scallions"],
      ["spring onion", "ing-scallions"],
      ["tofu", "ing-tofu"]
    ];
    const match = aliases.sort((a, b) => b[0].length - a[0].length).find(([alias]) => new RegExp("\\b" + alias + "s?\\b").test(normalized));
    return match ? getInventoryById(match[1]) : null;
  }

  function findRecipeMention(query) {
    const normalized = query.toLowerCase();
    const direct = [...state.recipes]
      .sort((a, b) => b.name.length - a.name.length)
      .find((recipe) => normalized.includes(recipe.name.toLowerCase()));
    if (direct) return direct;

    const aliases = [
      ["classic rice", "recipe-classic-rice"],
      ["fried rice", "recipe-classic-rice"],
      ["chicken rice", "recipe-chicken-rice"],
      ["shrimp rice", "recipe-shrimp-rice"],
      ["vegetable noodles", "recipe-vegetable-noodles"],
      ["veggie noodles", "recipe-vegetable-noodles"],
      ["tofu bowl", "recipe-tofu-bowl"],
      ["egg roll", "recipe-egg-rolls"]
    ];
    const match = aliases.sort((a, b) => b[0].length - a[0].length).find(([alias]) => new RegExp("\\b" + alias + "s?\\b").test(normalized));
    return match ? getRecipeById(match[1]) : null;
  }

  function parseHorizon(query) {
    const normalized = query.toLowerCase();
    const explicitDays = normalized.match(/(?:next\s+)?(\d{1,2})\s*days?/);
    if (explicitDays) return clamp(Number(explicitDays[1]), 1, 60);
    if (normalized.includes("month") || normalized.includes("30 day")) return 30;
    if (normalized.includes("two week") || normalized.includes("2 week") || normalized.includes("fortnight") || normalized.includes("14 day")) return 14;
    if (normalized.includes("tomorrow") || normalized.includes("next day")) return 1;
    return 7;
  }

  function describeHorizon(days) {
    if (days === 1) return "tomorrow";
    if (days === 7) return "the next 7 days";
    if (days === 14) return "the next 14 days";
    if (days === 30) return "the next 30 days";
    return `the next ${days} days`;
  }

  function processAssistantQuery(rawQuery) {
    const query = rawQuery.trim();
    const normalized = query.toLowerCase();
    if (!query) return "Please enter a question about inventory, demand, recipes, or cost.";

    const item = findInventoryMention(query);
    const recipe = findRecipeMention(query);
    const horizon = parseHorizon(query);
    const numberMatch = normalized.match(/(?:^|\s)(\d+(?:\.\d+)?)(?=\s|$|kg|g|l|ml|each|pack|case)/i);
    const numericAmount = numberMatch ? Number(numberMatch[1]) : null;

    if (/^(hi|hello|hey)\b/.test(normalized)) {
      return "Hello! Ask me what is running low, what to buy for a future period, how much a purchase will cost, which day is busiest, or how many servings you can make.";
    }

    if (normalized.includes("help") || normalized.includes("what can you do")) {
      return "I can answer questions like:\n• What is running low?\n• How much rice should I buy for next week?\n• What will 12 kg of chicken cost?\n• What is my busiest day?\n• How many Classic Fried Rice servings can I make?\n• What is my most popular dish?";
    }

    if (/(running low|low stock|reorder|need attention|out of stock)/.test(normalized)) {
      const low = getLowStockItems();
      if (!low.length) return "Nothing is currently at or below its reorder point. All tracked inventory is in the healthy range.";
      const forecast = buildForecast(7);
      const planById = Object.fromEntries(buildPurchasePlan(forecast).map((entry) => [entry.item.id, entry]));
      const lines = low.slice(0, 8).map((lowItem) => {
        const status = getStockStatus(lowItem);
        const plan = planById[lowItem.id];
        const buyText = plan ? ` Suggested 7-day buy: ${formatQuantity(plan.suggestedBuy, lowItem.unit)} (${formatCurrency(plan.cost)}).` : "";
        return `• ${lowItem.name}: ${formatQuantity(lowItem.stock, lowItem.unit)} on hand (${status.label.toLowerCase()}).${buyText}`;
      });
      return `${low.length} item${low.length === 1 ? " is" : "s are"} low or critical:\n${lines.join("\n")}`;
    }

    if (/(busiest|busy day|strongest day|most orders)/.test(normalized)) {
      const busiest = [...getWeekdayAverages()].sort((a, b) => b.average - a.average)[0];
      if (!busiest || busiest.days === 0) return "There is not enough order history to identify a busiest day yet.";
      const second = [...getWeekdayAverages()].sort((a, b) => b.average - a.average)[1];
      return `${busiest.name} is the busiest day, averaging about ${integerFormatter.format(Math.round(busiest.average))} menu units. ${second ? `${second.name} is next at about ${integerFormatter.format(Math.round(second.average))}.` : ""} The estimate uses recent matching weekdays.`;
    }

    if (/(favorite|favourite|most popular|top seller|best seller|popular dish)/.test(normalized)) {
      const sales = getRecipeSales(28);
      const ranking = state.recipes
        .map((candidate) => ({ recipe: candidate, units: sales[candidate.id] || 0 }))
        .sort((a, b) => b.units - a.units);
      if (!ranking.length || ranking[0].units === 0) return "There is not enough recent order history to rank menu items.";
      const first = ranking[0];
      const second = ranking[1];
      return `${first.recipe.name} is the most popular item over the last 28 days with ${integerFormatter.format(first.units)} servings sold.${second ? ` ${second.recipe.name} is second with ${integerFormatter.format(second.units)}.` : ""}`;
    }

    if (recipe && /(how many|can i make|capacity|servings available|portions)/.test(normalized)) {
      const capacity = getRecipeCapacity(recipe);
      if (!capacity.limitingItem) return `${recipe.name} does not have usable ingredient quantities yet.`;
      return `You can make about ${integerFormatter.format(capacity.servings)} servings of ${recipe.name} with current stock. ${capacity.limitingItem.name} is the limiting ingredient.`;
    }

    if (item && /(how much.*have|do i have|in stock|stock of|quantity of|on hand)/.test(normalized)) {
      const status = getStockStatus(item);
      return `${item.name}: ${formatQuantity(item.stock, item.unit)} on hand. Its reorder point is ${formatQuantity(item.reorderPoint, item.unit)}, so the current status is ${status.label.toLowerCase()}. Unit cost is ${formatCurrency(item.unitCost)} per ${item.unit}.`;
    }

    if (item && numericAmount !== null && /(cost|price|spend|how much would|how much will)/.test(normalized) && !/(need|buy for|forecast|recommend)/.test(normalized)) {
      const cost = numericAmount * item.unitCost;
      return `${formatQuantity(numericAmount, item.unit)} of ${item.name} is approximately ${formatCurrency(cost)} at the saved cost of ${formatCurrency(item.unitCost)} per ${item.unit}. Supplier prices and delivery fees are not included.`;
    }

    if (recipe && /(forecast|expect|sell|need|next week|next month|tomorrow)/.test(normalized)) {
      const forecast = buildForecast(horizon);
      const servings = forecast.recipeTotals[recipe.id] || 0;
      const ingredientCost = servings * getRecipeCost(recipe);
      const revenue = servings * recipe.price;
      return `For ${describeHorizon(horizon)}, the model estimates about ${integerFormatter.format(servings)} servings of ${recipe.name}. That represents roughly ${formatCurrency(revenue)} in sales and ${formatCurrency(ingredientCost)} in ingredient cost at current prices.`;
    }

    if (item && /(need|buy|order|purchase|recommend|forecast|stock up)/.test(normalized)) {
      const forecast = buildForecast(horizon);
      const plan = buildPurchasePlan(forecast).find((entry) => entry.item.id === item.id);
      const expectedUse = forecast.ingredientNeeds[item.id] || 0;
      if (!plan) {
        const projectedRemaining = item.stock - expectedUse;
        return `For ${describeHorizon(horizon)}, expected ${item.name} use is about ${formatQuantity(expectedUse, item.unit)}. You currently have ${formatQuantity(item.stock, item.unit)}, so no purchase is suggested. Projected remaining stock is about ${formatQuantity(Math.max(0, projectedRemaining), item.unit)}.`;
      }
      return `For ${describeHorizon(horizon)}, expected ${item.name} use is about ${formatQuantity(expectedUse, item.unit)}. You have ${formatQuantity(item.stock, item.unit)} and the safety level is ${formatQuantity(item.reorderPoint, item.unit)}. Suggested purchase: ${formatQuantity(plan.suggestedBuy, item.unit)}, approximately ${formatCurrency(plan.cost)}.`;
    }

    if (/(forecast|what should i buy|what do i need|purchase plan|next week|next month)/.test(normalized)) {
      const forecast = buildForecast(horizon);
      const plan = buildPurchasePlan(forecast);
      if (!plan.length) return `Current stock covers ${describeHorizon(horizon)} plus saved safety levels. No purchases are suggested.`;
      const total = sum(plan.map((entry) => entry.cost));
      const lines = plan.slice(0, 6).map((entry) => `• ${entry.item.name}: buy ${formatQuantity(entry.suggestedBuy, entry.item.unit)} (${formatCurrency(entry.cost)})`);
      return `For ${describeHorizon(horizon)}, the estimated purchase plan is ${formatCurrency(total)} across ${plan.length} ingredients. Top recommendations:\n${lines.join("\n")}`;
    }

    if (item) {
      const status = getStockStatus(item);
      return `${item.name} has ${formatQuantity(item.stock, item.unit)} on hand and costs ${formatCurrency(item.unitCost)} per ${item.unit}. Its stock status is ${status.label.toLowerCase()}. Ask how much to buy, what a quantity will cost, or how much is in stock.`;
    }

    return "I did not recognize that request yet. Try asking about low stock, a named ingredient, a menu item, purchase cost, busiest day, or a 7-, 14-, or 30-day forecast.";
  }

  function submitChatMessage(message) {
    if (window.StockWiseAssistant) return window.StockWiseAssistant.send(message);
    const text = message.trim();
    if (!text) return;
    addChatMessage("user", text);
    const response = processAssistantQuery(text);
    addChatMessage("assistant", response);
  }

  // ---------------------------------------------------------------------------
  // Settings, backup, and restore
  // ---------------------------------------------------------------------------

  function openDataDialog() {
    els.settingsBusinessName.value = state.settings.businessName;
    showDialog(els.dataDialog);
    window.setTimeout(() => els.settingsBusinessName.focus(), 0);
  }

  function exportData() {
    const data = JSON.stringify(state, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `stockwise-backup-${toDateKey(new Date())}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    showToast("Backup exported", "A JSON copy of the workspace was created.", "success");
  }

  async function importData(file) {
    if (!file) return;
    try {
      if (file.size > 5000000) throw new Error("Please import a JSON backup smaller than 5 MB.");
      const text = await file.text();
      const imported = normalizeState(JSON.parse(text));
      if (!window.confirm(`Replace this workspace with the imported data for “${imported.settings.businessName}”?`)) {
        els.importDataInput.value = "";
        return;
      }
      state = imported;
      ui.forecastHorizon = state.settings.defaultHorizon;
      saveState();
      ui.orderDraft = {};
      resetChat();
      closeDialog(els.dataDialog);
      renderAll();
      showToast("Backup imported", "Inventory, recipes, and orders were restored.", "success");
    } catch (error) {
      console.error(error);
      showToast("Import failed", error.message || "The selected JSON file is not a valid StockWise backup.", "error");
    } finally {
      els.importDataInput.value = "";
    }
  }

  function resetDemoData() {
    if (!window.confirm("Reset everything to the original sample data? Current inventory, recipes, and orders in this browser will be replaced.")) return;
    state = createSampleState();
    saveState();
    ui.orderDraft = {};
    ui.inventorySearch = "";
    ui.inventoryCategory = "all";
    ui.inventoryStatus = "all";
    ui.forecastHorizon = 7;
    els.inventorySearch.value = "";
    els.inventoryStatusFilter.value = "all";
    els.orderNote.value = "";
    resetChat();
    closeDialog(els.dataDialog);
    renderAll();
    navigateTo("dashboard");
    showToast("Sample data restored", "Eight weeks of orders and the original inventory are ready.", "success");
  }

  function handleSettingsSubmit(event) {
    event.preventDefault();
    if (event.submitter?.value === "cancel") {
      closeDialog(els.dataDialog);
      return;
    }
    if (!els.settingsForm.reportValidity()) return;
    const businessName = els.settingsBusinessName.value.trim();
    state.settings.businessName = businessName || "My Business";
    addActivity("system", "Business settings updated", `Workspace renamed to ${state.settings.businessName}`);
    saveState();
    closeDialog(els.dataDialog);
    renderAll();
    showToast("Settings saved", `Workspace name set to ${state.settings.businessName}.`, "success");
  }

  // ---------------------------------------------------------------------------
  // Event wiring
  // ---------------------------------------------------------------------------

  function cacheElements() {
    const ids = [
      "sidebar", "primaryNav", "inventoryAlertBadge", "dataToolsButton", "mobileMenuButton", "mobileOverlay",
      "pageEyebrow", "pageTitle", "mainContent", "businessChip", "businessNameHeader", "businessDateHeader", "globalOrderButton",
      "dashboardSummary", "dashboardMetrics", "demandChart", "demandLegend", "demandTrendMeta", "dashboardAlerts", "purchaseSnapshot", "topRecipes", "recentActivity",
      "inventoryMetrics", "inventorySearch", "inventoryCategoryFilter", "inventoryStatusFilter", "inventoryTableBody", "inventoryEmptyState", "addInventoryButton", "categorySuggestions",
      "recipeSummaryStrip", "recipeGrid", "recipeEmptyState", "addRecipeButton",
      "orderMenuGrid", "currentOrderLines", "orderTotals", "orderItemCount", "orderStockCheck", "orderNote", "submitOrderButton", "clearOrderButton", "orderHistoryBody",
      "forecastHorizon", "forecastMetrics", "forecastDayGrid", "forecastConfidenceLabel", "businessRhythm", "purchasePlanTotal", "purchasePlanBody", "purchasePlanEmpty",
      "calculatorItem", "calculatorQuantity", "calculatorUnit", "calculatorResult",
      "chatMessages", "chatForm", "chatInput", "clearChatButton", "assistantPromptList", "assistantContext",
      "inventoryDialog", "inventoryForm", "inventoryDialogTitle", "inventoryId", "inventoryName", "inventoryCategory", "inventoryUnit", "inventoryStock", "inventoryCost", "inventoryReorderPoint", "inventoryParLevel", "inventorySupplier",
      "stockAdjustDialog", "stockAdjustForm", "stockAdjustItemId", "stockAdjustTitle", "stockAdjustCurrent", "stockAdjustQuantity", "stockAdjustUnit", "stockAdjustReason",
      "recipeDialog", "recipeForm", "recipeDialogTitle", "recipeId", "recipeName", "recipeCategory", "recipePrice", "recipeIcon", "recipeActive", "recipeIngredientRows", "addRecipeIngredientButton",
      "dataDialog", "settingsForm", "settingsBusinessName", "exportDataButton", "importDataInput", "resetDemoButton", "toastRegion"
    ];
    ids.forEach((id) => { els[id] = document.getElementById(id); });
  }

  function wireEvents() {
    document.addEventListener("click", (event) => {
      const navButton = event.target.closest("[data-view-target]");
      if (navButton) {
        navigateTo(navButton.dataset.viewTarget, true);
        return;
      }

      const goButton = event.target.closest("[data-go-view]");
      if (goButton) {
        navigateTo(goButton.dataset.goView, true);
      }
    });

    els.mobileMenuButton.addEventListener("click", () => {
      if (els.sidebar.classList.contains("is-open")) closeMobileMenu();
      else openMobileMenu();
    });
    els.mobileOverlay.addEventListener("click", closeMobileMenu);
    window.addEventListener("resize", () => {
      if (window.innerWidth > 920) closeMobileMenu();
    });

    els.globalOrderButton.addEventListener("click", () => navigateTo("orders", true));
    els.dataToolsButton.addEventListener("click", openDataDialog);

    els.addInventoryButton.addEventListener("click", () => openInventoryDialog());
    els.inventoryForm.addEventListener("submit", handleInventorySubmit);
    els.stockAdjustForm.addEventListener("submit", handleStockAdjustSubmit);

    els.inventorySearch.addEventListener("input", () => {
      ui.inventorySearch = els.inventorySearch.value;
      renderInventory();
    });
    els.inventoryCategoryFilter.addEventListener("change", () => {
      ui.inventoryCategory = els.inventoryCategoryFilter.value;
      renderInventory();
    });
    els.inventoryStatusFilter.addEventListener("change", () => {
      ui.inventoryStatus = els.inventoryStatusFilter.value;
      renderInventory();
    });

    els.inventoryTableBody.addEventListener("click", (event) => {
      const button = event.target.closest("[data-inventory-action]");
      if (!button) return;
      const item = getInventoryById(button.dataset.itemId);
      if (!item) return;
      if (button.dataset.inventoryAction === "adjust") openStockAdjustDialog(item);
      if (button.dataset.inventoryAction === "edit") openInventoryDialog(item);
      if (button.dataset.inventoryAction === "delete") deleteInventoryItem(item);
    });

    els.addRecipeButton.addEventListener("click", () => openRecipeDialog());
    els.recipeForm.addEventListener("submit", handleRecipeSubmit);
    els.addRecipeIngredientButton.addEventListener("click", () => {
      syncRecipeDraftFromDOM();
      ui.recipeIngredientsDraft.push({ itemId: "", quantity: 0 });
      renderRecipeIngredientRows();
    });
    els.recipeIngredientRows.addEventListener("change", (event) => {
      const row = event.target.closest("[data-ingredient-index]");
      if (!row) return;
      const index = Number(row.dataset.ingredientIndex);
      if (event.target.matches('[data-builder-field="itemId"]')) {
        syncRecipeDraftFromDOM();
        renderRecipeIngredientRows();
        const rows = els.recipeIngredientRows.querySelectorAll("[data-ingredient-index]");
        rows[index]?.querySelector('[data-builder-field="quantity"]')?.focus();
      }
    });
    els.recipeIngredientRows.addEventListener("click", (event) => {
      const button = event.target.closest('[data-builder-action="remove"]');
      if (!button) return;
      const row = button.closest("[data-ingredient-index]");
      const index = Number(row.dataset.ingredientIndex);
      syncRecipeDraftFromDOM();
      ui.recipeIngredientsDraft.splice(index, 1);
      renderRecipeIngredientRows();
    });
    els.recipeGrid.addEventListener("click", (event) => {
      const button = event.target.closest("[data-recipe-action]");
      if (!button) return;
      const recipe = getRecipeById(button.dataset.recipeId);
      if (!recipe) return;
      if (button.dataset.recipeAction === "edit") openRecipeDialog(recipe);
      if (button.dataset.recipeAction === "delete") deleteRecipe(recipe);
    });

    els.orderMenuGrid.addEventListener("click", (event) => {
      const button = event.target.closest("[data-order-action]");
      if (!button) return;
      adjustDraftQuantity(button.dataset.recipeId, button.dataset.orderAction === "increase" ? 1 : -1);
    });
    els.clearOrderButton.addEventListener("click", clearOrderDraft);
    els.submitOrderButton.addEventListener("click", submitOrder);

    els.forecastHorizon.addEventListener("change", () => {
      ui.forecastHorizon = Number(els.forecastHorizon.value);
      renderForecast();
    });
    els.calculatorItem.addEventListener("change", renderCalculatorResult);
    els.calculatorQuantity.addEventListener("input", renderCalculatorResult);

    els.chatForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const message = els.chatInput.value;
      els.chatInput.value = "";
      submitChatMessage(message);
    });
    els.clearChatButton.addEventListener("click", resetChat);
    els.assistantPromptList.addEventListener("click", (event) => {
      const button = event.target.closest("[data-assistant-prompt]");
      if (!button) return;
      const prompt = button.dataset.assistantPrompt;
      submitChatMessage(prompt);
    });

    els.settingsForm.addEventListener("submit", handleSettingsSubmit);
    els.exportDataButton.addEventListener("click", exportData);
    els.importDataInput.addEventListener("change", () => importData(els.importDataInput.files?.[0]));
    els.resetDemoButton.addEventListener("click", resetDemoData);

    document.querySelectorAll(".app-dialog").forEach((dialog) => {
      dialog.addEventListener("click", (event) => {
        if (event.target === dialog) closeDialog(dialog);
      });
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && els.sidebar.classList.contains("is-open")) closeMobileMenu();
    });
  }

  function init() {
    cacheElements();
    ui.forecastHorizon = state.settings.defaultHorizon || 7;
    wireEvents();
    resetChat();
    renderAll();
    navigateTo("dashboard");
  }

  window.StockWise = Object.freeze({
    state: () => state,
    ui: () => ui,
    save: saveState,
    render: renderAll,
    navigate: navigateTo,
    toast: showToast,
    activity: addActivity,
    addMessage: addChatMessage,
    renderChat: renderChatMessages,
    answer: processAssistantQuery,
    item: getInventoryById,
    recipe: getRecipeById,
    lowItems: getLowStockItems,
    stockStatus: getStockStatus,
    recipeSales: getRecipeSales,
    weekdays: getWeekdayAverages,
    period: getPeriodStats,
    forecast: buildForecast,
    purchasePlan: buildPurchasePlan,
    recipeCost: getRecipeCost,
    quantity: formatQuantity,
    money: formatCurrency,
    dateKey: toDateKey,
    escape: escapeHTML,
    id: uniqueId,
    backup: exportData,
    dataDialog: openDataDialog,
    reload: () => {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) { state = normalizeState(JSON.parse(raw)); renderAll(); }
      } catch (error) { showToast("Workspace sync failed", error.message, "error"); }
    },
    setHorizon: (days) => { ui.forecastHorizon = days; renderForecast(); },
    storageKey: STORAGE_KEY
  });
  init();
})();
