# Changelog

## 2026-10-17 - workspace version 2

Added Account & email and Appearance & settings pages; editable business and owner names; report email destination; offline MIME email drafts with JSON/CSV attachments; live report preview and clearly labelled preparation history; standalone inventory CSV; six customisable palettes and a custom color picker; reminder and planning preferences.

Added confirmed assistant inventory/count/waste and settings changes, compatible unit conversions, stale-preview rejection, cancellation and confirmable undo; live 28-day customer favorites; app glossary and quantity-based costs. Added genuine lazy WebLLM integration, worker, progress/stop/unload controls and a standard-library local asset installer. Model binaries could not be downloaded in the authoring environment and remain explicitly absent.

Added low/critical stock pop-ups with next-visit snooze, severity-aware acknowledgement, shortage-episode recovery and manual review. Preserved original recipes, order deductions, forecasts, purchase calculations and backups. Retained the storage key and migrated existing workspace data instead of resetting it.

Hardened imported-state normalization, output escaping, email header validation, CSV export, quantity interpretation and storage-failure reporting. Fixed mobile table-heading overflow and intermediate-width forecast controls. Added isolated browser regression tests and dependency-free parser/validation tests.

Known scope limits: no authenticated accounts, cloud synchronization, mailbox sign-in, SMTP delivery, background emailing or AI model training. Open-ended generation needs installed model files and a compatible WebGPU device. Real model startup remains unverified in this handoff.
