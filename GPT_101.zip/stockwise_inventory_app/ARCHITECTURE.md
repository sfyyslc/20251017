# StockWise architecture - version 2

## Runtime boundary

The application is static HTML, CSS and browser JavaScript. `python -m http.server` serves bytes only: it neither processes orders nor holds business records. No framework, npm install, build step, CDN, backend database, remote inference or email service is part of the running app. The user's requested WebLLM runtime is the sole optional third-party application dependency, installed locally by `install_ai.py`.

```
index.html + styles.css + workspace.css
  |
  +-- app.js: original inventory, recipes, orders, forecasts, storage and rendering
  |      +-- frozen StockWise bridge
  |
  +-- assistant-actions.js: pure parsing and action validation
  |
  +-- workspace.js: account, reports, themes, reminders and assistant orchestration
         |
         +-- deterministic tools -> preview -> confirm -> validate -> mutation
         |
         +-- assistant-engine.js (lazy import, only after assets installed)
                 +-- webllm-worker.js
                         +-- vendor/webllm/index.js
                         +-- models/<model-id>/*
```

All dynamic business/user/model strings are escaped or inserted as text. The static CSP limits executable scripts and fetches to local assets, with allowances required for WebAssembly and workers. It does not grant arbitrary model text permission to run scripts.

## Persistent state and migration

The same localStorage key as the original app is retained: `stockwise-inventory-app-v1`. The saved state now has version 2. `normalizeState` applies new defaults while preserving existing inventory, recipes, order history and name.

Main collections: `inventory`, `recipes`, `orders`, `activity`, `settings`, `reminders`, `reportHistory`. Settings include business name, owner name, email, USD currency, theme color, forecast horizon, reminder enabled state and AI autoload preference. Reminders are keyed by ingredient ID. Report snapshots are strings to preserve point-in-time data, but previously embedded report snapshots are nulled when preparing another snapshot.

The normalizer rejects malformed required collections, duplicate IDs and invalid numeric ranges. Imported JSON is limited to 5 MB. Corrupt existing storage is retained in a recovery key when possible, rather than silently overwritten without a recovery copy. Save failures dispatch a visible persistent warning. Browser data remains unencrypted and origin-scoped.

This is not a database transaction system. Confirmation reloads the latest saved state before validation, and cross-tab storage events invalidate pending changes. Simultaneous writes in separate tabs can still race; use one active editing tab and make backups. The bridge is an application interface, not a security boundary against another script that already controls the page.

## Orders, demand and costs

The retained order workflow records recipe serving counts, validates available ingredient stock and deducts the sum of required quantities when the order is committed. Drafts have no stock effect. Recipe quantities refer to one serving in each ingredient's stored unit.

Forecasts estimate future recipe servings from matching historical weekdays with recency weighting, then multiply by recipe ingredient quantities. Suggested purchase is the positive remainder of expected use plus reorder-point buffer minus current stock. It is not merely a fill-to-par rule. Neither the forecast nor favorites ranking requires the LLM.

Favorites use the last 28 calendar days of recorded servings. The report includes total servings and recorded sales; costs and margins exclude overhead and other unrecorded expenses.

## Safe command path

`assistant-actions.js` is a side-effect-free UMD module, available in the browser and testable in Node without dependencies. It recognizes explicit supported requests, resolves overlapping ingredient aliases, converts compatible units and returns a structured proposal or clarification. Unknown package sizes and ambiguous requests cannot silently become numeric stock changes.

A proposal stores the item/setting, current value, next value and relevant metadata. `workspace.js` displays it. On confirmation the current state is reloaded, and `validateAction` checks the whitelist, stale value, unit, cost, name and finite bounds. Only application code performs the write. The most recent assistant change can produce a reversal preview; undo also requires approval.

The generative model never issues executable commands. It is only called after built-in commands, live calculations and help topics fail to answer. Its output is labelled separately. It receives limited live context as untrusted data and is instructed not to claim that it changed state or sent email.

## WebLLM integration and missing assets

The archive intentionally contains no fake `vendor/webllm/index.js` and no dummy weights. Its manifest is `installed: false` because external binary acquisition failed during authoring. The real module import and worker path are present, but cannot run until the installer succeeds.

Pinned runtime: WebLLM 0.2.85. Selected model: Qwen2.5-0.5B-Instruct-q4f32_1-MLC. The compiled model library follows the runtime's supported `v0_2_84/base` record. The model repository's concrete revision is resolved and recorded by the installer.

The installer uses only Python standard-library HTTPS, tar, JSON and hashing facilities. It verifies npm distribution integrity, extracts permitted regular files without general tar extraction, downloads model manifests/tokenizer/shards/library/licenses, checks byte counts and available upstream hashes, and writes a per-file SHA-256 inventory after completion. `--verify` is offline. A successful install has not been exercised here.

`assistant-engine.js` checks secure context, WebGPU adapter availability, manifest paths and served file lengths. It creates a Web Worker and supplies explicit same-origin model and library URLs to WebLLM. Context size is capped at 4096; generation uses streaming with a 360-token limit. Load and generation timeouts, interrupt, unload and user-facing errors preserve the non-AI tools when GPU inference fails. The worker prevents the expensive inference loop from sharing the main UI thread.

The browser may cache model data, but the deployment does not rely on a prewarmed cache: a complete installed folder contains the required files. No service worker or external model fallback is configured. Real installation, CSP/HTTP module loading and GPU inference must still be verified on a compatible target device.

## Email and export design

The report preview is derived from current local state. `.eml` generation produces multipart MIME with UTF-8 subject/body and base64-encoded JSON and CSV attachments, marked unsent. The recipient is a validated saved destination. Draft history records preparation, not delivery. Standalone exports are available for clients that cannot edit `.eml` drafts.

The `mailto:` action prepares a summary only. There are no credentials, OAuth tokens, SMTP calls or sending API requests. Internet delivery requires a separate mail client/service and is outside the app's capabilities. CSV strings beginning with spreadsheet formula markers are neutralized; values are quoted and escaped.

## Reminder state machine

A new visit ID is generated for each page load. A per-visit seen map prevents repeated interruption while changing pages. Persisted records contain choice, severity and visit ID.

- `later`: seen for this visit; eligible on a later document open if still low.
- `ok`: suppress same severity; low-to-critical escalation is eligible.
- Healthy recovery: clears the shortage episode so a later shortage is new.

A single native modal consolidates due items. Other open dialogs defer it. Escape/backdrop dismissal uses snooze semantics. Disabling reminders stops automatic pop-ups, not dashboard indicators or explicit manual review.

## Responsive interface and accessibility

The app includes eight views, fluid grids, an off-canvas mobile sidebar, independently scrollable tables, native form validation, labels and accessible dialog names. The hidden mobile sidebar is inert so its controls do not trap keyboard navigation. Custom palettes derive contrast-aware foreground colors rather than blindly using a pale accent for text. Existing reduced-motion CSS is retained.

## Validation boundaries

The included tests cover command safety, real DOM interactions, exports, reminder transitions, persistence adapters and 320/390/768/1440 CSS layouts. The authoring browser blocked all direct URL navigation. Therefore browser checks injected the actual local application source into an isolated blank document with explicit storage/fetch/download adapters, and removed CSP solely in that test document. No production CSP or browser policies were modified.

This harness does not establish HTTP-origin storage behavior, native email-client behavior, module/CSP compatibility, first offline model load or hardware inference. Consult `TEST_REPORT.md` for exact executed checks and remaining device-level acceptance tests.
