/* Pure, testable command parser. No model output ever executes as JavaScript. */
(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.StockWiseActions = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";
  const THEMES = [
    { name: "Forest", color: "#195f3e", words: ["forest", "green"] },
    { name: "Ocean", color: "#245cb5", words: ["ocean", "blue", "navy"] },
    { name: "Plum", color: "#7543a0", words: ["plum", "purple", "violet"] },
    { name: "Terracotta", color: "#b04a2f", words: ["terracotta", "orange", "rust"] },
    { name: "Rose", color: "#a43567", words: ["rose", "pink", "red"] },
    { name: "Teal", color: "#08766e", words: ["teal", "turquoise"] }
  ];
  const ALIASES = {
    "ing-rice": ["rice", "jasmine rice"], "ing-water": ["water"], "ing-salt": ["salt"],
    "ing-eggs": ["egg", "eggs"], "ing-soy": ["soy sauce", "soy"], "ing-oil": ["oil", "vegetable oil"],
    "ing-peas": ["pea", "peas"], "ing-carrots": ["carrot", "carrots"],
    "ing-onions": ["onion", "onions", "yellow onion", "yellow onions"],
    "ing-chicken": ["chicken", "chicken breast"], "ing-shrimp": ["shrimp", "prawns"],
    "ing-noodles": ["noodle", "noodles"], "ing-garlic": ["garlic"], "ing-cabbage": ["cabbage"],
    "ing-scallions": ["spring onion", "spring onions", "scallion", "scallions", "green onions"],
    "ing-tofu": ["tofu"]
  };
  const units = {
    kg: ["mass", 1], kilogram: ["mass", 1], kilograms: ["mass", 1], kilo: ["mass", 1], kilos: ["mass", 1],
    g: ["mass", .001], gram: ["mass", .001], grams: ["mass", .001],
    lb: ["mass", .45359237], lbs: ["mass", .45359237], pound: ["mass", .45359237], pounds: ["mass", .45359237],
    oz: ["mass", .028349523125], ounce: ["mass", .028349523125], ounces: ["mass", .028349523125],
    l: ["volume", 1], liter: ["volume", 1], liters: ["volume", 1], litre: ["volume", 1], litres: ["volume", 1],
    ml: ["volume", .001], milliliter: ["volume", .001], milliliters: ["volume", .001], millilitre: ["volume", .001], millilitres: ["volume", .001],
    each: ["count", 1], unit: ["count", 1], units: ["count", 1], piece: ["count", 1], pieces: ["count", 1], dozen: ["count", 12], dozens: ["count", 12],
    pack: ["pack", 1], packs: ["pack", 1], case: ["case", 1], cases: ["case", 1]
  };
  const numberPattern = "[-+]?(?:\\d+(?:,\\d{3})*(?:\\.\\d+)?|\\.\\d+)";
  const unitPattern = Object.keys(units).sort((a,b) => b.length-a.length).join("|");
  const amountPattern = new RegExp("(?:^|[^\\w.])(" + numberPattern + ")\\s*(" + unitPattern + ")?\\b", "i");
  const escapeRegExp = text => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const round = number => Math.round((number + Number.EPSILON) * 1e6) / 1e6;
  const validEmail = email => typeof email === "string" && email.length <= 254 && /^[^\s@<>;,\r\n]+@[^\s@<>;,\r\n]+\.[^\s@<>;,\r\n]+$/.test(email);
  const trimValue = value => value.trim().replace(/[.!?]$/, "").replace(/^["']|["']$/g, "").trim();
  const error = message => ({ kind: "clarify", message });
  const setting = (state, key, value, label) => ({ kind: "setting", key, value, before: state.settings[key], label });
  function wordsToNumbers(text) {
    const map = {one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,twenty:20,thirty:30,fifty:50,hundred:100};
    return text.replace(/\bhalf (?:a )?(?:kilo|kilogram)\b/gi, "0.5 kg").replace(/\ba dozen\b/gi,"1 dozen").replace(/\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|twenty|thirty|fifty|hundred)\b/gi, word => map[word.toLowerCase()]);
  }
  function matchItems(query, inventory) {
    const hits = [];
    inventory.forEach(item => {
      [item.name, ...(ALIASES[item.id] || [])].forEach(alias => {
        const re = new RegExp("\\b" + escapeRegExp(alias.toLowerCase()) + "\\b", "g");
        for (const match of query.toLowerCase().matchAll(re)) hits.push({ item, start:match.index, end:match.index+match[0].length });
      });
    });
    // Prefer "spring onions" to the overlapping "onions" alias.
    const keep = hits.filter(hit => !hits.some(other => other.start <= hit.start && other.end >= hit.end && other.end-other.start > hit.end-hit.start));
    return [...new Map(keep.map(hit => [hit.item.id,hit.item])).values()];
  }
  function readAmount(query, item, allowZero = false) {
    const input = wordsToNumbers(query);
    const match = input.match(amountPattern);
    if (!match) return error(`How much ${item.name} did you mean? Include a quantity and ${item.unit}, for example: "add 5 ${item.unit} of ${item.name}".`);
    const number = Number(match[1].replace(/,/g,""));
    if (!Number.isFinite(number) || number < 0 || (!allowZero && number === 0) || number > 1000000) return error("Use a positive quantity of at most 1,000,000. A stock count may be set to zero; deliveries must be greater than zero.");
    let unit = (match[2] || "").toLowerCase();
    if (!unit) {
      const nextWord = input.slice(match.index+match[0].length).trim().match(/^([a-z]+)/i)?.[1]?.toLowerCase();
      const itemWords = [item.name, ...(ALIASES[item.id] || [])].map(name => name.toLowerCase().split(/\s+/)[0]);
      if (nextWord && !["of", "more", ...itemWords].includes(nextWord)) return error(`I do not know the package size or measurement "${nextWord}" for ${item.name}. Please give its actual quantity in ${item.unit}; I will not guess the contents of boxes or other packages.`);
      if (["each","pack","case"].includes(item.unit)) unit = item.unit;
      else return error(`Please include a measurement unit. ${item.name} is tracked in ${item.unit}. For example: "add 5 ${item.unit} of ${item.name}".`);
    }
    const from = units[unit], to = units[item.unit.toLowerCase()];
    if (!from || !to || from[0] !== to[0]) return error(`I cannot safely convert ${unit} to ${item.unit} for ${item.name}. Please give the quantity in ${item.unit}; I will not guess package sizes or weight-to-volume conversions.`);
    const converted = round(number * from[1] / to[1]);
    if ((!allowZero && converted <= 0) || converted > 1000000) return error("The converted quantity is outside the supported range.");
    if (["each","pack","case"].includes(item.unit) && !Number.isInteger(converted)) return error(`Use a whole number of ${item.unit} for ${item.name}.`);
    return { amount:converted, inputAmount:number, inputUnit:unit, unit:item.unit };
  }
  function parseIntent(raw, state) {
    const q = String(raw || "").trim();
    if (!q) return null;
    const low = q.toLowerCase();
    // Negation, examples, hypotheticals, and how-to questions cannot authorize a write.
    if (/\b(don't|do not|didn't|did not|haven't|have not|never|not yet|no longer)\b/.test(low) || /^(what if|suppose|imagine|how (do|can|would|should|to)|why |explain |what does|what is|show me how|for example)/.test(low)) return null;
    const lead = q.replace(/^(?:please\s+)?(?:(?:can|could|would|will) you\s+|i (?:want|need) you to\s+|please\s+)?/i, "").replace(/^please\s+/i, "");
    let m;
    if ((m = lead.match(/^(?:set|change|update|link|connect|save)\s+(?:(?:my|the|our)\s+)?(?:(?:report|backup|account)\s+)?email(?: address)?\s+(?:(?:to|as|is)\s+)?(.+)$/i))) {
      const email = trimValue(m[1]);
      return validEmail(email) ? setting(state,"email",email,"Report email") : error("Please provide one valid email address, such as owner@example.com. This saves a destination; it does not sign in to a mailbox.");
    }
    if (/^(?:remove|clear|disconnect)\s+(?:my |the )?email(?: address)?[.!]?$/i.test(lead)) return setting(state,"email","","Report email");
    if ((m = lead.match(/^(?:rename|set|change|update)\s+(?:(?:my|the|our)\s+)?(?:business|company|workspace)(?: name)?\s+(?:to|as)\s+(.+)$/i)) || (m = lead.match(/^(?:my|our) business name is\s+(.+)$/i))) {
      const value = trimValue(m[1]);
      return value && value.length <= 60 ? setting(state,"businessName",value,"Business name") : error("Use a business name between 1 and 60 characters.");
    }
    if ((m = lead.match(/^(?:set|change|update)\s+(?:my |the )?(?:owner name|name)\s+to\s+(.+)$/i))) {
      const value = trimValue(m[1]);
      return value && value.length <= 60 ? setting(state,"ownerName",value,"Owner name") : error("Use an owner name between 1 and 60 characters.");
    }
    if (/^(?:change|set|update|make|switch)\b/i.test(lead) && /\b(theme|colou?r|website|site)\b/i.test(lead)) {
      const hex = lead.match(/#[0-9a-f]{6}\b/i);
      const theme = THEMES.find(candidate => candidate.words.some(word => new RegExp("\\b"+word+"\\b","i").test(lead)));
      return hex || theme ? setting(state,"themeColor",hex ? hex[0].toLowerCase() : theme.color,"Website color") : error("Choose forest, blue, purple, orange, rose, teal, or a six-digit hex color, such as #245cb5.");
    }
    if (/\b(reminder|reminders|alerts|pop.?ups)\b/i.test(lead) && /\b(enable|disable|turn|switch|set)\b/i.test(lead)) {
      const off = /\b(off|disable|disabled)\b/i.test(lead), on = /\b(on|enable|enabled)\b/i.test(lead);
      if (on === off) return error("Should I turn low-stock reminders on or off?");
      return setting(state,"remindersEnabled",on,"Low-stock reminders");
    }
    if (/\b(auto|automatic|automatically)\b/i.test(lead) && /\b(ai|assistant|model)\b/i.test(lead) && /\b(enable|disable|turn|switch|set)\b/i.test(lead)) {
      const off = /\b(off|disable|disabled)\b/i.test(lead), on = /\b(on|enable|enabled)\b/i.test(lead);
      if (on === off) return error("Should I turn automatic AI loading on or off?");
      return setting(state,"autoLoadAI",on,"Automatic AI loading");
    }
    if (/^(?:set|change|update)\b/i.test(lead) && /\b(forecast|planning)\b/i.test(lead)) {
      const number = wordsToNumbers(lead).match(/\b(\d+)\s*days?\b/i);
      const days = number ? Number(number[1]) : 0;
      return [7,14,30].includes(days) ? setting(state,"defaultHorizon",days,"Default forecast window") : error("Choose a default forecast window of 7, 14, or 30 days.");
    }
    const stockVerb = /^(?:(?:i|we)(?:'ve| have)?\s+(?:just\s+)?(?:bought|purchased|received|restocked)|(?:add|restock|receive|record a delivery|set|update|change|remove|discard|subtract|wasted)\b)/i.test(lead);
    if (!stockVerb) return null;
    const matches = matchItems(lead, state.inventory);
    if (!matches.length) return error("Which ingredient should I update? Use its inventory name and a quantity, for example: 'I bought 5 kg of rice'. For account changes, name the setting: business name, email, color, reminders, or forecast window.");
    if (matches.length > 1) return error("Please update one ingredient at a time so each quantity has a clear match. For example: 'add 5 kg of rice', then 'add 24 eggs'. Nothing has been changed.");
    const item = matches[0];
    // Do not silently reinterpret customer orders as purchases of raw ingredients.
    if (state.recipes.some(recipe => lead.toLowerCase().includes(recipe.name.toLowerCase()))) return error("That is a menu item. Record customer sales in Log orders so all recipe ingredients are deducted together. For a delivery, name the raw ingredient instead.");
    const allNumbers = wordsToNumbers(lead).match(/[-+]?\d+(?:,\d{3})*(?:\.\d+)?/g) || [];
    if (allNumbers.length > 1) return error("I found more than one number. Please give one quantity per request. Set costs or reorder points separately so I do not confuse a price with a delivery quantity.");
    let field = "stock";
    if (/\b(reorder point|reorder level|minimum stock)\b/i.test(lead)) field = "reorderPoint";
    else if (/\b(par level|target stock|target level)\b/i.test(lead)) field = "parLevel";
    else if (/\b(unit cost|cost per|price per)\b/i.test(lead)) field = "unitCost";
    let mode = /^(set|update|change)\b/i.test(lead) ? "set" : /^(remove|discard|subtract|wasted)\b/i.test(lead) ? "subtract" : "add";
    if (field !== "stock") mode = "set";
    let amount;
    if (field === "unitCost") {
      const n = wordsToNumbers(lead).match(new RegExp(numberPattern));
      amount = n ? Number(n[0].replace(/,/g,"")) : NaN;
      if (!Number.isFinite(amount) || amount < 0 || amount > 1000000) return error(`Give a nonnegative unit cost in dollars per ${item.unit}.`);
      const per = lead.match(new RegExp("\\bper\\s+(" + unitPattern + ")\\b", "i"));
      if (per && per[1].toLowerCase() !== item.unit.toLowerCase()) return error(`Set the price per ${item.unit}, the unit used for ${item.name}.`);
    } else {
      const result = readAmount(lead,item,mode === "set");
      if (result.kind === "clarify") return result;
      amount = result.amount;
    }
    const before = item[field];
    const after = round(mode === "set" ? amount : mode === "subtract" ? before-amount : before+amount);
    if (after < 0) return error(`You only have ${before} ${item.unit} of ${item.name}. I cannot remove ${amount} ${item.unit} or create negative stock.`);
    if (after > 1000000) return error("The resulting value exceeds 1,000,000. Please use the Inventory page to review your units.");
    return {kind:"inventory",itemId:item.id,field,mode,amount,unit:item.unit,before,after,itemName:item.name,unitCost:item.unitCost};
  }
  function validateAction(action,state) {
    if (!action || !["setting","inventory"].includes(action.kind)) return "There is no valid change to apply.";
    if (action.kind === "setting") {
      const allowed = ["businessName","ownerName","email","themeColor","defaultHorizon","remindersEnabled","autoLoadAI"];
      if (!allowed.includes(action.key)) return "This setting cannot be changed through the assistant.";
      if (state.settings[action.key] !== action.before) return "This setting changed after the preview. Ask again to review the latest value.";
      if (action.key === "email" && action.value !== "" && !validEmail(action.value)) return "The email address is invalid.";
      if (["businessName","ownerName"].includes(action.key) && (typeof action.value !== "string" || !action.value.trim() || action.value.length > 60)) return "The name is invalid.";
      if (action.key === "themeColor" && !/^#[0-9a-f]{6}$/i.test(action.value)) return "The color is invalid.";
      if (action.key === "defaultHorizon" && ![7,14,30].includes(action.value)) return "The forecast window is invalid.";
      if (["remindersEnabled","autoLoadAI"].includes(action.key) && typeof action.value !== "boolean") return "The preference is invalid.";
    } else {
      const item = state.inventory.find(candidate => candidate.id === action.itemId);
      if (!item || !["stock","reorderPoint","parLevel","unitCost"].includes(action.field)) return "The ingredient is no longer available.";
      if (item[action.field] !== action.before || item.unit !== action.unit || item.unitCost !== action.unitCost || item.name !== action.itemName) return "This ingredient changed after the preview. Ask again so I can use its latest values.";
      if (!Number.isFinite(action.after) || action.after < 0 || action.after > 1000000) return "The proposed quantity is invalid.";
    }
    return null;
  }
  return Object.freeze({parseIntent,validateAction,readAmount,matchItems,validEmail,THEMES});
});
