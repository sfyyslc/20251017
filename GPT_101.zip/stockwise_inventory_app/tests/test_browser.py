"""Optional Playwright regression checks for the app's real DOM and local logic.
Run: python tests/test_browser.py
Requires Playwright + Chromium as developer-only tools; neither is needed by the app.
Set CHROMIUM_PATH to an existing Chromium executable; defaults to /usr/bin/chromium.
"""
import os
import json
import math
import time
START=time.monotonic()
from pathlib import Path
from email import policy
from email.parser import BytesParser
from playwright.sync_api import sync_playwright
from browser_harness import mount

passed = 0
all_errors = []
OUT = Path(os.environ.get('STOCKWISE_TEST_OUTPUT', 'test-output'))
OUT.mkdir(parents=True, exist_ok=True)

def check(value, description):
    global passed
    if not value:
        raise AssertionError(description)
    passed += 1
    print(f'PASS {passed} [{time.monotonic()-START:.1f}s]: {description}', flush=True)

def navigate(page, view):
    page.evaluate('(v)=>StockWise.navigate(v)', view)
    page.wait_for_timeout(220)

def chat(page, message):
    navigate(page, 'assistant')
    page.fill('#chatInput', message)
    page.click('#chatSendButton')
    page.wait_for_timeout(60)
    return page.evaluate('StockWise.ui().chat.at(-1).text')

def stock(page, item='ing-rice'):
    return page.evaluate('(id)=>StockWise.item(id).stock', item)

def settings(page):
    return page.evaluate('StockWise.state().settings')

def rem_open(page):
    return page.locator('#restockDialog').is_visible()

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'), headless=True, args=['--no-sandbox'])
    page, errors = mount(browser)
    page.set_default_timeout(8000)
    all_errors.append(errors)
    initial = page.evaluate('StockWise.state()')
    check(len(initial['inventory'])==16 and len(initial['recipes'])==6 and len(initial['orders'])==112, 'Realistic sample inventory, recipes and historical order batches')
    check(rem_open(page) and page.locator('.restock-item').count()==4, 'Initial low-stock dialog contains four sample ingredients')
    page.click('#remindLaterButton')
    baseline = page.evaluate('__store')
    navigate(page, 'inventory')
    page.evaluate('StockWise.render()')
    page.wait_for_timeout(500)
    check(not rem_open(page), 'Snooze does not reappear within the same visit')
    page2, errors2 = mount(browser, baseline)
    all_errors.append(errors2)
    check(rem_open(page2), 'Snoozed items reappear when the workspace is opened again')
    page2.click('#acknowledgeRestockButton')
    acknowledged = page2.evaluate('__store')
    page2.close()
    page3, errors3 = mount(browser, acknowledged)
    all_errors.append(errors3)
    check(not rem_open(page3), 'OK acknowledgement persists across visits for the same severity')
    # Clear the shortage episode, then reduce stock immediately, before a timer fires.
    low_id = page3.evaluate('StockWise.lowItems()[0].id')
    page3.evaluate('(id)=>{const x=StockWise.item(id);x.stock=x.parLevel+10;StockWise.save();StockWise.render();x.stock=x.reorderPoint;StockWise.save();StockWise.render();}',low_id)
    page3.wait_for_timeout(450)
    check(rem_open(page3), 'A new low-stock episode is detected after restocking')
    page3.click('#acknowledgeRestockButton')
    page3.evaluate('(id)=>{StockWise.item(id).stock=0;StockWise.save();StockWise.render();}',low_id)
    page3.wait_for_timeout(450)
    check(rem_open(page3), 'Low-to-critical escalation triggers a new reminder')
    page3.click('#remindLaterButton')
    page3.close()
    page.bring_to_front()

    before=stock(page)
    text=chat(page,'I bought 5 kg of rice')
    check(page.locator('#assistantActionReview').is_visible() and stock(page)==before, 'Delivery preview leaves stock unchanged until confirmed')
    page.click('#applyAssistantAction')
    check(stock(page)==before+5, 'Confirmed delivery increases stock by the requested amount')
    chat(page,'undo')
    check(stock(page)==before+5 and page.locator('#assistantActionReview').is_visible(), 'Undo also requires confirmation')
    page.click('#applyAssistantAction')
    check(stock(page)==before, 'Confirmed undo restores original stock')
    chat(page,'I bought 500 g of rice')
    page.click('#applyAssistantAction')
    check(stock(page)==before+0.5, 'Grams are converted to stored kilograms')
    chat(page,'set rice stock to 20 kg')
    page.click('#cancelAssistantAction')
    check(stock(page)==before+0.5, 'Cancel leaves inventory unchanged')
    chat(page,'I bought 2 kg of rice')
    page.evaluate('StockWise.item("ing-rice").stock+=1;StockWise.save();')
    page.click('#applyAssistantAction')
    check(stock(page)==before+1.5 and 'Nothing was changed' in page.evaluate('StockWise.ui().chat.at(-1).text'), 'Stale preview is rejected after intervening stock change')
    count=stock(page)
    text=chat(page,'I did not buy 3 kg of rice')
    check(not page.locator('#assistantActionReview').is_visible() and stock(page)==count, 'Negated purchase cannot alter stock')
    text=chat(page,'I bought 2 boxes of eggs')
    check(not page.locator('#assistantActionReview').is_visible() and ('box' in text.lower() or 'unit' in text.lower()), 'Unspecified package quantities request clarification')
    text=chat(page,'What is our favorite dish?')
    check('servings' in text and 'last 28' in text and 'current favorite' in text, 'Favorites answer uses recorded servings from live sales history')
    text=chat(page,'What does reorder point mean?')
    check('stock' in text.lower() and 'local AI model' not in text, 'App glossary works without model files')
    cost=page.evaluate('StockWise.item("ing-rice").unitCost')
    text=chat(page,'How much does 500 g of rice cost?')
    check(f'${cost*0.5:.2f}' in text, 'Built-in cost calculator uses exact converted quantity and saved unit cost')
    text=chat(page,'Write a cheerful poem about autumn')
    check('needs the local AI model' in text, 'Missing generative model is disclosed instead of pretending to answer')
    check('Model setup required' in page.locator('#aiStatusBadge').inner_text(), 'Model status accurately reflects absent assets')
    page.click('#loadAIButton')
    page.wait_for_timeout(150)
    check(page.locator('#aiSetupDetails').evaluate('(e)=>e.open'), 'Missing model setup controls show installation instructions')
    chat(page,'Set my business name to Maple Street Kitchen')
    page.click('#applyAssistantAction')
    check(settings(page)['businessName']=='Maple Street Kitchen', 'Assistant can rename business after confirmation')
    chat(page,'Change my website color to ocean')
    page.click('#applyAssistantAction')
    check(settings(page)['themeColor']!='#195f3e', 'Assistant can change website color')
    chat(page,'Set my email to owner@maplestreet.test')
    page.click('#applyAssistantAction')
    check(settings(page)['email']=='owner@maplestreet.test', 'Assistant saves report email destination')
    chat(page,'Set my default forecast to 14 days')
    page.click('#applyAssistantAction')
    check(settings(page)['defaultHorizon']==14 and page.locator('#forecastHorizon').input_value()=='14', 'Forecast preference immediately updates current planning horizon')

    navigate(page,'orders')
    recipe=page.evaluate('StockWise.state().recipes.find(r=>r.active)')
    old_order_count=page.evaluate('StockWise.state().orders.length')
    old_stock=page.evaluate('Object.fromEntries(StockWise.state().inventory.map(i=>[i.id,i.stock]))')
    page.click(f'[data-order-action="increase"][data-recipe-id="{recipe["id"]}"]')
    check(page.locator('#submitOrderButton').is_enabled(), 'Existing order workflow enables a valid order')
    page.click('#submitOrderButton')
    check(page.evaluate('StockWise.state().orders.length')==old_order_count+1, 'Order saves exactly one additional record')
    new_stock=page.evaluate('Object.fromEntries(StockWise.state().inventory.map(i=>[i.id,i.stock]))')
    check(all(math.isclose(new_stock[i['itemId']],old_stock[i['itemId']]-i['quantity'],abs_tol=0.0011) for i in recipe['ingredients']), 'Order automatically deducts each recipe ingredient')
    page.evaluate('(id)=>{StockWise.item(id).stock=0;StockWise.save();StockWise.render();}',recipe['ingredients'][0]['itemId'])
    page.wait_for_timeout(450)
    if rem_open(page):page.click('#remindLaterButton')
    page.click(f'[data-order-action="increase"][data-recipe-id="{recipe["id"]}"]')
    check(page.locator('#submitOrderButton').is_disabled(), 'Order cannot be saved with insufficient ingredients')
    page.click('#clearOrderButton')
    page.evaluate('(data)=>{for(const x of StockWise.state().inventory)x.stock=data[x.id];StockWise.save();StockWise.render();}',new_stock)

    navigate(page,'account')
    page.fill('#accountBusinessName','Caf\u00e9 Maple & Co.')
    page.fill('#accountOwnerName','Morgan L\u00e9e')
    page.fill('#accountEmail','reports@maplestreet.test')
    page.click('#accountProfileForm button[type="submit"]')
    check(settings(page)['businessName']=='Caf\u00e9 Maple & Co.' and 'Caf\u00e9' in page.locator('#accountBusinessTitle').inner_text(), 'Profile form saves Unicode business details across the interface')
    page.click('#prepareEmailButton')
    page.wait_for_timeout(100)
    download=page.evaluate('__downloads.at(-1)')
    mime=BytesParser(policy=policy.default).parsebytes(download['text'].encode('utf-8'))
    check(download['name'].endswith('.eml') and mime['To']=='reports@maplestreet.test' and mime['X-Unsent']=='1', 'Email download is an unsent MIME draft with the saved recipient')
    check('Caf\u00e9' in str(mime['Subject']), 'Email subject preserves Unicode business name')
    attachments=list(mime.iter_attachments())
    check(len(attachments)==2 and {x.get_content_type() for x in attachments}=={'application/json','text/csv'}, 'Email draft includes real JSON backup and CSV inventory attachments')
    backup=json.loads(next(x.get_payload(decode=True).decode('utf-8') for x in attachments if x.get_content_type()=='application/json'))
    check(backup['settings']['businessName']=='Caf\u00e9 Maple & Co.' and len(backup['inventory'])==16, 'Backup attachment contains the current workspace state')
    check(all(r['snapshot'] is None for r in backup['reportHistory']), 'Export strips recursively embedded report snapshots')
    check(page.evaluate('StockWise.state().reportHistory[0].status')!='sent', 'Prepared report is not mislabeled as delivered email')
    page.click('#downloadCSVButton')
    page.wait_for_timeout(70)
    check('Jasmine Rice' in page.evaluate('__downloads.at(-1).text'), 'Standalone inventory CSV export works')
    page.click('#accountBackupButton')
    page.wait_for_timeout(70)
    json_export=page.evaluate('__downloads.at(-1)')
    check(json_export['name'].endswith('.json') and len(json.loads(json_export['text'])['inventory'])==16, 'Standalone JSON backup works')

    navigate(page,'preferences')
    page.fill('#customThemeHex','#ffffff')
    page.click('#applyHexButton')
    ink=page.evaluate('getComputedStyle(document.documentElement).getPropertyValue("--theme-ink").trim()')
    check(settings(page)['themeColor']=='#ffffff' and ink!='#ffffff', 'Arbitrary pale custom theme retains a separate legible text accent')
    page.click('[data-theme-color="#245cb5"]')
    page.select_option('#defaultHorizonInput','30')
    check(settings(page)['defaultHorizon']==30, 'Forecast setting saves from preferences form')
    page.uncheck('#remindersEnabledInput')
    check(settings(page)['remindersEnabled'] is False, 'Automatic reminders can be disabled')
    page.click('#reviewRemindersButton')
    check(rem_open(page), 'Manual reminder review works even with automatic reminders off')
    page.click('#acknowledgeRestockButton')
    page.check('#remindersEnabledInput')
    # Version-one data migration, using the original storage key.
    v1=json.loads(json.dumps(initial));v1['version']=1
    v1['settings']={'businessName':'Existing Shop','currency':'USD'}
    v1.pop('reminders',None);v1.pop('reportHistory',None)
    migrated, errs=mount(browser,{'stockwise-inventory-app-v1':json.dumps(v1)})
    all_errors.append(errs)
    check(settings(migrated)['businessName']=='Existing Shop' and settings(migrated)['themeColor']=='#195f3e' and len(migrated.evaluate('StockWise.state().orders'))==112, 'Version-one migration retains existing name and orders while adding preferences')
    migrated.close()
    persisted=page.evaluate('__store')
    reopened, errs=mount(browser,persisted)
    all_errors.append(errs)
    check(settings(reopened)['businessName']=='Caf\u00e9 Maple & Co.' and settings(reopened)['defaultHorizon']==30 and len(reopened.evaluate('StockWise.state().reportHistory'))>1, 'Profile, preferences and draft history survive simulated reopening')
    if rem_open(reopened):reopened.click('#acknowledgeRestockButton')
    reopened.close()
    page.bring_to_front()

    # Check all views at four breakpoints. Tables may scroll inside their own wrappers.
    for width in [320,390,768,1440]:
        page.set_viewport_size({'width':width,'height':900})
        page.wait_for_timeout(260)
        for view in ['dashboard','inventory','recipes','orders','forecast','assistant','account','preferences']:
            navigate(page,view)
            dimensions=page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})')
            check(dimensions['scroll']<=dimensions['width']+1,f'{view} fits {width}px viewport without page overflow')
    check(all(not errors for errors in all_errors), 'No uncaught JavaScript errors across isolated browser scenarios')
    check(set(page.evaluate('__requests'))=={'vendor/manifest.json'}, 'Core interactions make no unexpected external fetch requests')
    # Playwright context manager owns browser-process teardown.
print(f'\n{passed} isolated browser checks passed.',flush=True)
