"""Additional isolated browser checks. Same limitations as browser_harness.py."""
import json
import os
from playwright.sync_api import sync_playwright
from browser_harness import mount
count=0
def check(value,message):
    global count
    assert value,message
    count+=1
    print(f'PASS {count}: {message}',flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page,errors=mount(b,width=390,height=844)
    page.set_default_timeout(6000)
    page.click('#remindLaterButton')
    check(page.locator('#sidebar').evaluate('(e)=>e.inert'),'Closed mobile navigation is not keyboard focusable')
    page.click('#mobileMenuButton')
    check(not page.locator('#sidebar').evaluate('(e)=>e.inert'),'Opened mobile navigation is keyboard accessible')
    page.click('[data-view-target="account"]')
    page.wait_for_timeout(250)
    check(page.locator('#view-account').is_visible() and page.locator('#sidebar').evaluate('(e)=>e.inert'),'Mobile account navigation closes offscreen menu')
    page.fill('#accountBusinessName','<img src=x onerror=alert(1)>')
    page.click('#accountProfileForm button[type="submit"]')
    check(page.locator('#accountBusinessTitle img').count()==0 and '<img' in page.locator('#accountBusinessTitle').inner_text(),'Business name is rendered as text, never executable HTML')
    page.evaluate('()=>{window.__savedSetItem=localStorage.setItem;localStorage.setItem=()=>{throw new DOMException("Quota exceeded","QuotaExceededError")};}')
    page.fill('#accountOwnerName','New owner')
    page.click('#accountProfileForm button[type="submit"]')
    check(page.locator('#storageWarning').is_visible() and 'Not saved' in page.locator('#profileSaveStatus').inner_text(),'Storage failure produces persistent warning and accurate status')
    page.evaluate('localStorage.setItem=window.__savedSetItem;StockWise.save();')
    check(not page.locator('#storageWarning').is_visible(),'Successful saving clears storage warning')
    original=page.evaluate('StockWise.state()')
    page.click('#accountRestoreButton')
    page.locator('#importDataInput').set_input_files({'name':'bad.json','mimeType':'application/json','buffer':b'{not-json'})
    page.wait_for_timeout(150)
    check(page.evaluate('StockWise.state().inventory.length')==len(original['inventory']),'Malformed backup does not replace workspace')
    # Restore through the real file-input handler, including native confirmation.
    restored=json.loads(json.dumps(original));restored['settings']['businessName']='Restored Test Kitchen'
    page.on('dialog',lambda dialog:dialog.accept())
    page.locator('#importDataInput').set_input_files({'name':'backup.json','mimeType':'application/json','buffer':json.dumps(restored).encode()})
    page.wait_for_timeout(250)
    check(page.evaluate('StockWise.state().settings.businessName')=='Restored Test Kitchen','Valid JSON backup restores through the real import form')
    page.evaluate('StockWise.state().inventory[0].name="=2+2";StockWise.save();StockWise.render();StockWise.navigate("account");')
    page.click('#downloadCSVButton')
    page.wait_for_timeout(90)
    check("'=2+2" in page.evaluate('__downloads.at(-1).text'),'CSV export neutralizes formula-like imported names')
    check(not errors,'No uncaught JavaScript errors in edge-case scenarios')
print(f'\n{count} additional isolated browser checks passed.',flush=True)
