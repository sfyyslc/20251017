"""Isolated DOM test adapter, not the production server.

For constrained environments where browser navigation is denied. Replaces storage,
fetch, and download side effects; leaves production app DOM/logic/CSS unchanged.
It does not validate real origin storage, CSP, HTTP modules, WebGPU, or email clients.
"""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
def mount(browser, storage=None, width=1440, height=1000):
    page=browser.new_page(viewport={'width':width,'height':height})
    html=(ROOT/'index.html').read_text()
    html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '',html)
    html=re.sub(r'<link rel="stylesheet"[^>]*>', '',html)
    html=re.sub(r'<script src="[^"]*" defer></script>', '',html)
    page.set_content(html)
    page.evaluate('''data => {
      window.__store = {...data.storage};
      Object.defineProperty(window, 'localStorage', {value: {
        getItem: key => Object.prototype.hasOwnProperty.call(window.__store,key) ? window.__store[key] : null,
        setItem: (key,value) => { window.__store[key]=String(value); },
        removeItem: key => delete window.__store[key],
        clear: () => { window.__store={}; },
        key: index => Object.keys(window.__store)[index] || null,
        get length() {return Object.keys(window.__store).length;}
      }});
      window.__requests=[]; window.__downloads=[]; window.__blobs=new Map();
      window.fetch=async url => {
        window.__requests.push(String(url));
        if (String(url)==='vendor/manifest.json') return new Response(JSON.stringify(data.manifest), {status:200,headers:{'content-type':'application/json'}});
        throw new Error('Unexpected network request in isolated test: '+url);
      };
      const create=URL.createObjectURL.bind(URL);
      URL.createObjectURL = blob => {const url=create(blob);window.__blobs.set(url,blob);return url;};
      document.addEventListener('click',async event=>{
        const a=event.target.closest('a');if(!a)return;
        if(a.download){event.preventDefault();const blob=window.__blobs.get(a.href);window.__downloads.push({name:a.download,type:blob.type,text:await blob.text()});}
        if(a.href.startsWith('mailto:')){event.preventDefault();window.__mail=a.href;}
      },true);
    }''',{'storage':storage or {},'manifest':json.loads((ROOT/'vendor/manifest.json').read_text())})
    for name in ['styles.css','workspace.css']:page.add_style_tag(content=(ROOT/name).read_text())
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    for name in ['app.js','assistant-actions.js','workspace.js']:page.add_script_tag(content=(ROOT/name).read_text())
    page.wait_for_timeout(500)
    return page,errors
