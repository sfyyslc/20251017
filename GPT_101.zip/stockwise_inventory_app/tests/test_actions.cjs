/* Optional development test. Run: node tests/test_actions.cjs */
const assert = require('node:assert/strict');
const api = require('../assistant-actions.js');
const state = {settings:{businessName:'Harbor Bowl Kitchen',ownerName:'Morgan',email:'owner@harborbowl.example',themeColor:'#195f3e',defaultHorizon:7,remindersEnabled:true,autoLoadAI:false},inventory:[
{id:'ing-rice',name:'Jasmine Rice',unit:'kg',stock:18.6,unitCost:2.35,reorderPoint:12,parLevel:34},
{id:'ing-eggs',name:'Eggs',unit:'each',stock:144,unitCost:.3,reorderPoint:48,parLevel:200},
{id:'ing-scallions',name:'Spring Onions',unit:'kg',stock:.8,unitCost:5.25,reorderPoint:1.2,parLevel:4},
{id:'ing-onions',name:'Yellow Onions',unit:'kg',stock:4,unitCost:1.4,reorderPoint:2,parLevel:8},
{id:'ing-soy',name:'Soy Sauce',unit:'L',stock:4,unitCost:3,reorderPoint:2,parLevel:8},
{id:'custom-oats',name:'Rolled Oats',unit:'kg',stock:6,unitCost:2,reorderPoint:3,parLevel:12}
],recipes:[{id:'recipe-classic-rice',name:'Classic Fried Rice'}]};
let checks=0;
function check(name,fn){fn();checks++;console.log('PASS '+name);}
const p=q=>api.parseIntent(q,state);
check('delivery preview adds, does not mutate',()=>{assert.equal(p('I bought 5 kg of rice').after,23.6);assert.equal(state.inventory[0].stock,18.6);});
check('compact grams convert to kilograms',()=>assert.equal(p('add 500g rice').amount,.5));
check('decimal gram conversion',()=>assert.equal(p('add 250.5 grams of rice').amount,.2505));
check('dozens convert to individual eggs',()=>assert.equal(p('I received two dozen eggs').amount,24));
check('literal count of eggs',()=>assert.equal(p('add 24 eggs').amount,24));
check('one dozen',()=>assert.equal(p('I bought a dozen eggs').amount,12));
check('liters conversion',()=>assert.equal(p('add 500ml soy sauce').amount,.5));
check('metric words',()=>assert.equal(p('I bought five kilograms of rice').amount,5));
check('pounds convert by weight only',()=>assert.equal(p('add 2 lbs rice').amount,.907185));
check('zero is a valid stock count',()=>assert.equal(p('set rice to 0kg').after,0));
check('absolute count does not add',()=>assert.equal(p('update rice to 20 kg').after,20));
check('negative delivery rejected',()=>assert.equal(p('add -5 kg rice').kind,'clarify'));
check('zero delivery rejected',()=>assert.equal(p('add 0kg rice').kind,'clarify'));
check('nonfinite input rejected',()=>assert.equal(p('add Infinity kg rice').kind,'clarify'));
check('very large quantity rejected',()=>assert.equal(p('add 900000000 kg rice').kind,'clarify'));
check('missing quantity asks clarification',()=>assert.equal(p('I bought more rice').kind,'clarify'));
check('missing unit for weight asks clarification',()=>assert.equal(p('add 5 rice').kind,'clarify'));
check('weight-volume conversion rejected',()=>assert.equal(p('add 5 liters rice').kind,'clarify'));
check('unknown case size not guessed',()=>assert.equal(p('add 2 cases eggs').kind,'clarify'));
check('fractional whole item rejected',()=>assert.equal(p('add 2.5 eggs').kind,'clarify'));
check('multiple items not guessed',()=>assert.equal(p('add 5 kg rice and 24 eggs').kind,'clarify'));
check('multiple numbers not guessed',()=>assert.equal(p('I bought 5 kg rice for $12').kind,'clarify'));
check('unknown inventory not silently created',()=>assert.equal(p('add 4 kg unicorn powder').kind,'clarify'));
check('longest ingredient alias wins',()=>assert.equal(p('add 1 kg spring onions').itemId,'ing-scallions'));
check('generic onions still match',()=>assert.equal(p('add 1 kg onions').itemId,'ing-onions'));
check('custom inventory names work',()=>assert.equal(p('I bought 2 kg Rolled Oats').itemId,'custom-oats'));
check('recipes not mistaken for delivery ingredients',()=>assert.equal(p('I bought 5 Classic Fried Rice').kind,'clarify'));
check('stock removal',()=>assert.equal(p('remove 1.6 kg rice').after,17));
check('negative resulting stock blocked',()=>assert.equal(p('remove 30 kg rice').kind,'clarify'));
check('reorder point is a separate field',()=>{const x=p('set rice reorder point to 10 kg');assert.equal(x.field,'reorderPoint');assert.equal(x.after,10);});
check('target stock is a separate field',()=>assert.equal(p('set rice par level to 40 kg').field,'parLevel'));
check('unit cost parses dollars',()=>{const x=p('set rice unit cost to $3 per kg');assert.equal(x.field,'unitCost');assert.equal(x.after,3);});
check('wrong cost unit rejected',()=>assert.equal(p('set rice unit cost to $3 per g').kind,'clarify'));
for (const phrase of ["I didn't buy 5kg rice",'Do not add 5kg rice','What if I bought 5kg rice','How do I add 5kg rice','Imagine I bought 5kg rice']) check('no write for '+phrase,()=>assert.equal(p(phrase),null));
check('business name setting',()=>assert.equal(p('Rename my business to Maple Street Kitchen').value,'Maple Street Kitchen'));
check('polite business setting',()=>assert.equal(p('Could you change my business name to Elm Kitchen?').value,'Elm Kitchen'));
check('owner name setting',()=>assert.equal(p('set my name to Alex').key,'ownerName'));
check('email setting',()=>assert.equal(p('set my email to alex@example.org').value,'alex@example.org'));
check('connect email saves destination only',()=>assert.equal(p('connect my email alex@example.org').key,'email'));
check('email invalid rejected',()=>assert.equal(p('set my email to not-an-email').kind,'clarify'));
check('email header injection rejected',()=>assert.equal(api.validEmail('a@b.com\r\nBcc:c@d.com'),false));
check('email multi-address rejected',()=>assert.equal(api.validEmail('a@b.com,b@b.com'),false));
check('email clear',()=>assert.equal(p('remove my email').value,''));
check('blue theme',()=>assert.equal(p('Change my website color to blue').value,'#245cb5'));
check('custom color',()=>assert.equal(p('set my theme to #ABCDEF').value,'#abcdef'));
check('unknown color rejected',()=>assert.equal(p('set my website color to invisible').kind,'clarify'));
check('reminder disable',()=>assert.equal(p('turn off low stock reminders').value,false));
check('reminder enable',()=>assert.equal(p('enable reminders').value,true));
check('forecast window',()=>assert.equal(p('set my forecast to 14 days').value,14));
check('unsupported forecast window',()=>assert.equal(p('set forecast to 9 days').kind,'clarify'));
check('auto AI preference',()=>assert.equal(p('turn on automatic AI loading').value,true));
check('valid action passes revalidation',()=>assert.equal(api.validateAction(p('add 5kg rice'),state),null));
check('stale stock preview rejected',()=>{const x=p('add 5kg rice');const changed=JSON.parse(JSON.stringify(state));changed.inventory[0].stock++;assert.match(api.validateAction(x,changed),/changed/);});
check('stale setting preview rejected',()=>{const x=p('set my email to other@example.org');const changed=JSON.parse(JSON.stringify(state));changed.settings.email='x@y.com';assert.match(api.validateAction(x,changed),/changed/);});
check('unsupported setting denied at apply time',()=>assert.match(api.validateAction({kind:'setting',key:'__proto__'},state),/cannot/));
check('invalid proposed numeric value denied',()=>{const x=p('add 5kg rice');x.after=NaN;assert.match(api.validateAction(x,state),/invalid/);});
check('unknown boxes cannot become individual eggs',()=>assert.equal(p('I bought 2 boxes of eggs').kind,'clarify'));
check('unknown trays cannot become individual eggs',()=>assert.equal(p('add 2 trays of eggs').kind,'clarify'));
check('unknown cups cannot become stored kilograms',()=>assert.equal(p('add 2 cups of rice').kind,'clarify'));
console.log(`\n${checks} parser and validation checks passed.`);
